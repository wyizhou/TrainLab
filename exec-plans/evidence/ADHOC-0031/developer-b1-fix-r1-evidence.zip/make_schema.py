import json
from pathlib import Path

def obj(p): return {'type':'object','properties':p,'required':list(p),'additionalProperties':False}
def ref(n): return {'$ref':'#/$defs/'+n}
def arr(s): return {'type':'array','items':s}
def mapping(pattern,s): return {'type':'object','patternProperties':{pattern:s},'additionalProperties':False}
def nullable(s): return {'anyOf':[s,{'type':'null'}]}
string={'type':'string'}
integer={'type':'integer','minimum':0}
textnull=nullable(string)
sha={'type':'string','pattern':'^[0-9a-f]{64}$'}
fid={'type':'string','pattern':'^f(0|[1-9][0-9]*)$'}
did={'type':'string','pattern':'^d(0|[1-9][0-9]*)$'}
utc={'type':'string','format':'date-time','pattern':r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{6}Z$'}
d={}
d['Value']={'anyOf':[{'type':['null','boolean','string']},{'type':'number','minimum':-9007199254740991,'maximum':9007199254740991},arr(ref('Value')),obj({'integer':{'type':'string','pattern':'^(0|-?[1-9][0-9]*)$'}}),obj({'bytes_hex':{'type':'string','pattern':'^([0-9a-f]{2})*$'}})]}
d['FieldMap']=mapping(r'^f(0|[1-9][0-9]*)$',ref('Value'))
d['FieldSet']=obj({'standard':ref('FieldMap'),'developer':ref('FieldMap')})
d['Definition']=obj({'message_number':integer,'message_name':textnull,'field_number':integer,'name':textnull,'base_type':{'enum':['enum','sint8','uint8','sint16','uint16','sint32','uint32','string','float32','float64','uint8z','uint16z','uint32z','byte','sint64','uint64','uint64z']},'unit':textnull,'origin':{'enum':['direct','expanded','merged']},'source_ref':nullable(did),'definition_index':integer,'chain_index':integer,'component_of':nullable(fid),'value_form':{'enum':['physical','raw']}})
d['Definitions']=mapping(r'^f(0|[1-9][0-9]*)$',ref('Definition'))
d['Source']=obj({'chain_index':integer,'developer_data_index':integer,'application_name':textnull,'manufacturer':nullable({'type':['string','integer']})})
d['Sources']=mapping(r'^d(0|[1-9][0-9]*)$',ref('Source'))
d['Message']=obj({'message_index':integer,'chain_index':integer,'message_number':integer,'message_name':textnull,'fields':ref('FieldSet')})
groups={'basic_json':[0,34,49],'summary_json':[18],'segments_json':[19,101,142,225,312,313]}
for group, nums in groups.items():
 d[group+'Message']={'allOf':[ref('Message'),{'properties':{'message_number':{'enum':nums}}}]}
d['SensorsMessage']={'allOf':[ref('Message'),{'properties':{'message_number':{'not':{'enum':[20]+sum(groups.values(),[])}}}}]}
d['Basic']=obj({'sport':textnull,'sub_sport':textnull,'start_time_utc':nullable(utc),'end_time_utc':nullable(utc),'messages':arr(ref('basic_jsonMessage'))})
d['Summary']=obj({'messages':arr(ref('summary_jsonMessage'))})
d['Segments']=obj({'items':arr(ref('segments_jsonMessage'))})
d['Sensors']=obj({'field_definitions':ref('Definitions'),'developer_sources':ref('Sources'),'messages':arr(ref('SensorsMessage'))})
d['TimeEvidence']=obj({'kind':{'enum':['absolute','relative','local','invalid','missing']},'raw':ref('Value'),'unit':textnull})
d['Metrics']=obj({'standard':ref('FieldMap'),'developer':ref('FieldMap'),'time_evidence':ref('TimeEvidence')})
d['Record']=obj({'record_index':integer,'timestamp_utc':nullable(utc),'metrics_json':ref('Metrics')})
d['ActivityFacts']=obj({'activity_id':sha,'schema_version':{'const':1,'type':'integer'},'basic_json':ref('Basic'),'summary_json':ref('Summary'),'segments_json':ref('Segments'),'field_definitions':ref('Definitions'),'developer_sources':ref('Sources')})
d['ParsedActivity']=obj({'sport':textnull,'sub_sport':textnull,'start_time_utc':nullable(utc),'end_time_utc':nullable(utc),'basic_json':ref('Basic'),'summary_json':ref('Summary'),'segments_json':ref('Segments'),'sensors_json':ref('Sensors'),'records':arr(ref('Record'))})
d['GetRunningRecordsRequest']=obj({'activity_id':sha})
d['Error']=obj({'code':string,'message':string,'details':{'type':'object'}})
d['GetRunningRecordsResult']=obj({'schema_version':{'const':'fit-records/1'},'ok':{'type':'boolean'},'activity_id':nullable(sha),'data':nullable(obj({'field_definitions':ref('Definitions'),'developer_sources':ref('Sources'),'records':arr(ref('Record'))})),'error':nullable(ref('Error'))})
d['GetRunningRecordsResult']['allOf']=[{'if':{'properties':{'ok':{'const':True}}},'then':{'properties':{'activity_id':sha,'data':{'type':'object'},'error':{'type':'null'}}},'else':{'properties':{'data':{'type':'null'},'error':{'type':'object'}}}}]
rid={'enum':['longdou','garmin-fit-parsing']}
d['ReadReferenceRequest']=obj({'reference_id':rid})
d['ReadReferenceResult']=obj({'ok':{'type':'boolean'},'data':nullable(obj({'reference_id':rid,'title':string,'content':string})),'error':nullable(ref('Error'))})
summary={'type':'string','pattern':r'\S'}
d['ActivityReportSave']=obj({'activity_id':sha,'start_time_utc':nullable(utc),'summary':summary})
d['WeeklyReportSave']=obj({'run_time_utc':utc,'summary':summary})
def exact_patterns(value):
 if isinstance(value, list):
  for item in value: exact_patterns(item)
 if isinstance(value, dict):
  for key, item in list(value.items()):
   if key == 'pattern' and item.endswith('$'): value[key] = item[:-1] + r'(?![\s\S])'
   elif key == 'patternProperties':
    value[key] = {k[:-1] + r'(?![\s\S])' if k.endswith('$') else k: v for k,v in item.items()}
   else: exact_patterns(item)
exact_patterns(d)
root=Path('source/schemas')
(root/'contracts.schema.json').write_text(json.dumps({'$schema':'https://json-schema.org/draft/2020-12/schema','$defs':d,'x-message-containers':groups},indent=2)+'\n')
basic={'sport':None,'sub_sport':None,'start_time_utc':None,'end_time_utc':None,'messages':[]}
examples={'ActivityFacts':{'activity_id':'a'*64,'schema_version':1,'basic_json':basic,'summary_json':{'messages':[]},'segments_json':{'items':[]},'field_definitions':{},'developer_sources':{}},'GetRunningRecordsRequest':{'activity_id':'a'*64},'GetRunningRecordsResult':{'schema_version':'fit-records/1','ok':True,'activity_id':'a'*64,'data':{'field_definitions':{},'developer_sources':{},'records':[]},'error':None},'ReadReferenceRequest':{'reference_id':'longdou'},'ReadReferenceResult':{'ok':True,'data':{'reference_id':'longdou','title':'公开资料','content':'合成全文'},'error':None},'ActivityReportSave':{'activity_id':'a'*64,'start_time_utc':None,'summary':'全文总结'},'WeeklyReportSave':{'run_time_utc':'2030-01-01T00:00:00.000000Z','summary':'本周无任何运动记录'}}
(root/'examples.json').write_text(json.dumps(examples,ensure_ascii=False,indent=2)+'\n')
