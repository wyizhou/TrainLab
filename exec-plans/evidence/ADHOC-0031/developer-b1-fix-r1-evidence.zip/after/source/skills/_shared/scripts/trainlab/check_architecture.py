from __future__ import annotations

import ast
import sys
from pathlib import Path

from trainlab.contracts.interfaces import (
    UNCONFIGURED_POLICIES,
    PendingDecision,
    validate_schema_examples,
)
from trainlab.contracts.paths import WEB_STATIC_DIR, validate_static_mount
from trainlab.contracts.schema import BUSINESS_TABLES, SYSTEM_TABLES, table_contracts


def check_layout(source: Path) -> None:
    for name in ("trainlab", "src", "index.py"):
        if (source / name).exists():
            raise ValueError("unapproved implementation root: " + name)
    if list((source / "tools").rglob("*.py")):
        raise ValueError("tools is documentation only")
    if not (source / "schemas/contracts.schema.json").is_file():
        raise ValueError("public schema missing")
    for path in (source / "skills").rglob("*.py"):
        relative = path.relative_to(source)
        if len(relative.parts) < 4 or relative.parts[2] != "scripts":
            raise ValueError("runtime implementation outside Skill/scripts")
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if (
                isinstance(node, ast.Attribute)
                and isinstance(node.value, ast.Attribute)
                and isinstance(node.value.value, ast.Name)
                and node.value.value.id == "sys"
                and node.value.attr == "path"
            ):
                raise ValueError("runtime sys.path patch forbidden")


def main() -> int:
    root = Path.cwd()
    source = root if (root / "pyproject.toml").exists() else root / "source"
    check_layout(source)
    validate_static_mount(WEB_STATIC_DIR)
    tables = table_contracts()
    if (
        tuple(t.name for t in tables if t.business_table) != BUSINESS_TABLES
        or tuple(t.name for t in tables if not t.business_table) != SYSTEM_TABLES
    ):
        raise ValueError("table ownership mismatch")
    if set(UNCONFIGURED_POLICIES) != set(PendingDecision):
        raise ValueError("pending policy mismatch")
    validate_schema_examples()
    print("architecture and public Schema checks passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
