# TrainLab source

当前只实现本地工程底座及 FIT/SQLite 基础层；不启动同步、定时器、报告生成或 AI 请求，不读取正式私人实例。

## 目录与安装

- `source/skills/_shared/scripts/trainlab/`：共享合同、JSON 校验、时间、数据库协调门和架构检查。
- `source/skills/fit-store/scripts/`：实际 FIT 解码、消息映射、activities/records 唯一写入者。
- `source/skills/local-web/scripts/`：最小 FastAPI 应用；`web/` 是 React 生成目录。
- `source/schemas/`：公开 JSON Schema 及合法示例；所有验证入口引用同一份 Schema。
- `source/tools/README.md`：能力说明，不放执行脚本。
- `source/frontend/`、`source/tests/`：前端与合成测试。

Python 包名仍为 `trainlab`，由 `source/pyproject.toml` 的 setuptools 映射到上述物理目录。无需也不允许运行时修改 `sys.path`。Schema 同时打包为资源，正常 wheel 安装后可离开工程目录导入。

使用仓库外独立 Python 3.12 环境；不要全局安装或创建仓库 `.venv`。预先将 `UV_PROJECT_ENVIRONMENT` 设置为该仓库外环境，按锁文件安装（在项目根运行）：

```bash
: "${UV_PROJECT_ENVIRONMENT:?请先指向仓库外独立环境}"
uv sync --project source --python 3.12 --locked --extra dev --no-editable
```

检查使用实际安装的非 editable 包。修改产品后先重新执行安装，防止检查到旧 wheel。`source/uv.lock` 固定全部解析后的依赖；SDK 为 `garmin-fit-sdk==21.214.0`，Schema 验证器为 `jsonschema==4.26.0`。

## 本地检查

在激活上述环境后，从 `source/` 运行：

```bash
python -m pytest tests -q -p no:cacheprovider
python -m ruff check --no-cache .
python -m mypy -p trainlab -p tests --no-incremental
python -m compileall -q skills schemas tests
python -m trainlab.check_architecture
```

mypy 显式检查已安装产品包及当前测试。原 `trainlab skills tools tests` 物理路径检查改为包检查；原 `tools/check_b0_static.py` 改为共享包模块入口，原检查覆盖保留并增加违规目录/导入补丁检查。

前端在 `source/frontend/`：

```bash
npm ci
npm run lint
npm run typecheck
npm test
npm run build
```

构建直接输出 `source/skills/local-web/web/`，不清空相邻 scripts。仅最小 health/静态应用已接线；其他业务路由不伪造成功结果。

## FIT 基础层

`trainlab.fit.import_fit_file(instance_root, fit_path)` 默认调用实际解析器，不需要注入 decoder。只在完整解码和 JSON/引用校验后建库、整场事务写入。实例及 FIT 路径必须由受信宿主提供；测试全部使用临时合成实例。

同 SHA 普通导入不修改已有有效数据、原路径、解析时间或报告。维护必须显式调用 `trainlab.fit.storage.reparse_fit_file`：读取原入库路径、核验原件 SHA、完整解析，再取得单进程协调门更新；无变化不写，有活动报告且依赖事实变化则 `REPARSE_CONFLICT`，失败保留五表数据。内部 `replace_activity` 只供 FIT 仓储与合成测试使用，不是模型/Web 工具。

默认事实接口 `get_activity_facts` 只返回批准的123容器和其所需字段/来源闭包，不整体返回第四类。12/4/3/3业务列及config三列不变；没有自动付费补报或重解析UI。

解析能力、SDK适配与完整性细则见 [FIT基础层说明](skills/fit-store/README.md)。采样查询、报告生成/存储业务、同步、AI/Context和完整Web业务仍待后续阶段实现，不能把本轮自查当整个系统验收。
