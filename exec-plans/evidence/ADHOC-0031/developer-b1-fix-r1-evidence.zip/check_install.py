from pathlib import Path
import hashlib
import importlib.metadata as metadata
import json
import sys
import trainlab
import trainlab_schemas
import garmin_fit_sdk
from garmin_fit_sdk.profile import Profile

root=Path(sys.argv[1])
installed=Path(trainlab.__file__).parent
pairs=[(root/'source/skills/_shared/scripts/trainlab',installed),(root/'source/skills/fit-store/scripts',installed/'fit'),(root/'source/skills/local-web/scripts',installed/'local_web'),(root/'source/schemas',Path(trainlab_schemas.__file__).parent)]
items=[]
for source,dest in pairs:
 for file in sorted(source.rglob('*')):
  if not file.is_file() or '__pycache__' in file.parts or file.suffix not in ('.py','.json','.typed'):continue
  other=dest/file.relative_to(source)
  assert other.is_file(), str(other)
  assert file.read_bytes()==other.read_bytes(), str(file)
  items.append({'source':file.relative_to(root).as_posix(),'installed':str(other),'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
sdk=Path(garmin_fit_sdk.__file__).parent
info={'python':sys.version,'executable':sys.executable,'checked_install_files':items,'dependencies':{d.metadata['Name']:d.version for d in metadata.distributions()},'sdk_profile':{'messages':len(Profile['messages']),'types':len(Profile['types'])},'sdk_files':{name:hashlib.sha256((sdk/name).read_bytes()).hexdigest() for name in ('decoder.py','profile.py','fit.py','crc_calculator.py')},'cwd':str(Path.cwd())}
print(json.dumps(info,indent=2))
