from pathlib import Path
import hashlib,json,subprocess,sys,os
ROOT=Path('/Volumes/DiskOther/Code/TrainLab')
E=Path(__file__).parent
PY=E/'verify-venv/bin/python'
logs=E/'final-validation';logs.mkdir(exist_ok=True)

def snapshot():
 paths=['.gitignore']+subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','source'],cwd=ROOT,text=True).splitlines()
 items=[]
 for name in sorted(set(paths)):
  p=ROOT/name
  if p.is_file():items.append({'path':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size,'mode':oct(p.stat().st_mode & 0o777)})
 return items
before=snapshot()
results=[]
commands=[
 ('pytest',ROOT/'source',[PY,'-m','pytest','tests','-q','-p','no:cacheprovider','--junitxml='+str(logs/'pytest.xml')]),
 ('ruff',ROOT/'source',[PY,'-m','ruff','check','--no-cache','.']),
 ('mypy',ROOT/'source',[PY,'-m','mypy','-p','trainlab','-p','tests','--no-incremental']),
 ('compileall',ROOT/'source',[PY,'-m','compileall','-q','skills','schemas','tests']),
 ('architecture',ROOT/'source',[PY,'-m','trainlab.check_architecture']),
 ('installed-parity',E,[PY,E/'check_install.py',ROOT]),
 ('frontend-lint',ROOT/'source/frontend',['npm','run','lint']),
 ('frontend-types',ROOT/'source/frontend',['npm','run','typecheck']),
 ('frontend-test',ROOT/'source/frontend',['npm','test']),
 ('frontend-build',ROOT/'source/frontend',['npm','run','build']),
 ('diff-check',ROOT,['git','diff','--check']),
 ('index-check',ROOT,['git','diff','--cached','--exit-code']),
]
for name,cwd,args in commands:
 args=list(map(str,args));r=subprocess.run(args,cwd=cwd,text=True,capture_output=True)
 (logs/(name+'.log')).write_text(r.stdout+r.stderr)
 results.append({'name':name,'cwd':str(cwd),'command':args,'exit_code':r.returncode,'log':str(logs/(name+'.log'))})
 print(name,r.returncode,flush=True)
after=snapshot();assert before==after
base=json.loads((E/'baseline.json').read_text())
bmap={x['path']:x for x in base['items']};amap={x['path']:x for x in after}
state={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'branch':subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip(),'git_status':subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True),'no_staged_files':not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip(),'items':after,'file_count':len(after),'aggregate_sha256':hashlib.sha256(json.dumps(after,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'added':sorted(set(amap)-set(bmap)),'removed':sorted(set(bmap)-set(amap)),'changed':sorted(p for p in set(amap)&set(bmap) if amap[p]['sha256']!=bmap[p]['sha256']),'tests_unchanged_during_validation':True}
(E/'final-snapshot.json').write_text(json.dumps(state,indent=2))
(E/'final-results.json').write_text(json.dumps(results,indent=2))
print('files',state['file_count'],'aggregate',state['aggregate_sha256'])
sys.exit(int(any(r['exit_code'] for r in results)))
