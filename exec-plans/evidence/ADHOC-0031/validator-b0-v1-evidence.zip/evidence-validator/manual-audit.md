# B0 独立人工核对

- 依据：baseline 中 AGENTS.md、Validator模板、ADHOC-0031执行计划、2026-09-16用户决定以及25个 source 文件。未读取Developer报告、规划原报告或旧验证输出。
- 固定副本：开始逐文件比对SHA-256及模式；scratch初始25个source文件与baseline相同。仅在scratch建立环境、生成物、合成states和临时测试。
- 环境：Python 3.12.13、uv 0.12.3、Node 26.5.0、npm 11.17.0。项目声明依赖安装成功；pytest、httpx为独立验证额外依赖，不能据此证明项目声明齐全。
- Python：现有9个unittest用例可被pytest收集；Ruff、strict mypy（15个文件）、compile均成功。但pyproject dev只有mypy/Ruff，独立仅安装项目声明的环境无法运行pytest。
- 前端：package.json只有build/test两个命令；两类依赖均为空。构建器将renderShell返回的字符串写入HTML/CSS，无React组件或运行时，无lint/type入口。3个node测试仅验证路由前缀、静态常量和壳文字；产物SHA与baseline相同不等于React基础完成。
- 目录：无source/src、source/index.py；脚本入口及前端产物位置正确，tools/README.md为能力索引。source/skills/_shared/scripts/contracts.py为转导出，公共基础设施实现实际位于source/trainlab/contracts；没有自动检查批准目录A共享实现位置的约束。
- SQLite：实际列名/类型、12/4/3/3列及config三列与声明一致。显式foreign_keys=ON后普通外键及records复合唯一键生效，重复时间点可保留，126000字合成全文可无损保存，自增周报ID不复用。activities/activties_report的activity_id以及config.key虽声明nullable=False，TEXT PRIMARY KEY实际允许多条NULL；这是DDL声明不一致，不是要求额外业务列。
- 时间：有时区时间的跨UTC日/年、七天窗口、北京时间4点边界通过；next函数在恰好4点返回次日（仅记录当前helper语义，不据此推断调度漏跑）。history.append对naive datetime采用操作系统时区，TZ不同使相同输入相差8小时，与ensure_utc拒绝naive的行为不一致。
- 命名：合成字节SHA和UTC日期组合/unknown名称正确，非法摘要和常见路径字符拒绝。activity_fit_name仍接受20260230、全角数字；精确日历输入校验未闭合。本轮没有下载器或原件写入服务，未宣称验证了实际计算SHA、去重、旧原件保护。
- 内存：两实例互不串话、快照不随后续clear改变，新进程为空；没有持久化实现。未触及任何正式states内容。
- 私有路径：真实create_app+TestClient在正常合成根可提供HTML/CSS/health，私有URL、编码遍历和指向合成私密文件的单文件软链接返回404。路径验证器对web/../../../../states错误放行；当静态根本身是指向合成states的软链接时，真实factory提供/ai.json为200并包含合成密钥。后者前提是本机静态根被替换为软链接，不宣称普通远程URL遍历即可泄露默认安装。
- 公共合同未冻结：现有Schema仅SQL列/DDL元数据；ErrorEnvelope和路由名称不是完整活动/records/报告/API/工具请求响应DTO或JSON Schema。activity/reports/sync列表只有路由声明，API真实health和404也未复用公共envelope。授权只有tools README文字；缺少宿主可信作用域、技术容量失败、重复/幂等、七天边界/缺报与无活动区分的完整公共接口与映射。RESOURCE_LIMIT枚举不能证明容量不足整体失败。用户已允许请求/数据不限，不据此增加费用或次数上限。
- B1～B7尚未开始：FIT解析、仓储、运行采样工具、同步/认证、正式定时、AI协议循环、三模式Context、报告自动生成、浏览搜索和浏览器效果不属于当前可运行骨架；不以其未实现单独判B0代码缺陷，也不把骨架检测视为这些能力通过。
- 所有HTTP测试为scratch合成根的TestClient上下文，结束已关闭；未启动正式监听、调度器或外部业务请求。依赖获取不等于业务实调用。
- 未修改受审文件或协调记录，未暂存/提交。完整命令及退出码在commands.json、followup-commands.json，独立场景在scratch-validator/test_independent_b0.py及independent-pytest.log。
