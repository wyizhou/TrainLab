import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
from datetime import UTC, datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient

from trainlab.contracts.errors import ErrorCode, failure_envelope, success_envelope
from trainlab.contracts.paths import WEB_STATIC_DIR, activity_fit_name, validate_static_mount
from trainlab.contracts.schema import ddl_statements, table_contracts
from trainlab.contracts.session import InMemoryConversationHistory
from trainlab.contracts.time import ensure_utc, utc_fit_date, initial_sync_window, weekly_window, next_activity_report_run_utc

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT.parent / 'evidence-validator'
OBSERVED = {}


def observe(key, value):
    OBSERVED[key] = value
    (EVIDENCE / 'independent-observations.json').write_text(json.dumps(OBSERVED, ensure_ascii=False, indent=2))


def connection():
    db = sqlite3.connect(':memory:')
    db.execute('PRAGMA foreign_keys=ON')
    for statement in ddl_statements():
        db.execute(statement)
    return db


def activity_values(identity='a' * 64):
    return (identity, 'states/activities/synthetic.fit', 'running', None, '2026-09-15T12:00:00Z', None,
            1, '2026-09-16T00:00:00Z', '{}', '{}', '[]', '{}')


def load_server():
    spec = importlib.util.spec_from_file_location('validator_server', ROOT / 'source/skills/local-web/scripts/server.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_declared_frontend_is_react_base():
    package = json.loads((ROOT / 'source/frontend/package.json').read_text())
    dependencies = package.get('dependencies', {}) | package.get('devDependencies', {})
    observe('frontend_dependencies', dependencies)
    assert {'react', 'react-dom'} <= dependencies.keys(), 'React target has no declared React runtime'


def test_declared_python_check_dependencies():
    import tomllib
    project = tomllib.loads((ROOT / 'source/pyproject.toml').read_text())
    requirements = project['project']['dependencies'] + project['project']['optional-dependencies']['dev']
    observe('declared_python_requirements', requirements)
    assert any(requirement.split('>')[0].split('=')[0].split('<')[0] == 'pytest' for requirement in requirements), 'pytest only available after validator supplied it'


def test_built_output_and_imports():
    server = load_server()
    assert server.app_contract()['starts_background_jobs'] is False
    web = ROOT / WEB_STATIC_DIR
    baseline = ROOT.parent / 'baseline' / WEB_STATIC_DIR
    data = {}
    for filename in ('index.html', 'assets/main.css'):
        digest = hashlib.sha256((web / filename).read_bytes()).hexdigest()
        assert digest == hashlib.sha256((baseline / filename).read_bytes()).hexdigest()
        data[filename] = digest
    observe('build_matches_frozen_output', data)
    assert not (ROOT / 'source/src').exists()
    assert not (ROOT / 'source/index.py').exists()
    assert not (ROOT / 'source/frontend/dist').exists()
    assert not (ROOT / '.venv').exists()


def test_schema_real_columns_and_normal_relations():
    db = connection()
    actual = {table.name: db.execute(f'PRAGMA table_info({table.name})').fetchall() for table in table_contracts()}
    observe('sqlite_table_info', actual)
    for table in table_contracts():
        assert [column[1] for column in actual[table.name]] == list(table.column_names)
        assert [column[2] for column in actual[table.name]] == [column.sql_type for column in table.columns]
    db.execute('INSERT INTO activities VALUES(?,?,?,?,?,?,?,?,?,?,?,?)', activity_values())
    for record_index, timestamp in [(2, None), (0, '2026-09-15T12:00:00Z'), (1, '2026-09-15T12:00:00Z')]:
        db.execute('INSERT INTO records VALUES(?,?,?,?)', ('a'*64, record_index, timestamp, '{}'))
    records = db.execute('SELECT record_index,timestamp_utc FROM records ORDER BY record_index').fetchall()
    assert [record[0] for record in records] == [0,1,2]
    assert records[0][1] == records[1][1]
    with pytest.raises(sqlite3.IntegrityError):
        db.execute('INSERT INTO records VALUES(?,?,?,?)', ('a'*64, 1, None, '{}'))
    with pytest.raises(sqlite3.IntegrityError):
        db.execute('INSERT INTO records VALUES(?,?,?,?)', ('missing', 0, None, '{}'))
    with pytest.raises(sqlite3.IntegrityError):
        db.execute('INSERT INTO activties_report VALUES(?,?,?)', ('missing', None, 'synthetic'))
    full = '合成报告\n"特殊字符" <script>not executed</script>\n' * 3000
    db.execute('INSERT INTO activties_report VALUES(?,?,?)', ('a'*64, '2026-09-15T12:00:00Z', full))
    db.execute('INSERT INTO weekly_report(run_time_utc,summary) VALUES(?,?)', ('2026-09-16T00:00:00Z', full))
    assert db.execute('SELECT summary FROM activties_report').fetchone()[0] == full
    assert db.execute('SELECT summary FROM weekly_report').fetchone()[0] == full
    db.execute('DELETE FROM weekly_report')
    db.execute('INSERT INTO weekly_report(run_time_utc,summary) VALUES(?,?)', ('2026-09-17T00:00:00Z', '本周无任何运动记录'))
    assert db.execute('SELECT id FROM weekly_report').fetchone()[0] == 2
    observe('sqlite_normal', {'record_order': [0,1,2], 'duplicate_timestamp_kept': True, 'full_summary_chars': len(full), 'foreign_keys_enforced': True, 'weekly_next_id': 2})
    db.close()


@pytest.mark.parametrize('table,values', [
    ('activities', activity_values(None)),
    ('activties_report', (None, None, 'synthetic')),
    ('config', (None, '{}', '2026-09-16T00:00:00Z')),
])
def test_declared_nonnullable_text_primary_keys(table, values):
    db = connection()
    sql = f'INSERT INTO {table} VALUES ({",".join("?" for _ in values)})'
    accepted = False
    try:
        db.execute(sql, values)
        db.execute(sql, values)
        accepted = True
    except sqlite3.IntegrityError:
        pass
    count = db.execute(f'SELECT COUNT(*) FROM {table} WHERE {"key" if table == "config" else "activity_id"} IS NULL').fetchone()[0]
    observe('null_primary_key_' + table, {'two_null_rows_accepted': accepted, 'null_rows': count})
    db.close()
    assert not accepted, f'{table}: nullable=False declaration but two NULL primary key rows stored'


def test_utc_windows_and_schedule_boundaries():
    east = timezone(timedelta(hours=8))
    moment = datetime(2026,1,1,1,0,0,123456,tzinfo=east)
    assert utc_fit_date(moment) == '20251231'
    for window in (initial_sync_window, weekly_window):
        start, end = window(moment)
        assert end == datetime(2025,12,31,17,0,0,123456,tzinfo=UTC)
        assert end - start == timedelta(days=7)
        assert start.tzinfo == end.tzinfo == UTC
    with pytest.raises(ValueError):
        ensure_utc(datetime(2026,1,1))
    before = datetime(2026,12,31,19,59,59,999999,tzinfo=UTC)
    exact = datetime(2026,12,31,20,tzinfo=UTC)
    assert next_activity_report_run_utc(before) == exact
    assert next_activity_report_run_utc(exact) == datetime(2027,1,1,20,tzinfo=UTC)
    observe('schedule_boundary', {'before': next_activity_report_run_utc(before).isoformat(), 'exact': next_activity_report_run_utc(exact).isoformat()})


def test_actual_byte_sha_and_naming():
    payload = b'synthetic FIT bytes only\x00\xff'
    digest = hashlib.sha256(payload).hexdigest()
    assert activity_fit_name('20260916', digest) == f'20260916-{digest}.fit'
    assert activity_fit_name(None, digest) == f'unknown-{digest}.fit'
    for invalid in ('x'*64, 'A'*64, 'a'*63, '../' + 'a'*61):
        with pytest.raises(ValueError):
            activity_fit_name('20260916', invalid)
    for invalid in ('../states', '2026-09-16'):
        with pytest.raises(ValueError):
            activity_fit_name(invalid, digest)
    observe('filename_calendar_validation_gap', [activity_fit_name(date, digest) for date in ('20260230', '２０２６０９１６')])


def test_history_memory_isolation_and_snapshot():
    history = InMemoryConversationHistory()
    other = InMemoryConversationHistory()
    history.append('user', 'synthetic', datetime(2026,9,16,tzinfo=UTC))
    snapshot = history.snapshot()
    assert len(snapshot) == 1 and other.snapshot() == ()
    history.clear()
    assert history.snapshot() == () and len(snapshot) == 1
    result = subprocess.run([sys.executable, '-c', 'from trainlab.contracts.session import InMemoryConversationHistory; print(len(InMemoryConversationHistory().snapshot()))'], capture_output=True, text=True, env=os.environ.copy())
    assert result.returncode == 0 and result.stdout.strip() == '0'
    assert history.persistence_target is None


def test_history_rejects_ambiguous_time():
    history = InMemoryConversationHistory()
    try:
        history.append('user', 'synthetic', datetime(2026,9,16,0,0))
    except ValueError:
        return
    observe('naive_history_accepted', history.snapshot()[0].created_at_utc.isoformat())
    pytest.fail('history accepts naive time unlike ensure_utc; depends on process local timezone')


def test_error_envelope_serializable_normal_failure():
    success = success_envelope({'summary': '合成全文\nsecond line'}).to_json()
    failure = failure_envelope(ErrorCode.RESOURCE_LIMIT, 'synthetic resource failure').to_json()
    assert success['ok'] and success['error'] is None
    assert not failure['ok'] and failure['data'] is None
    assert failure['error']['code'] == 'RESOURCE_LIMIT'
    assert json.loads(json.dumps(success)) == success
    observe('envelopes', [success, failure])


@pytest.mark.parametrize('path', [Path('states'), Path('states/ai.json'), Path('source'), Path('source/frontend')])
def test_static_policy_rejects_obvious_private_paths(path):
    with pytest.raises(ValueError):
        validate_static_mount(path)


def test_static_policy_rejects_dotdot_escape():
    path = WEB_STATIC_DIR / '../../../../states'
    try:
        validate_static_mount(path)
    except ValueError:
        return
    observe('accepted_static_escape', str(path))
    pytest.fail('static validator allows traversal outside web root')


def test_real_app_normal_and_encoded_traversal(monkeypatch):
    monkeypatch.chdir(ROOT)
    fake_states = ROOT / 'states'
    fake_states.mkdir(exist_ok=True)
    (fake_states/'ai.json').write_text('{"api_key":"SYNTHETIC_PRIVATE_MARKER"}')
    web = ROOT / WEB_STATIC_DIR
    link = web / 'private-link.json'
    link.symlink_to(fake_states / 'ai.json')
    server = load_server()
    try:
        with TestClient(server.create_app()) as client:
            codes = {}
            for url in ('/', '/assets/main.css', '/api/health', '/states/ai.json', '/ai.json', '/%2e%2e/%2e%2e/%2e%2e/%2e%2e/states/ai.json', '/private-link.json', '/api/absent', '/api/activities'):
                response = client.get(url)
                codes[url] = response.status_code
                assert 'SYNTHETIC_PRIVATE_MARKER' not in response.text
                if url in ('/', '/assets/main.css', '/api/health'):
                    assert response.status_code == 200
                else:
                    assert response.status_code == 404
            health = client.get('/api/health').json()
            error = client.get('/api/absent').json()
            observe('actual_http', {'status_codes': codes, 'health_json': health, 'api_404_json': error})
    finally:
        link.unlink()


def test_real_app_rejects_static_root_symlink(monkeypatch):
    instance = ROOT / 'symlink-instance'
    fake_states = instance / 'states'
    fake_states.mkdir(parents=True, exist_ok=True)
    (fake_states/'ai.json').write_text('{"api_key":"SYNTHETIC_PRIVATE_MARKER"}')
    mount = instance / WEB_STATIC_DIR
    mount.parent.mkdir(parents=True, exist_ok=True)
    mount.symlink_to(fake_states, target_is_directory=True)
    server = load_server()
    monkeypatch.chdir(instance)
    try:
        try:
            app = server.create_app()
        except (ValueError, RuntimeError):
            return
        with TestClient(app) as client:
            response = client.get('/ai.json')
            observe('static_root_symlink', {'status': response.status_code, 'synthetic_secret_served': 'SYNTHETIC_PRIVATE_MARKER' in response.text})
            assert response.status_code != 200 and 'SYNTHETIC_PRIVATE_MARKER' not in response.text
    finally:
        mount.unlink()
