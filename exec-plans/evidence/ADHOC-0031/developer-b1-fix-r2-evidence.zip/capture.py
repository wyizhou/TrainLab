from pathlib import Path
import difflib,hashlib,json,shutil,stat,subprocess
root=Path('/Volumes/DiskOther/Code/TrainLab');e=Path(__file__).resolve().parent;target=e/'green'
paths=['.gitignore']+subprocess.check_output(['git','ls-files','--others','--exclude-standard','source'],cwd=root,text=True).splitlines()
items=[]
for rel in sorted(paths):
 p=root/rel;t=target/rel;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,t)
 items.append(dict(path=rel,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=p.stat().st_size,mode=oct(stat.S_IMODE(p.stat().st_mode))))
sha=hashlib.sha256(json.dumps(items,sort_keys=True,separators=(',',':')).encode()).hexdigest()
report=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),branch=subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip(),items=items,product_file_count=len(items),product_aggregate_sha256=sha)
(target/'review-snapshot.json').write_text(json.dumps(report,indent=2));(e/'final-snapshot.json').write_text(json.dumps(report,indent=2))
baseline=json.loads((e/'baseline.json').read_text());old={i['path']:i for i in baseline['items']};new={i['path']:i for i in items}
changed=[p for p in new if p in old and old[p]!=new[p]];added=sorted(set(new)-set(old));removed=sorted(set(old)-set(new))
allowed=('source/skills/fit-store/scripts/','source/skills/_shared/scripts/trainlab/contracts/','source/tests/','source/schemas/')
allowedfiles={'source/skills/_shared/scripts/trainlab/check_architecture.py','source/skills/fit-store/README.md','source/README.md'}
assert all(p.startswith(allowed) or p in allowedfiles for p in changed+added+removed)
protected=json.loads((e/'protected.json').read_text());assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==sha for p,sha in protected.items())
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root)
assert report['head']==baseline['head'] and report['branch']==baseline['branch']
diff=''
for p in changed+added+removed:
 before=(e/'red'/p).read_text() if p in old else ''
 after=(root/p).read_text() if p in new else ''
 diff+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='baseline/'+p,tofile='current/'+p))
(e/'product.diff').write_text(diff)
summary=dict(changed=changed,added=added,removed=removed,aggregate_sha256=sha,product_files=len(items),protected_files_unchanged=len(protected),no_staged_files=True)
(e/'diff-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
