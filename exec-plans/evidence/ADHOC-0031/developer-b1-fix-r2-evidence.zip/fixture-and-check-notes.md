# 夹具与检查差异说明

## 没有改动的历史材料

历史53文件清单、压缩包、三个独立测试及independent_fit.py原文保留。红/绿测试副本的三份测试/编码器字节与原件相同；仅check_install.py把路径断言双方正规化，避免macOS /tmp与/private/tmp别名误报。README引用的公开解析参考须放副本根references/，最初误放source/references/，产生额外1条非产品失败；搬到正确层级后再跑，精确恢复12失败/79通过。

## 原有测试夹具的四处同步（断言未删除/放弱）

1. valid()原来把session字段3解释成heart_rate，Profile实际字段3为start_position_lat；改成session字段16/avg_heart_rate，并与record分开definition_index。仍测试相同最小默认字典、来源、事务/幂等/错误场景。
2. 默认123父组件闭包测试原来声称Profile存在derived字段；改用真实session.avg_cadence → avg_running_cadence，保留仅需要f1/f2及不输出records的原断言。
3. 多session夹具的第二lap仅有message_index，第二session缺timestamp/timer；依据公开Activity正文补齐四个必需时间字段，原多运动/两session/30秒断言不变。新增8种逐一删除必需字段反例证明不是规避完整性要求。
4. 25,001条DTO原序测试原来只在time_evidence提供时间，没有实际timestamp字段；补充字典及每行raw时间，原逐行SQL/JSON/顺序断言不变。新单因素删除实际时间字段/错时间/缺失单位等反例检查拒绝且五表保旧。

## 所有失败保留

- 原91项红灯：12失败/79通过；中途曾因参考文件复制层级错误得到13失败/78通过，原日志不覆盖。
- 新测试首次因一个多余括号收集退出2，修正测试语法后61项48失败/13通过；最终65项对旧安装包重放52失败/13通过。
- 首次实现自查mypy失败1项（字典类型推断过窄），补显式类型后通过；没有跳过静态检查。
- 实现自查157项及历史91项最终全通过，仍不构成独立验收。
