# 实际检查命令

## red-install

- cwd: `/tmp/trainlab-b1-r2-0vQR45/red`
- command: `uv sync --project source --python 3.12 --locked --extra dev --no-editable`
- exit: 0
- log: `red-install.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv'}`

## red-parity

- cwd: `/tmp/trainlab-b1-r2-0vQR45/red/evidence`
- command: `/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv/bin/python check_install.py`
- exit: 1
- log: `red-parity.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv'}`

## red-npm-ci

- cwd: `/tmp/trainlab-b1-r2-0vQR45/red/source/frontend`
- command: `npm ci --cache /tmp/trainlab-b1-r2-0vQR45/npm-cache`
- exit: 0
- log: `red-npm-ci.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv'}`

## red-frontend-build

- cwd: `/tmp/trainlab-b1-r2-0vQR45/red/source/frontend`
- command: `npm run build`
- exit: 0
- log: `red-frontend-build.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv'}`

## red-parity-resolved

- cwd: `/tmp/trainlab-b1-r2-0vQR45/red/evidence`
- command: `/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv/bin/python check_install.py`
- exit: 0
- log: `red-parity-resolved.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv'}`

## red-historical-91

- cwd: `/tmp/trainlab-b1-r2-0vQR45/red/evidence`
- command: `/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv/bin/python -m pytest test_independent.py test_followup.py test_final_boundaries.py -q -p no:cacheprovider --basetemp red-temp --junitxml red.xml --tb=short`
- exit: 1
- log: `red-historical-91.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv'}`

## red-historical-91-complete-materials

- cwd: `/tmp/trainlab-b1-r2-0vQR45/red/evidence`
- command: `/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv/bin/python -m pytest test_independent.py test_followup.py test_final_boundaries.py -q -p no:cacheprovider --basetemp red-complete-temp --junitxml red-complete.xml --tb=short`
- exit: 1
- log: `red-historical-91-complete-materials.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv'}`

## red-new-boundaries

- cwd: `/Volumes/DiskOther/Code/TrainLab/source`
- command: `/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv/bin/python -m pytest tests/fit/test_b1_r2.py -q -p no:cacheprovider --basetemp /tmp/trainlab-b1-r2-0vQR45/new-red-temp --junitxml /tmp/trainlab-b1-r2-0vQR45/new-red.xml --tb=short`
- exit: 2
- log: `red-new-boundaries.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv'}`

## red-new-boundaries-executable

- cwd: `/Volumes/DiskOther/Code/TrainLab/source`
- command: `/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv/bin/python -m pytest tests/fit/test_b1_r2.py -q -p no:cacheprovider --basetemp /tmp/trainlab-b1-r2-0vQR45/new-red-temp --junitxml /tmp/trainlab-b1-r2-0vQR45/new-red.xml --tb=short`
- exit: 1
- log: `red-new-boundaries-executable.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv'}`

## green-install

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green`
- command: `uv sync --project source --python 3.12 --locked --extra dev --no-editable`
- exit: 0
- log: `green-install.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-parity

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/evidence`
- command: `/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv/bin/python check_install.py`
- exit: 0
- log: `green-parity.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-pytest-initial

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/source`
- command: `/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv/bin/python -m pytest tests -q -p no:cacheprovider --basetemp /tmp/trainlab-b1-r2-0vQR45/green/evidence/product-temp --junitxml /tmp/trainlab-b1-r2-0vQR45/green/evidence/product.xml --tb=short`
- exit: 0
- log: `green-pytest-initial.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-ruff

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/source`
- command: `/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv/bin/python -m ruff check --no-cache .`
- exit: 0
- log: `green-ruff.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-npm-ci

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/source/frontend`
- command: `npm ci --cache /tmp/trainlab-b1-r2-0vQR45/npm-cache`
- exit: 0
- log: `green-npm-ci.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-mypy

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/source`
- command: `/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv/bin/python -m mypy -p trainlab -p tests --no-incremental`
- exit: 1
- log: `green-mypy.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-compile

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/source`
- command: `/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv/bin/python -m compileall -q skills schemas tests`
- exit: 0
- log: `green-compile.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-architecture

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/source`
- command: `/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv/bin/python -m trainlab.check_architecture`
- exit: 0
- log: `green-architecture.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-frontend-lint

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/source/frontend`
- command: `npm run lint`
- exit: 0
- log: `green-frontend-lint.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-frontend-typecheck

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/source/frontend`
- command: `npm run typecheck`
- exit: 0
- log: `green-frontend-typecheck.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-frontend-test

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/source/frontend`
- command: `npm run test`
- exit: 0
- log: `green-frontend-test.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-frontend-build

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/source/frontend`
- command: `npm run build`
- exit: 0
- log: `green-frontend-build.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-historical-91

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/evidence`
- command: `/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv/bin/python -m pytest test_independent.py test_followup.py test_final_boundaries.py -q -p no:cacheprovider --basetemp green-temp --junitxml green.xml --tb=short`
- exit: 0
- log: `green-historical-91.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## red-additional-same-message

- cwd: `/Volumes/DiskOther/Code/TrainLab/source`
- command: `/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv/bin/python -m pytest tests/fit/test_b1_r2.py -k 'same_message_accumulated or local_datetime_boundary' -q -p no:cacheprovider --tb=short`
- exit: 1
- log: `red-additional-same-message.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv'}`

## green-install-final

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green`
- command: `uv sync --project source --python 3.12 --locked --extra dev --no-editable --reinstall-package trainlab-source`
- exit: 0
- log: `green-install-final.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-parity-final

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/evidence`
- command: `/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv/bin/python check_install.py`
- exit: 0
- log: `green-parity-final.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-product-final

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/source`
- command: `/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv/bin/python -m pytest tests -q -p no:cacheprovider --basetemp /tmp/trainlab-b1-r2-0vQR45/green/evidence/product-final-temp --junitxml /tmp/trainlab-b1-r2-0vQR45/green/evidence/product-final.xml --tb=short`
- exit: 0
- log: `green-product-final.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-ruff-final

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/source`
- command: `/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv/bin/python -m ruff check --no-cache .`
- exit: 0
- log: `green-ruff-final.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## red-final-65-baseline-control

- cwd: `/Volumes/DiskOther/Code/TrainLab/source`
- command: `/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv/bin/python -m pytest tests/fit/test_b1_r2.py -q -p no:cacheprovider --basetemp /tmp/trainlab-b1-r2-0vQR45/red-final65-temp --junitxml /tmp/trainlab-b1-r2-0vQR45/red-final65.xml --tb=short`
- exit: 1
- log: `red-final-65-baseline-control.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/red/evidence/venv'}`

## green-git-diff-check

- cwd: `/Volumes/DiskOther/Code/TrainLab`
- command: `git diff --check`
- exit: 0
- log: `green-git-diff-check.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-git-index-check

- cwd: `/Volumes/DiskOther/Code/TrainLab`
- command: `git diff --cached --exit-code`
- exit: 0
- log: `green-git-index-check.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-git-status

- cwd: `/Volumes/DiskOther/Code/TrainLab`
- command: `git status --short`
- exit: 0
- log: `green-git-status.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-mypy-final

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/source`
- command: `/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv/bin/python -m mypy -p trainlab -p tests --no-incremental`
- exit: 0
- log: `green-mypy-final.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-compile-final

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/source`
- command: `/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv/bin/python -m compileall -q skills schemas tests`
- exit: 0
- log: `green-compile-final.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-architecture-final

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/source`
- command: `/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv/bin/python -m trainlab.check_architecture`
- exit: 0
- log: `green-architecture-final.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-historical-91-final

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green/evidence`
- command: `/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv/bin/python -m pytest test_independent.py test_followup.py test_final_boundaries.py -q -p no:cacheprovider --basetemp green-final-temp --junitxml green-final.xml --tb=short`
- exit: 0
- log: `green-historical-91-final.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

## green-hashes-after

- cwd: `/tmp/trainlab-b1-r2-0vQR45/green`
- command: `/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv/bin/python evidence/check_snapshot.py after`
- exit: 0
- log: `green-hashes-after.log`
- env: `{'UV_CACHE_DIR': '/private/tmp/trainlab-b1-r2-0vQR45/uv-cache', 'UV_PROJECT_ENVIRONMENT': '/private/tmp/trainlab-b1-r2-0vQR45/green/evidence/venv'}`

