from pathlib import Path
import hashlib,json,shlex,subprocess,zipfile
root=Path('/Volumes/DiskOther/Code/TrainLab');e=Path(__file__).resolve().parent
snapshot=json.loads((e/'final-snapshot.json').read_text());baseline=json.loads((e/'baseline.json').read_text())
for item in snapshot['items']:
 for base in (root,e/'green'):
  assert hashlib.sha256((base/item['path']).read_bytes()).hexdigest()==item['sha256']
for item in baseline['items']:
 assert hashlib.sha256((e/'red'/item['path']).read_bytes()).hexdigest()==item['sha256']
for name in ('test_independent.py','test_followup.py','test_final_boundaries.py','independent_fit.py'):
 for phase in ('red','green'):
  assert (e/phase/'evidence'/name).read_bytes()==(e/'history/validator/evidence'/name).read_bytes()
protected=json.loads((e/'protected.json').read_text())
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in protected.items())
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==snapshot['head']
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()==snapshot['branch']
rows=[json.loads(l) for l in (e/'commands.jsonl').read_text().splitlines()]
(e/'commands.md').write_text('# 实际检查命令\n\n'+''.join(f"## {r['phase']}-{r['label']}\n\n- cwd: `{r['cwd']}`\n- command: `{shlex.join(r['command'])}`\n- exit: {r['exit_code']}\n- log: `{Path(r['log']).name}`\n- env: `{r['env']}`\n\n" for r in rows))
parity=json.loads((e/'green-parity-final.log').read_text())
receipt=dict(head=snapshot['head'],branch=snapshot['branch'],snapshot_files=len(snapshot['items']),snapshot_sha256=snapshot['product_aggregate_sha256'],installed_files=len(parity['modules_and_schemas']),installed_packages=len(parity['versions']),protected_unchanged=len(protected),independent_test_scripts_unchanged=True,no_staged_files=True)
(e/'final-audit.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
selected=set()
for p in e.iterdir():
 if p.is_file() and p.suffix in {'.py','.md','.json','.jsonl','.log','.xml','.diff','.txt'}:selected.add(p)
for phase,manifest in [('red',baseline),('green',snapshot)]:
 for i in manifest['items']:selected.add(e/phase/i['path'])
 selected.add(e/phase/'review-snapshot.json')
 for p in (e/phase/'evidence').iterdir():
  if p.is_file() and p.suffix in {'.py','.log','.json','.xml'}:selected.add(p)
 for d in ('public-sources','references','source/skills/local-web/web'):
  for p in (e/phase/d).rglob('*'):
   if p.is_file():selected.add(p)
for directory in (e/'red-final65-temp',e/'green/evidence/product-final-temp',e/'green/evidence/green-final-temp',e/'red/evidence/red-complete-temp'):
 for p in directory.rglob('*'):
  if p.is_file() and p.suffix in {'.fit','.db'} and p.stat().st_size<=1024*1024:selected.add(p)
with zipfile.ZipFile(e/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(selected):z.write(p,p.relative_to(e))
with zipfile.ZipFile(e/'evidence.zip') as z:assert z.testzip() is None
archive=dict(path=str(e/'evidence.zip'),sha256=hashlib.sha256((e/'evidence.zip').read_bytes()).hexdigest(),bytes=(e/'evidence.zip').stat().st_size,files=len(selected),omissions='Rebuildable environments/cache/build intermediates and synthetic databases larger than 1MiB omitted; all raw temp paths remain on disk.')
(e/'archive.json').write_text(json.dumps(archive,indent=2));print(json.dumps(archive,indent=2))
