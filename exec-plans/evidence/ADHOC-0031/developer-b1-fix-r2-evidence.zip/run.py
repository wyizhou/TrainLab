import json, os, pathlib, subprocess, sys, time
root=pathlib.Path(__file__).resolve().parent
phase,label,cwd,*cmd=sys.argv[1:]
env=os.environ.copy();env.update(UV_CACHE_DIR=str(root/'uv-cache'),UV_PROJECT_ENVIRONMENT=str(root/phase/'evidence/venv'))
start=time.time()
p=subprocess.run(cmd,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
log=root/f'{phase}-{label}.log';log.write_text(p.stdout)
row=dict(phase=phase,label=label,cwd=cwd,command=cmd,env={k:env[k] for k in ('UV_CACHE_DIR','UV_PROJECT_ENVIRONMENT')},exit_code=p.returncode,seconds=time.time()-start,log=str(log))
with (root/'commands.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
print(json.dumps(row));print(p.stdout[-8000:]);sys.exit(p.returncode)
