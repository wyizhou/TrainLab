# 本轮修复前分析

基线53/53文件SHA/大小/权限、产品集合、分支HEAD与索引均匹配；历史zip SHA/CRC核对通过。原材料完整读取，历史计数不重置：B1尝试2；公共合同累计尝试3（此前两种方法未闭合）。只在授权路径处理001/002/003，004/005/006保持回归。

- 001：协议层将255当未知合法字段；完整性层只计消息存在。改为协议定义有效性与必需消息内容分别验证，session/lap检查四个必需时间字段的存在及编码类型，而合法null/relative、record缺timestamp但有实际采样字段仍保留。空record/仅timestamp不冒充采样；不以某个样例名称判断。原多session单元夹具有不完整摘要，将按公开协议补齐夹具，保留原功能断言并补负向测试，不放宽合同。
- 累积器遗漏数组：按原始数组顺序逐个更新累计基点，invalid不重置，不改变单位，链隔离。date_time/local_date_time是数值域边界而不是枚举，保留原整数；增加下界前后/最大值、直接数组→压缩→直接→压缩/invalid/跨链场景。
- 002：从目录名字/扩展枚举转为目录职责分类＋可执行文件识别；覆盖根和Skill/scripts外运行文件、tools脚本/shebang，保留前端配置、tests、schema资源等合法路径。AST按导入别名追踪sys.path对象的写操作/方法修改，允许只读sys.path，不再将所有属性读取误判为补丁。
- 003：不是再加一个名字if；采用共享SDK Profile身份解析（依赖引用，不复制Profile影子字典），在Definition和Message/字段集合建立canonical message、field、chain、definition、source对应；timestamp按字段号253连接原值、raw字典、time_evidence及SQL。拒绝同时改名字、互换定义和移除时间字段伪造missing等矛盾，并以真实仓储五表保旧验证。保留未知厂商消息number/name=null与Developer来源身份。

安装工具首次成功。归档check_install.py的路径断言把macOS /tmp与/private/tmp当不同目录；实际文件相同，属于检查脚本路径适配，不是环境故障。保留原脚本并仅对副本改成resolve()后比较，记录原失败日志red-parity.log。历史三份业务测试原文不改。

尚未修改产品实现。下一步保存基线91项红灯，新增必要边界红灯，再进行本轮实现/完整自查；自查不等于独立验收。
