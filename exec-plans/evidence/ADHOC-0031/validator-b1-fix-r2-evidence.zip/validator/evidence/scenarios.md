# 独立复验场景与实际状态

## 已执行

| 场景 | 要求/类型 | 输入与实际入口 | 预期 | 实际/退出结果 | 证据 |
|---|---|---|---|---|---|
| SNAP-01 | 固定版本/正常 | 按review-snapshot.json逐文件读取56文件，另读2份公开资料 | 每份SHA/大小/权限一致 | 前后均56/56匹配，公开资料SHA匹配；exit 0 | 01-snapshot.log、12-snapshot.log、snapshot-before.json、snapshot-after.json |
| ENV-01 | 安装前置/正常 | 独立evidence环境，uv sync --project source --python 3.12 --locked --extra dev --no-editable | 完成安装，再逐模块/Schema匹配 | **未完成**：外层工具200秒超时；uv退出码未取得 | 02-install.log、install-blocker.json |
| ENV-02 | 阻塞确认/只读 | 仅按本副本路径过滤进程；evidence/venv的importlib.metadata分发清单 | 核实安装是否仍进行或已可用 | 无匹配安装进程；分发清单[]；exit 0 | 03-install-process-observation.log |
| FE-01 | U31-01/GATE-01/正常 | source/frontend：npm ci、lint、typecheck、test、build | 锁定依赖安装、静态检查、现有3测试与生产构建成功 | 5命令均exit 0；3测试通过，输出批准web目录 | 04～08日志 |
| FE-02 | U31-01/独立正常 | evidence/check_frontend_artifacts.py读取实际生产index和资产 | React root存在；每个引用限定/assets/且实际存在非空JS/CSS；无其他类型或符号链接产物 | 2引用与3产物一致；exit 0 | 10-frontend-artifacts.log、frontend-artifacts.json |
| FE-03 | 依赖证据/正常 | npm ls --depth=0 | 顶层分发无缺失错误 | exit 0；实际版本留原始日志 | 11-frontend-dependencies.log |
| PY-01 | GATE-01/语法 | 已创建的Python3.12解释器执行compileall，不导入受审包、不依赖未安装分发 | 源码/Schema包/测试语法编译成功 | exit 0 | 09-compileall.log |

FE-02是独立产物检查，不是独立HTTP/浏览器验收；FE-01为原有测试，不能冒充B1独立FIT场景。

## 已设计但因ENV-01未执行

以下只是待验证输入设计；没有生成FIT/SQLite、没有成功基线，没有实际结果，不计入通过数。

| 编号 | 类型 | 独立输入/步骤 | 预期与验收关键点 | 状态 |
|---|---|---|---|---|
| V31-B1-001/A | 正常 | 自写协议编码器，独立CRC，file_id→record×4097→lap→session→activity；按固定Profile核字段编号/scale；间隔[0,0,7,1,…] | 默认import_fit_file真实解码→库→get_activity_facts；4097行原顺序，无合并/补点；物理值与原生/派生身份准确 | 未执行 |
| V31-B1-001/B | 错误 | 从有效基线分别单改CRC、data_size、未定义local message、字段255、空session/lap/record、删必需尾部，坏链尾 | 每例实际入口拒绝；新库不造活动行、已有五表全保旧 | 未执行 |
| V31-B1-001/C | 边界 | timestamp为0x0fffffff、0x10000000、invalid、缺失，0/null采样、developer-only；大小端及32秒压缩回绕 | 数值268435456不转枚举；相对/缺失不伪造UTC；合法采样保留 | 未执行 |
| V31-B1-001/D | 边界 | HR event_timestamp直接数组[10240,11264]后跟12位组件[0,1024]，跨Definition和跨链分别设置；核Profile累计/scale | 同链按1024 scale及4096回绕应接12、13秒；不得只取数组首项；链状态不得串扰 | 未执行 |
| V31-B1-001/E | 正常 | 未知消息/字段、Developer同名不同来源和重定义、session running+cycling、lap/split/set；直接和展开混合 | 不丢未知可解码结构；来源与字典不串；多运动不授予整体running；原生分段全部保留 | 未执行 |
| V31-B1-002 | 正常/错误 | 先离源码根导入已安装包并逐文件比SHA；隔离完整副本逐次增加sys.path赋值/切片/别名、tools shell、根运行文件；正向文档/测试/前端/读取sys.path | 正常包及合法结构通过；每种违规明确拒绝；不增额外目录约束 | 未执行 |
| V31-B1-003 | 正常/错误 | 先用真实解码DTO成功保存；每例新合法基线后仅变record实际timestamp、字典/消息name、source/definition身份、component引用、非有限值/结构键 | 变异入口import_activity/replace_activity拒绝且全五表逐行不变；有效未知身份、标准subfield/component不误拒绝 | 未执行 |
| V31-B1-004 | 正常/边界 | 对含Developer、summary组件和sensor-only字段的真实文件读get_activity_facts，独立计算传递引用闭包 | 仅7个批准顶层字段；全文123不裁剪；无records、fit_path、整体sensors；最少字典与父引用/来源完整 | 未执行 |
| V31-B1-005 | 正常 | 相同字节另文件名、另parsed_at再次普通导入；事先合成两报告/config | 五表全部字段、原路径/时间与两份文件字节全不变 | 未执行 |
| V31-B1-006 | 正常/错误 | 维护入口依次试SHA不符、坏解析、无变化、有报告变化冲突、无报告合法更新、插入子行触发失败 | 先SHA及完整解析；不变不写；冲突/失败五表与原件全保旧；合法维护原子更新且周报/config保留 | 未执行 |
| B0/B1-DB | 正常/边界 | SQLite五表列数、主外键；read_view与写门跨线程等待/释放；rollback journal；只读不存在库 | 12/4/3/3/3、实际外键、视图期间等待、读取不造库 | 未执行 |
| B0-Web | 正常/错误 | 已安装包创建FastAPI应用，用生产资源请求health、index/assets、缺路由、路径穿越/符号链接 | 实际合同与HTTP状态正确；静态根不泄露合成私密文件 | 未执行 |

## 证据边界

安装没有完成，因此未进行安装模块/Schema逐字节核对，也未运行pytest/Ruff/mypy/architecture入口。没有以源码sys.path补丁、旧wheel、DTO替身或已有断言替代实际解码。不把手工读到的防护分支判成已修复。没有确认产品缺陷，也没有证明V31-B1-001～006已修复或无退化。
