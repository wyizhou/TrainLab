import datetime, json, os, pathlib, subprocess, sys
ROOT = pathlib.Path(__file__).resolve().parent.parent
name, cwd, *cmd = sys.argv[1:]
env = os.environ.copy()
env.update(UV_PROJECT_ENVIRONMENT=str(ROOT/'evidence/venv'), UV_CACHE_DIR=str(ROOT/'evidence/uv-cache'), PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(ROOT/'evidence/tmp'), npm_config_cache=str(ROOT/'evidence/npm-cache'))
(ROOT/'evidence/tmp').mkdir(exist_ok=True)
log = ROOT/'evidence'/f'{name}.log'
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with log.open('wb') as out:
    result = subprocess.run(cmd, cwd=ROOT/cwd, env=env, stdout=out, stderr=subprocess.STDOUT)
entry = dict(name=name, cwd=str((ROOT/cwd).resolve()), command=cmd, started=started, ended=datetime.datetime.now(datetime.timezone.utc).isoformat(), exit_code=result.returncode, log=str(log.relative_to(ROOT)))
with (ROOT/'evidence/commands.jsonl').open('a') as out:
    out.write(json.dumps(entry)+'\n')
print(json.dumps(entry))
print(log.read_text()[-12000:])
sys.exit(result.returncode)
