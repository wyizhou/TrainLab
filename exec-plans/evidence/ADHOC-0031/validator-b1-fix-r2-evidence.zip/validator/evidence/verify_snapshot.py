import hashlib,json,pathlib,stat,sys
root=pathlib.Path(__file__).resolve().parent.parent
snapshot=json.loads((root/'review-snapshot.json').read_text())
items=[]
for item in snapshot['items']:
    p=root/item['path']; b=p.read_bytes()
    actual=dict(path=item['path'],sha256=hashlib.sha256(b).hexdigest(),size=len(b),mode=oct(stat.S_IMODE(p.stat().st_mode)))
    assert actual==item,(actual,item)
    items.append(actual)
public={}
for name,expected in [('protocol-content.txt','67d986e4649292edbee0c317c7310d22352368a79f6af5e8067a203b6f99da93'),('activity-content.txt','94d79baa80f554ec84d7d45076eb63d29d865ce6a93d7597101a39ae921e0b30')]:
    h=hashlib.sha256((root/'public-sources'/name).read_bytes()).hexdigest();assert h==expected; public[name]=h
# The manifest's aggregate encoding is not declared; verify every member rather than assume its encoding.
result=dict(items=items,verified_count=len(items),manifest_aggregate=snapshot['product_aggregate_sha256'],manifest_sha256=hashlib.sha256((root/'review-snapshot.json').read_bytes()).hexdigest(),public_sources=public,git_metadata_present=(root/'.git').exists())
(root/'evidence'/f'snapshot-{sys.argv[1]}.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
