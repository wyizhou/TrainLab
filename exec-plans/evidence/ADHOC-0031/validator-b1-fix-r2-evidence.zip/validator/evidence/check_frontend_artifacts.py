import hashlib,json,pathlib,re
root=pathlib.Path(__file__).resolve().parent.parent
web=root/'source/skills/local-web/web'
index=(web/'index.html').read_text()
refs=re.findall(r'(?:src|href)="([^"]+)"',index)
assert refs, 'no production assets'
for ref in refs:
    assert ref.startswith('/assets/') and '..' not in ref, ref
    path=web/ref.lstrip('/')
    assert path.is_file() and path.stat().st_size>0,ref
assert '<div id="root"></div>' in index
files=[]
for p in sorted(web.rglob('*')):
    if not p.is_file(): continue
    assert p.suffix in {'.html','.js','.css'},p
    assert not p.is_symlink(),p
    files.append(dict(path=str(p.relative_to(root)),size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
assert any(f['path'].endswith('.js') for f in files)
assert any(f['path'].endswith('.css') for f in files)
result={'expected':'Production index mounts React root; every referenced JS/CSS asset exists under approved web/assets; no non-web file or symlink generated.','actual':{'references':refs,'files':files},'scope':'Build artifacts only; does not prove HTTP routing or private-path isolation.'}
(root/'evidence/frontend-artifacts.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
