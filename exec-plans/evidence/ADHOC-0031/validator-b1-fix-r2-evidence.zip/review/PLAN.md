# 隔离复验材料索引

本目录仅为B0相关前置及B1当前固定复验副本，不是业务工作区或另一份产品总计划。

- 客观要求和已审核拆解：requirements.md
- 固定产品版本：review-snapshot.json
- 本次任务：validation-request.md
- 角色规则：AGENTS.md、subagent-templates/validator.md

未提供开发者报告、历史裁决或失败次数；产品实现/说明均为受审材料，不是需求来源。
