from __future__ import annotations

import sys
from pathlib import Path

SOURCE_ROOT = Path(__file__).resolve().parents[1]
if SOURCE_ROOT.as_posix() not in sys.path:
    sys.path.insert(0, SOURCE_ROOT.as_posix())

from trainlab.contracts.interfaces import (
    UNCONFIGURED_POLICIES,
    PendingDecision,
    validate_schema_examples,
)
from trainlab.contracts.paths import WEB_STATIC_DIR, validate_static_mount
from trainlab.contracts.schema import BUSINESS_TABLES, SYSTEM_TABLES, table_contracts


def main() -> int:
    root = Path.cwd()
    forbidden = [root / "source" / "src", root / "source" / "index.py"]
    existing_forbidden = [path.as_posix() for path in forbidden if path.exists()]
    if existing_forbidden:
        print(f"forbidden legacy paths exist: {existing_forbidden}", file=sys.stderr)
        return 1

    validate_static_mount(WEB_STATIC_DIR)
    contracts = table_contracts()
    business = tuple(table.name for table in contracts if table.business_table)
    system = tuple(table.name for table in contracts if not table.business_table)
    if business != BUSINESS_TABLES:
        print(f"business table mismatch: {business}", file=sys.stderr)
        return 1
    if system != SYSTEM_TABLES:
        print(f"system table mismatch: {system}", file=sys.stderr)
        return 1
    if set(UNCONFIGURED_POLICIES) != {
        PendingDecision.ACTIVITY_BATCH_AND_BACKFILL,
        PendingDecision.WEEKLY_TRIGGER_AND_MISSING_REPORTS,
        PendingDecision.RUNNING_RECORDS_QUOTA,
    }:
        print("unconfigured policy set mismatch", file=sys.stderr)
        return 1
    validate_schema_examples()

    print("B0 static contract check passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
