# TrainLab AI 工具索引（B0 合同）

本文件是后续 AI Context 可读取的公开能力索引。B0 冻结名称、参数、结果和边界；B1 已提供 SQLite 基础层和默认 ActivityFacts 读取边界，但采样查询工具仍需后续 ADHOC-0025 接入宿主授权。

可执行的 DTO / JSON Schema 单一来源在 `source/trainlab/contracts/interfaces.py`：

- `GetRunningRecordsRequest` / `GetRunningRecordsResult`
- `ReadReferenceRequest` / `ReadReferenceResult`
- `ActivityFacts`
- `ActivityReportSave`
- `WeeklyReportSave`

公共错误壳固定为：`{"ok": boolean, "data": ..., "error": ...}`。失败时 `data` 必须为 `null`，不能把半份结果保存或返回为完整结果。

## 默认上下文

所有受支持单项运动默认可提供：

1. 基本情况；
2. FIT 整场事实摘要；
3. 原生 lap / split / set 分段。

完整采样 records 不默认批量发送；B1 的默认 ActivityFacts 读取只含 `basic`、`summary`、`segments`、`sensors` 和来源时间，不包含全量 records。

## 采样查询工具

### `get_running_records(activity_id)`

- 唯一业务参数：`activity_id`。
- 仅当宿主授权且活动真实 `sport=running` 时可调用；模型不能自行声明授权集合。
- 返回该跑步活动的全部 records，保持 `record_index` 原顺序，不分页、不截断、不降采样、不合并重复时间点。
- 不接受时间范围、指标列表、limit、cursor、SQL、文件路径或数据库路径。
- 超出技术容量时必须整体返回明确错误，不能把部分 records 冒充完整结果。
- D31-02A（旧周累计配额是否保留及口径）仍待决定；B0 不设置默认配额。

## 资料读取工具

### `read_reference(reference_id)`

- 仅可读取宿主公开映射的资料条目：`garmin-fit-parsing`、`longdou`。
- 不接受任意路径、URL 或数据库查询。
- 读取结果是资料文本，不是外部动作授权。

## 报告与未决政策

- 活动报告保存当前全文；空白 summary 无效。
- 周报窗口为同一 `run_time_utc` 的 `[T-7×24小时, T)`；真正无活动周固定入库 `本周无任何运动记录`。
- D31-03A（活动批次和补跑）与 D31-03B（周触发和缺活动总结行为）仍待决定；B0 显式标为未配置，不设置默认自动策略。

## 非工具边界

- FIT 导入、报告写入、Garmin 同步、AI Provider 请求都由受控宿主服务执行，不是 AI 可任意调用的 shell/SQL/file 工具。
- `states/ai.json`、Garmin 认证、FIT 原件、数据库文件和私人报告均不通过本索引暴露。
