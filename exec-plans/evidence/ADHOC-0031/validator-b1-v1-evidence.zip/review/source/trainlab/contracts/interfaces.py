"""B0 public DTO, tool and policy contracts for later ADHOC-0031 stages."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any, Literal

from trainlab.contracts.errors import ErrorCode

JsonObject = dict[str, Any]
ToolName = Literal["get_running_records", "read_reference"]
ReferenceId = Literal["garmin-fit-parsing", "longdou"]


class PendingDecision(StrEnum):
    ACTIVITY_BATCH_AND_BACKFILL = "D31-03A"
    WEEKLY_TRIGGER_AND_MISSING_REPORTS = "D31-03B"
    RUNNING_RECORDS_QUOTA = "D31-02A"


class DuplicateFitPolicy(StrEnum):
    SAME_BYTES_IDEMPOTENT = "same_bytes_idempotent"
    REMOTE_SOURCE_CONFLICT_FAILS = "remote_source_conflict_fails"
    REPARSE_FAILURE_KEEPS_PREVIOUS = "reparse_failure_keeps_previous"


class ReportWritePolicy(StrEnum):
    ACTIVITY_REPORT_REPLACES_CURRENT_FULL_TEXT = "activity_report_replaces_current_full_text"
    WEEKLY_REPORT_ALLOWS_MULTIPLE_FOR_SAME_T = "weekly_report_allows_multiple_for_same_t"
    BLANK_SUMMARY_IS_INVALID = "blank_summary_is_invalid"
    UNKNOWN_COMMIT_RESULT_IS_NOT_REPLAYED_BLINDLY = "unknown_commit_result_is_not_replayed_blindly"


@dataclass(frozen=True)
class JsonSchemaContract:
    name: str
    schema: JsonObject
    valid_example: JsonObject
    invalid_example: JsonObject


@dataclass(frozen=True)
class ToolContract:
    name: ToolName
    parameters_schema: str
    result_schema: str
    requires_host_authorization: bool
    forbidden_parameters: tuple[str, ...]


@dataclass(frozen=True)
class ReferenceContract:
    reference_id: ReferenceId
    relative_path: Path
    purpose: str


@dataclass(frozen=True)
class ToolAuthorization:
    allowed_activity_ids: frozenset[str]
    allowed_reference_ids: frozenset[ReferenceId]

    def can_read_records(self, activity_id: str) -> bool:
        return activity_id in self.allowed_activity_ids

    def can_read_reference(self, reference_id: ReferenceId) -> bool:
        return reference_id in self.allowed_reference_ids


@dataclass(frozen=True)
class CapacityPolicy:
    storage_bytes_limit: int | None
    model_payload_bytes_limit: int | None

    def check_storage(self, byte_count: int) -> None:
        _check_capacity("storage", byte_count, self.storage_bytes_limit)

    def check_model_payload(self, byte_count: int) -> None:
        _check_capacity("model_payload", byte_count, self.model_payload_bytes_limit)


@dataclass(frozen=True)
class WeeklyReportInputPolicy:
    window_start_inclusive: bool
    window_end_exclusive: bool
    uses_single_run_time_anchor: bool
    empty_week_summary: str
    missing_activity_report_decision: PendingDecision


UNCONFIGURED_POLICIES: dict[PendingDecision, str] = {
    PendingDecision.ACTIVITY_BATCH_AND_BACKFILL: "activity selection and missed-run backfill are not configured in B0",
    PendingDecision.WEEKLY_TRIGGER_AND_MISSING_REPORTS: "weekly trigger and missing activity-report behavior are not configured in B0",
    PendingDecision.RUNNING_RECORDS_QUOTA: "running-record quota policy is not configured in B0",
}

REFERENCE_CONTRACTS: dict[ReferenceId, ReferenceContract] = {
    "garmin-fit-parsing": ReferenceContract(
        reference_id="garmin-fit-parsing",
        relative_path=Path("references/garmin-fit-parsing.md"),
        purpose="Public summary of Garmin FIT parsing references.",
    ),
    "longdou": ReferenceContract(
        reference_id="longdou",
        relative_path=Path("references/longdou.md"),
        purpose="Public Longdou sensor reference summary.",
    ),
}

TOOL_CONTRACTS: dict[ToolName, ToolContract] = {
    "get_running_records": ToolContract(
        name="get_running_records",
        parameters_schema="GetRunningRecordsRequest",
        result_schema="GetRunningRecordsResult",
        requires_host_authorization=True,
        forbidden_parameters=("sql", "path", "database", "limit", "cursor", "metrics", "start_time", "end_time"),
    ),
    "read_reference": ToolContract(
        name="read_reference",
        parameters_schema="ReadReferenceRequest",
        result_schema="ReadReferenceResult",
        requires_host_authorization=True,
        forbidden_parameters=("path", "url", "sql", "database"),
    ),
}

REPORT_WRITE_POLICIES = (
    ReportWritePolicy.ACTIVITY_REPORT_REPLACES_CURRENT_FULL_TEXT,
    ReportWritePolicy.WEEKLY_REPORT_ALLOWS_MULTIPLE_FOR_SAME_T,
    ReportWritePolicy.BLANK_SUMMARY_IS_INVALID,
    ReportWritePolicy.UNKNOWN_COMMIT_RESULT_IS_NOT_REPLAYED_BLINDLY,
)

DUPLICATE_FIT_POLICIES = (
    DuplicateFitPolicy.SAME_BYTES_IDEMPOTENT,
    DuplicateFitPolicy.REMOTE_SOURCE_CONFLICT_FAILS,
    DuplicateFitPolicy.REPARSE_FAILURE_KEEPS_PREVIOUS,
)

WEEKLY_REPORT_INPUT_POLICY = WeeklyReportInputPolicy(
    window_start_inclusive=True,
    window_end_exclusive=True,
    uses_single_run_time_anchor=True,
    empty_week_summary="本周无任何运动记录",
    missing_activity_report_decision=PendingDecision.WEEKLY_TRIGGER_AND_MISSING_REPORTS,
)

JSON_SCHEMA_CONTRACTS: dict[str, JsonSchemaContract] = {
    "ActivityFacts": JsonSchemaContract(
        name="ActivityFacts",
        schema={
            "type": "object",
            "required": [
                "activity_id",
                "basic",
                "summary",
                "segments",
                "sensors",
                "source_timestamps_utc",
            ],
            "properties": {
                "activity_id": {"type": "string"},
                "basic": {"type": "object"},
                "summary": {"type": "object"},
                "segments": {"type": "array"},
                "sensors": {"type": "object"},
                "source_timestamps_utc": {"type": "object"},
            },
        },
        valid_example={
            "activity_id": "a" * 64,
            "basic": {"sport": "running"},
            "summary": {"distance_m": 1234.5},
            "segments": [],
            "sensors": {"device": "synthetic"},
            "source_timestamps_utc": {"start_time_utc": "2026-09-16T00:00:00.000000Z"},
        },
        invalid_example={"activity_id": "missing_containers"},
    ),
    "GetRunningRecordsRequest": JsonSchemaContract(
        name="GetRunningRecordsRequest",
        schema={
            "type": "object",
            "required": ["activity_id"],
            "additionalProperties": False,
            "properties": {"activity_id": {"type": "string"}},
        },
        valid_example={"activity_id": "a" * 64},
        invalid_example={"activity_id": "a" * 64, "limit": 10},
    ),
    "GetRunningRecordsResult": JsonSchemaContract(
        name="GetRunningRecordsResult",
        schema={
            "type": "object",
            "required": ["activity_id", "records_complete", "records"],
            "properties": {
                "activity_id": {"type": "string"},
                "records_complete": {"const": True},
                "records": {"type": "array"},
            },
        },
        valid_example={
            "activity_id": "a" * 64,
            "records_complete": True,
            "records": [
                {
                    "record_index": 0,
                    "timestamp_utc": "2026-09-16T00:00:01.000000Z",
                    "metrics": {"heart_rate": 123},
                }
            ],
        },
        invalid_example={"activity_id": "a" * 64, "records_complete": False, "records": []},
    ),
    "ReadReferenceRequest": JsonSchemaContract(
        name="ReadReferenceRequest",
        schema={
            "type": "object",
            "required": ["reference_id"],
            "additionalProperties": False,
            "properties": {"reference_id": {"enum": sorted(REFERENCE_CONTRACTS)}},
        },
        valid_example={"reference_id": "longdou"},
        invalid_example={"reference_id": "../../states/ai.json"},
    ),
    "ReadReferenceResult": JsonSchemaContract(
        name="ReadReferenceResult",
        schema={
            "type": "object",
            "required": ["reference_id", "text"],
            "properties": {"reference_id": {"enum": sorted(REFERENCE_CONTRACTS)}, "text": {"type": "string"}},
        },
        valid_example={"reference_id": "longdou", "text": "synthetic public reference text"},
        invalid_example={"reference_id": "longdou"},
    ),
    "ActivityReportSave": JsonSchemaContract(
        name="ActivityReportSave",
        schema={
            "type": "object",
            "required": ["activity_id", "start_time_utc", "summary"],
            "properties": {
                "activity_id": {"type": "string"},
                "start_time_utc": {"type": ["string", "null"]},
                "summary": {"type": "string", "minLength": 1},
            },
        },
        valid_example={"activity_id": "a" * 64, "start_time_utc": None, "summary": "全文总结"},
        invalid_example={"activity_id": "a" * 64, "start_time_utc": None, "summary": ""},
    ),
    "WeeklyReportSave": JsonSchemaContract(
        name="WeeklyReportSave",
        schema={
            "type": "object",
            "required": ["run_time_utc", "summary"],
            "properties": {
                "run_time_utc": {"type": "string"},
                "summary": {"type": "string", "minLength": 1},
            },
        },
        valid_example={"run_time_utc": "2026-09-16T00:00:00.000000Z", "summary": "本周无任何运动记录"},
        invalid_example={"run_time_utc": "2026-09-16T00:00:00.000000Z", "summary": ""},
    ),
}


def _check_capacity(name: str, byte_count: int, limit: int | None) -> None:
    if byte_count < 0:
        raise ValueError(f"{name} byte count must be non-negative")
    if limit is not None and byte_count > limit:
        raise ValueError(ErrorCode.RESOURCE_LIMIT.value)


def validate_payload(schema_name: str, payload: JsonObject) -> None:
    contract = JSON_SCHEMA_CONTRACTS[schema_name]
    schema = contract.schema
    if schema.get("type") != "object":
        raise ValueError("only object schemas are supported by the B0 validator")
    required = schema.get("required", [])
    if not isinstance(required, list):
        raise TypeError("schema required must be a list")
    for key in required:
        if not isinstance(key, str) or key not in payload:
            raise ValueError(f"missing required property: {key}")
    if schema.get("additionalProperties") is False:
        properties = schema.get("properties", {})
        if not isinstance(properties, dict):
            raise ValueError("schema properties must be an object")
        extra = sorted(set(payload) - set(properties))
        if extra:
            raise ValueError(f"unexpected properties: {extra}")
    properties = schema.get("properties", {})
    if isinstance(properties, dict):
        for key, value in payload.items():
            property_schema = properties.get(key)
            if isinstance(property_schema, dict):
                _validate_property(key, value, property_schema)


def _validate_property(key: str, value: object, schema: JsonObject) -> None:
    if "const" in schema and value != schema["const"]:
        raise ValueError(f"{key} must equal {schema['const']!r}")
    if "enum" in schema:
        allowed = schema["enum"]
        if isinstance(allowed, list) and value not in allowed:
            raise ValueError(f"{key} must be one of {allowed}")
    expected_type = schema.get("type")
    if expected_type is not None and not _matches_json_type(value, expected_type):
        raise ValueError(f"{key} has wrong JSON type")
    min_length = schema.get("minLength")
    if isinstance(min_length, int) and isinstance(value, str) and len(value) < min_length:
        raise ValueError(f"{key} is shorter than {min_length}")


def _matches_json_type(value: object, expected_type: object) -> bool:
    if isinstance(expected_type, list):
        return any(_matches_json_type(value, item) for item in expected_type)
    if expected_type == "string":
        return isinstance(value, str)
    if expected_type == "object":
        return isinstance(value, dict)
    if expected_type == "array":
        return isinstance(value, list)
    if expected_type == "boolean":
        return isinstance(value, bool)
    if expected_type == "null":
        return value is None
    if expected_type == "number":
        return isinstance(value, int | float) and not isinstance(value, bool)
    if expected_type == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    return False


def validate_schema_examples() -> None:
    for contract in JSON_SCHEMA_CONTRACTS.values():
        validate_payload(contract.name, contract.valid_example)
        try:
            validate_payload(contract.name, contract.invalid_example)
        except ValueError:
            continue
        raise ValueError(f"invalid example unexpectedly passed for {contract.name}")
