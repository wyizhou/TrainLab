"""SQLite persistence for parsed FIT activities and record messages."""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from datetime import UTC, datetime
from pathlib import Path

from trainlab.contracts.errors import ErrorCode
from trainlab.contracts.paths import DATA_DB_PATH
from trainlab.contracts.schema import ddl_statements
from trainlab.contracts.time import format_utc
from trainlab.fit.models import JsonArray, JsonObject, ParsedActivity, ParsedRecord
from trainlab.fit.parser import FitDecoder

FIT_STORAGE_SCHEMA_VERSION = 1


class FitStorageError(ValueError):
    def __init__(self, code: ErrorCode, message: str) -> None:
        super().__init__(message)
        self.code = code


def activity_id_for_fit_bytes(fit_bytes: bytes) -> str:
    return hashlib.sha256(fit_bytes).hexdigest()


def open_database(db_path: Path) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(db_path)
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def initialize_schema(connection: sqlite3.Connection) -> None:
    connection.execute("PRAGMA foreign_keys = ON")
    with connection:
        for statement in ddl_statements(include_system=True):
            connection.execute(statement)


def init_database(db_path: Path) -> None:
    connection = open_database(db_path)
    try:
        initialize_schema(connection)
    finally:
        connection.close()


def import_fit_file(
    instance_root: Path,
    fit_path: Path,
    decoder: FitDecoder,
    *,
    db_path: Path | None = None,
    parsed_at_utc: datetime | None = None,
) -> str:
    absolute_fit_path, relative_fit_path = _fit_path_inside_instance(instance_root, fit_path)
    fit_bytes = absolute_fit_path.read_bytes()
    activity_id = activity_id_for_fit_bytes(fit_bytes)
    parsed = decoder.decode(fit_bytes)
    database_path = instance_root / DATA_DB_PATH if db_path is None else db_path
    connection = open_database(database_path)
    try:
        initialize_schema(connection)
        import_activity(
            connection,
            activity_id=activity_id,
            fit_path=relative_fit_path,
            parsed=parsed,
            parsed_at_utc=parsed_at_utc,
        )
    finally:
        connection.close()
    return activity_id


def import_activity(
    connection: sqlite3.Connection,
    *,
    activity_id: str,
    fit_path: Path | str,
    parsed: ParsedActivity,
    parsed_at_utc: datetime | None = None,
) -> str:
    connection.execute("PRAGMA foreign_keys = ON")
    _validate_activity_id(activity_id)
    relative_fit_path = _normalize_relative_fit_path(Path(fit_path))
    parsed_at = format_utc(datetime.now(UTC) if parsed_at_utc is None else parsed_at_utc)
    row = _activity_row(activity_id, relative_fit_path, parsed, parsed_at)
    record_rows = _record_rows(activity_id, parsed.records)

    with connection:
        connection.execute(
            """
            INSERT INTO activities (
                activity_id, fit_path, sport, sub_sport, start_time_utc, end_time_utc,
                schema_version, parsed_at_utc, basic_json, summary_json, segments_json, sensors_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(activity_id) DO UPDATE SET
                fit_path=excluded.fit_path,
                sport=excluded.sport,
                sub_sport=excluded.sub_sport,
                start_time_utc=excluded.start_time_utc,
                end_time_utc=excluded.end_time_utc,
                schema_version=excluded.schema_version,
                parsed_at_utc=excluded.parsed_at_utc,
                basic_json=excluded.basic_json,
                summary_json=excluded.summary_json,
                segments_json=excluded.segments_json,
                sensors_json=excluded.sensors_json
            """,
            row,
        )
        connection.execute("DELETE FROM records WHERE activity_id = ?", (activity_id,))
        connection.executemany(
            """
            INSERT INTO records(activity_id, record_index, timestamp_utc, metrics_json)
            VALUES (?, ?, ?, ?)
            """,
            record_rows,
        )
    return activity_id


def get_activity_facts(connection: sqlite3.Connection, activity_id: str) -> dict[str, object]:
    row = connection.execute(
        """
        SELECT activity_id, start_time_utc, end_time_utc, basic_json, summary_json, segments_json, sensors_json
        FROM activities WHERE activity_id = ?
        """,
        (activity_id,),
    ).fetchone()
    if row is None:
        raise FitStorageError(ErrorCode.ACTIVITY_NOT_FOUND, "activity not found")
    return {
        "activity_id": row[0],
        "basic": json.loads(row[3]),
        "summary": json.loads(row[4]),
        "segments": json.loads(row[5]),
        "sensors": json.loads(row[6]),
        "source_timestamps_utc": {
            "start_time_utc": row[1],
            "end_time_utc": row[2],
        },
    }


def _activity_row(
    activity_id: str,
    fit_path: Path,
    parsed: ParsedActivity,
    parsed_at_utc: str,
) -> tuple[str, str, str | None, str | None, str | None, str | None, int, str, str, str, str, str]:
    basic_json = _stable_json_object(parsed.basic, "basic_json")
    summary_json = _stable_json_object(parsed.summary, "summary_json")
    segments_json = _stable_json_array(parsed.segments, "segments_json")
    _validate_sensors(parsed.sensors)
    sensors_json = _stable_json_object(parsed.sensors, "sensors_json")
    return (
        activity_id,
        fit_path.as_posix(),
        parsed.sport,
        parsed.sub_sport,
        None if parsed.start_time_utc is None else format_utc(parsed.start_time_utc),
        None if parsed.end_time_utc is None else format_utc(parsed.end_time_utc),
        FIT_STORAGE_SCHEMA_VERSION,
        parsed_at_utc,
        basic_json,
        summary_json,
        segments_json,
        sensors_json,
    )


def _record_rows(
    activity_id: str,
    records: tuple[ParsedRecord, ...],
) -> list[tuple[str, int, str | None, str]]:
    rows: list[tuple[str, int, str | None, str]] = []
    for index, record in enumerate(records):
        timestamp = None if record.timestamp_utc is None else format_utc(record.timestamp_utc)
        rows.append((activity_id, index, timestamp, _stable_json_object(record.metrics, "metrics_json")))
    return rows


def _stable_json_object(value: JsonObject, field_name: str) -> str:
    if not isinstance(value, dict):
        raise FitStorageError(ErrorCode.DATA_INVALID, f"{field_name} must be a JSON object")
    return _stable_json(value, field_name)


def _stable_json_array(value: JsonArray, field_name: str) -> str:
    if not isinstance(value, list):
        raise FitStorageError(ErrorCode.DATA_INVALID, f"{field_name} must be a JSON array")
    return _stable_json(value, field_name)


def _stable_json(value: object, field_name: str) -> str:
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise FitStorageError(ErrorCode.DATA_INVALID, f"{field_name} is not valid JSON") from exc


def _validate_sensors(sensors: JsonObject) -> None:
    records_value = sensors.get("records")
    if isinstance(records_value, list):
        raise FitStorageError(
            ErrorCode.DATA_INVALID,
            "sensors_json must describe devices or field definitions, not embed full records",
        )


def _validate_activity_id(activity_id: str) -> None:
    if len(activity_id) != 64 or any(char not in "0123456789abcdef" for char in activity_id):
        raise FitStorageError(ErrorCode.DATA_INVALID, "activity_id must be a lowercase SHA-256 hex digest")


def _fit_path_inside_instance(instance_root: Path, fit_path: Path) -> tuple[Path, Path]:
    root = instance_root.resolve(strict=False)
    absolute_fit_path = fit_path if fit_path.is_absolute() else root / fit_path
    resolved_fit_path = absolute_fit_path.resolve(strict=False)
    try:
        relative = resolved_fit_path.relative_to(root)
    except ValueError as exc:
        raise FitStorageError(ErrorCode.INVALID_ARGUMENT, "fit_path must stay inside the instance root") from exc
    return resolved_fit_path, _normalize_relative_fit_path(relative)


def _normalize_relative_fit_path(fit_path: Path) -> Path:
    if fit_path.is_absolute():
        raise FitStorageError(ErrorCode.INVALID_ARGUMENT, "fit_path must be instance-root relative")
    normalized = Path(os.path.normpath(fit_path.as_posix()))
    if normalized == Path(".") or (normalized.parts and normalized.parts[0] == ".."):
        raise FitStorageError(ErrorCode.INVALID_ARGUMENT, "fit_path must stay inside the instance root")
    if normalized.suffix.lower() != ".fit":
        raise FitStorageError(ErrorCode.INVALID_ARGUMENT, "fit_path must point to a .fit file")
    return normalized
