"""FIT decoder protocol boundary.

The B1 storage layer accepts a decoder here but does not claim real Garmin FIT SDK decoding yet.
"""

from __future__ import annotations

from typing import Protocol

from trainlab.fit.models import ParsedActivity


class FitDecoder(Protocol):
    def decode(self, fit_bytes: bytes) -> ParsedActivity:
        """Return a complete parsed activity or raise an explicit parse error."""
