"""FastAPI application factory for the ADHOC-0031 B0 local web base."""

from __future__ import annotations

from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException

from trainlab.contracts.errors import (
    ErrorCode,
    failure_envelope,
    http_status_for_error,
    success_envelope,
)
from trainlab.contracts.web import API_ROUTES, DEFAULT_PORT, LOCAL_HOST, static_mount_dir


def app_contract() -> dict[str, Any]:
    return {
        "host": LOCAL_HOST,
        "port": DEFAULT_PORT,
        "static_dir": static_mount_dir().as_posix(),
        "routes": [route.__dict__ for route in API_ROUTES],
        "starts_background_jobs": False,
        "reads_private_state_on_import": False,
    }


def create_app() -> FastAPI:
    static_dir = static_mount_dir()
    app = FastAPI(title="TrainLab Local Web", version="0.1.0")

    @app.exception_handler(StarletteHTTPException)
    async def http_exception_handler(_request: Request, exc: StarletteHTTPException) -> JSONResponse:
        code = ErrorCode.ACTIVITY_NOT_FOUND if exc.status_code == 404 else ErrorCode.INVALID_ARGUMENT
        message = "not found" if exc.status_code == 404 else str(exc.detail)
        return JSONResponse(
            status_code=exc.status_code,
            content=failure_envelope(code, message).to_json(),
        )

    @app.exception_handler(ValueError)
    async def value_error_handler(_request: Request, exc: ValueError) -> JSONResponse:
        code = ErrorCode.INVALID_ARGUMENT
        return JSONResponse(
            status_code=http_status_for_error(code),
            content=failure_envelope(code, str(exc)).to_json(),
        )

    @app.get("/api/health")
    def health() -> dict[str, object]:
        return success_envelope(
            {
                "service": "trainlab-local-web",
                "b0_contract_only": True,
                "starts_background_jobs": False,
            }
        ).to_json()

    app.mount("/", StaticFiles(directory=static_dir, html=True, follow_symlink=False), name="web")
    return app
