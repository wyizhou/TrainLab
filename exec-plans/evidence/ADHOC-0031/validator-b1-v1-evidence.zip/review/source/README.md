# TrainLab source

ADHOC-0031 B0 工程底座。

本目录是当前产品唯一工程位置：

- `trainlab/`：Python 公共合同、路径、时间、Schema、DTO、错误壳，以及 FIT/SQLite 基础层。
- `skills/_shared/scripts/`：后续技能共享脚本位置。
- `skills/local-web/scripts/`：本地 Web/API 后端入口位置。
- `skills/local-web/web/`：前端生产构建默认输出位置，由后端静态服务使用；该目录是生成产物。
- `frontend/`：React 前端源码与本地构建脚本。
- `tools/README.md`：AI 可见能力索引。
- `tests/`：B0 合同级测试。

B0 只冻结工程底座和公共合同；B1 增加 ADHOC-0024 的合成可测 FIT 解析边界与 SQLite 入库基础层。当前仍不启动 Garmin 同步、不调用真实 AI Provider、不读取私有 `states/ai.json` 或私人 FIT。

## 本地检查

Python 检查在 `source/` 下运行：

```bash
python -m pytest tests -p no:cacheprovider
python -m ruff check --no-cache .
python -m mypy trainlab skills tools tests
python -m compileall -q .
```

前端检查在 `source/frontend/` 下运行：

```bash
npm install
npm run lint
npm run typecheck
npm test
npm run build
```

`npm run build` 默认输出到 `source/skills/local-web/web`。
