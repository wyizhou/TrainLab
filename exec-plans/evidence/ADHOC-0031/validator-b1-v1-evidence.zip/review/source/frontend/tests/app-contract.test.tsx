import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { App } from "../src/App";
import { allApiRoutesStayUnderPrefix, apiRoutes, staticPolicy } from "../src/contracts";

describe("TrainLab B0 React frontend", () => {
  it("keeps all public API routes under /api", () => {
    expect(apiRoutes.length).toBeGreaterThanOrEqual(5);
    expect(allApiRoutesStayUnderPrefix()).toBe(true);
  });

  it("documents the static output and privacy boundary", () => {
    expect(staticPolicy.outputDir).toBe("../skills/local-web/web");
    expect(staticPolicy.exposesStates).toBe(false);
    expect(staticPolicy.startsBackgroundJobs).toBe(false);
  });

  it("renders a real React shell for B0", () => {
    const html = renderToStaticMarkup(<App />);
    expect(html).toContain("TrainLab Local");
    expect(html).toContain("React B0");
    expect(html).toContain("source/skills/local-web/web");
  });
});
