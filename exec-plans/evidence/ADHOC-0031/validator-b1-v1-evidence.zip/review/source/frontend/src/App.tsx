import { apiRoutes, staticPolicy } from "./contracts";

const cards = [
  {
    title: "本地 API",
    body: "/api/ 下提供接口；当前 B0 只冻结工程底座与公共合同。",
  },
  {
    title: "隐私边界",
    body: "静态目录不暴露 states、密钥、FIT 原件或数据库。",
  },
  {
    title: "构建输出",
    body: "生产构建默认输出到 source/skills/local-web/web。",
  },
];

export function App(): React.ReactElement {
  return (
    <main className="shell">
      <section className="hero">
        <p className="eyebrow">TrainLab Local</p>
        <h1>本地训练数据与 AI 总结</h1>
        <p>React B0 前端底座；后续阶段接入同步状态、活动搜索和报告浏览。</p>
      </section>

      <section className="cards" aria-label="B0 contracts">
        {cards.map((card) => (
          <article key={card.title}>
            <h2>{card.title}</h2>
            <p>{card.body}</p>
          </article>
        ))}
      </section>

      <section className="contract-panel" aria-label="工程合同">
        <h2>已冻结的最小前端合同</h2>
        <ul>
          <li>API 路由数量：{apiRoutes.length}</li>
          <li>静态输出：{staticPolicy.outputDir}</li>
          <li>不启动后台任务：{String(!staticPolicy.startsBackgroundJobs)}</li>
        </ul>
      </section>
    </main>
  );
}
