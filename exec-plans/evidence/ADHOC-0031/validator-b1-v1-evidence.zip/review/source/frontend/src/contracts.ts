export const apiRoutes = [
  "/api/health",
  "/api/sync/status",
  "/api/activities",
  "/api/reports/activity",
  "/api/reports/weekly",
] as const;

export const staticPolicy = {
  outputDir: "../skills/local-web/web",
  exposesStates: false,
  startsBackgroundJobs: false,
} as const;

export function allApiRoutesStayUnderPrefix(routes: readonly string[] = apiRoutes): boolean {
  return routes.length > 0 && routes.every((route) => route.startsWith("/api/"));
}
