from __future__ import annotations

import json
import sqlite3
import tempfile
import unittest
from collections.abc import Mapping
from datetime import UTC, datetime, timedelta
from pathlib import Path

from trainlab.contracts.errors import ErrorCode
from trainlab.fit import (
    FitStorageError,
    ParsedActivity,
    ParsedRecord,
    activity_id_for_fit_bytes,
    get_activity_facts,
    import_activity,
    import_fit_file,
    init_database,
    open_database,
)
from trainlab.fit.models import JsonObject, JsonValue


class SyntheticDecoder:
    def decode(self, fit_bytes: bytes) -> ParsedActivity:
        if fit_bytes == b"bad-json-fit":
            raise ValueError("synthetic FIT payload is invalid")
        return parsed_activity(records=(record(0, {"heart_rate_bpm": 0}),))


def aware(offset_seconds: int = 0) -> datetime:
    return datetime(2026, 9, 16, 1, 2, 3, tzinfo=UTC) + timedelta(seconds=offset_seconds)


def cast_mapping(value: object) -> Mapping[str, object]:
    if not isinstance(value, dict):
        raise TypeError("expected mapping")
    return value


def record(offset_seconds: int | None, metrics: JsonObject) -> ParsedRecord:
    timestamp = None if offset_seconds is None else aware(offset_seconds)
    return ParsedRecord(timestamp_utc=timestamp, metrics=metrics)


def parsed_activity(
    *,
    sport: str | None = "running",
    records: tuple[ParsedRecord, ...] = (),
    sensors: JsonObject | None = None,
    summary: JsonObject | None = None,
) -> ParsedActivity:
    basic: JsonObject = {"sport": sport, "device": "synthetic"}
    default_summary: JsonObject = {"distance_m": 1234.5, "zero_value": 0}
    segments: list[JsonValue] = [{"kind": "lap", "elapsed_s": 180}]
    default_sensors: JsonObject = {
        "devices": ["synthetic-watch"],
        "fields": {"heart_rate_bpm": "bpm"},
    }
    return ParsedActivity(
        sport=sport,
        sub_sport=None,
        start_time_utc=aware(0),
        end_time_utc=aware(180),
        basic=basic,
        summary=default_summary if summary is None else summary,
        segments=segments,
        sensors=default_sensors if sensors is None else sensors,
        records=records,
    )


class FitStorageTests(unittest.TestCase):
    def test_init_database_creates_required_tables_and_keeps_existing_report_data(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            db_path = Path(temp_dir) / "states" / "data.db"
            init_database(db_path)
            with open_database(db_path) as connection:
                connection.execute(
                    "INSERT INTO activities VALUES(?, ?, ?, NULL, ?, ?, 1, ?, '{}', '{}', '[]', '{}')",
                    ("a" * 64, "states/activities/a.fit", "running", None, None, aware(1).strftime("%Y-%m-%dT%H:%M:%S.%fZ")),
                )
                connection.execute("INSERT INTO activties_report VALUES(?, ?, ?)", ("a" * 64, None, "全文"))
                connection.execute(
                    "INSERT INTO weekly_report(run_time_utc, summary) VALUES(?, ?)",
                    (aware(2).strftime("%Y-%m-%dT%H:%M:%S.%fZ"), "本周无任何运动记录"),
                )
                connection.execute("INSERT INTO config VALUES(?, ?, ?)", ("k", '{"v":1}', aware(3).strftime("%Y-%m-%dT%H:%M:%S.%fZ")))
            init_database(db_path)
            with open_database(db_path) as connection:
                tables = {
                    row[0]
                    for row in connection.execute(
                        "SELECT name FROM sqlite_master WHERE type='table'"
                    ).fetchall()
                }
                activities_info = connection.execute("PRAGMA table_info(activities)").fetchall()
                records_info = connection.execute("PRAGMA table_info(records)").fetchall()
                records_fk = connection.execute("PRAGMA foreign_key_list(records)").fetchall()
                activity_columns = {row[1] for row in activities_info}
                denied_columns = {
                    "has_running",
                    "parse_status",
                    "session_count",
                    "parser_version",
                    "data_revision",
                    "quality_json",
                }
                self.assertTrue({"activities", "records", "activties_report", "weekly_report", "config"}.issubset(tables))
                self.assertEqual(len(activity_columns), 12)
                self.assertFalse(activity_columns.intersection(denied_columns))
                self.assertEqual([(row[1], row[3], row[5]) for row in records_info[:2]], [("activity_id", 1, 1), ("record_index", 1, 2)])
                self.assertEqual(records_fk[0][2], "activities")
                self.assertEqual(connection.execute("SELECT summary FROM activties_report").fetchone()[0], "全文")
                self.assertEqual(connection.execute("SELECT value_json FROM config").fetchone()[0], '{"v":1}')

    def test_import_fit_file_uses_actual_fit_bytes_sha_and_relative_fit_path(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            fit_path = root / "states" / "activities" / "synthetic.fit"
            fit_path.parent.mkdir(parents=True)
            fit_bytes = b"synthetic-fit-bytes"
            fit_path.write_bytes(fit_bytes)
            expected_activity_id = activity_id_for_fit_bytes(fit_bytes)
            imported = import_fit_file(root, fit_path, SyntheticDecoder(), parsed_at_utc=aware(10))
            self.assertEqual(imported, expected_activity_id)
            with open_database(root / "states" / "data.db") as connection:
                row = connection.execute("SELECT activity_id, fit_path FROM activities").fetchone()
                self.assertEqual(row, (expected_activity_id, "states/activities/synthetic.fit"))

    def test_import_activity_keeps_original_record_order_duplicate_timestamps_and_zero_values(self) -> None:
        with sqlite3.connect(":memory:") as connection:
            init_connection(connection)
            activity_id = "b" * 64
            parsed = parsed_activity(
                records=(
                    record(20, {"heart_rate_bpm": 0, "developer": {"ground_contact_ms": 0}}),
                    record(10, {"heart_rate_bpm": 135}),
                    record(20, {"heart_rate_bpm": 136}),
                    record(None, {"heart_rate_bpm": None}),
                )
            )
            import_activity(
                connection,
                activity_id=activity_id,
                fit_path="states/activities/b.fit",
                parsed=parsed,
                parsed_at_utc=aware(30),
            )
            rows = connection.execute(
                "SELECT record_index, timestamp_utc, metrics_json FROM records WHERE activity_id=? ORDER BY record_index",
                (activity_id,),
            ).fetchall()
            self.assertEqual([row[0] for row in rows], [0, 1, 2, 3])
            self.assertEqual(rows[0][1], "2026-09-16T01:02:23.000000Z")
            self.assertEqual(rows[2][1], "2026-09-16T01:02:23.000000Z")
            self.assertIsNone(rows[3][1])
            self.assertEqual(json.loads(rows[0][2])["heart_rate_bpm"], 0)
            self.assertEqual(len(rows), 4)
            connection.execute("INSERT INTO activties_report VALUES(?, ?, ?)", (activity_id, None, "保留报告"))
            import_activity(
                connection,
                activity_id=activity_id,
                fit_path="states/activities/b.fit",
                parsed=parsed_activity(records=(record(0, {"heart_rate_bpm": 0}),)),
                parsed_at_utc=aware(31),
            )
            self.assertEqual(
                connection.execute(
                    "SELECT summary FROM activties_report WHERE activity_id=?",
                    (activity_id,),
                ).fetchone()[0],
                "保留报告",
            )

    def test_zero_record_activity_is_valid_and_get_activity_facts_excludes_records(self) -> None:
        with sqlite3.connect(":memory:") as connection:
            init_connection(connection)
            activity_id = "c" * 64
            import_activity(
                connection,
                activity_id=activity_id,
                fit_path="states/activities/c.fit",
                parsed=parsed_activity(records=()),
                parsed_at_utc=aware(40),
            )
            self.assertEqual(connection.execute("SELECT COUNT(*) FROM records").fetchone()[0], 0)
            facts = get_activity_facts(connection, activity_id)
            self.assertEqual(set(facts), {"activity_id", "basic", "summary", "segments", "sensors", "source_timestamps_utc"})
            self.assertNotIn("records", facts)
            sensors = facts["sensors"]
            self.assertIsInstance(sensors, dict)
            self.assertNotIn("records", cast_mapping(sensors))

    def test_illegal_json_or_sensor_records_rolls_back_existing_activity_and_records(self) -> None:
        with sqlite3.connect(":memory:") as connection:
            init_connection(connection)
            activity_id = "d" * 64
            import_activity(
                connection,
                activity_id=activity_id,
                fit_path="states/activities/d.fit",
                parsed=parsed_activity(records=(record(0, {"heart_rate_bpm": 100}),)),
                parsed_at_utc=aware(50),
            )
            with self.assertRaises(FitStorageError) as raised:
                import_activity(
                    connection,
                    activity_id=activity_id,
                    fit_path="states/activities/d.fit",
                    parsed=parsed_activity(
                        records=(record(0, {"bad_number": float("nan")}),),
                    ),
                    parsed_at_utc=aware(60),
                )
            self.assertEqual(raised.exception.code, ErrorCode.DATA_INVALID)
            rows = connection.execute("SELECT record_index, metrics_json FROM records WHERE activity_id=?", (activity_id,)).fetchall()
            self.assertEqual(len(rows), 1)
            self.assertEqual(json.loads(rows[0][1])["heart_rate_bpm"], 100)
            with self.assertRaises(FitStorageError):
                import_activity(
                    connection,
                    activity_id="e" * 64,
                    fit_path="states/activities/e.fit",
                    parsed=parsed_activity(sensors={"records": [{"heart_rate_bpm": 1}]}),
                    parsed_at_utc=aware(70),
                )
            self.assertIsNone(connection.execute("SELECT activity_id FROM activities WHERE activity_id=?", ("e" * 64,)).fetchone())

    def test_child_constraint_failure_rolls_back_activity_row(self) -> None:
        with sqlite3.connect(":memory:") as connection:
            init_connection(connection)
            with self.assertRaises(sqlite3.IntegrityError), connection:
                connection.execute(
                    "INSERT INTO activities VALUES(?, ?, NULL, NULL, NULL, NULL, 1, ?, '{}', '{}', '[]', '{}')",
                    ("f" * 64, "states/activities/f.fit", aware(80).strftime("%Y-%m-%dT%H:%M:%S.%fZ")),
                )
                connection.execute("INSERT INTO records VALUES(?, NULL, NULL, '{}')", ("f" * 64,))
            self.assertIsNone(connection.execute("SELECT activity_id FROM activities WHERE activity_id=?", ("f" * 64,)).fetchone())

    def test_invalid_activity_id_path_or_decoder_failure_saves_nothing(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            fit_path = root / "states" / "activities" / "bad.fit"
            fit_path.parent.mkdir(parents=True)
            fit_path.write_bytes(b"bad-json-fit")
            with self.assertRaises(ValueError):
                import_fit_file(root, fit_path, SyntheticDecoder())
            self.assertFalse((root / "states" / "data.db").exists())
            with sqlite3.connect(":memory:") as connection:
                init_connection(connection)
                with self.assertRaises(FitStorageError):
                    import_activity(
                        connection,
                        activity_id="not-a-sha",
                        fit_path="states/activities/g.fit",
                        parsed=parsed_activity(),
                    )
                with self.assertRaises(FitStorageError):
                    import_activity(
                        connection,
                        activity_id="0" * 64,
                        fit_path="../outside.fit",
                        parsed=parsed_activity(),
                    )


def init_connection(connection: sqlite3.Connection) -> None:
    from trainlab.fit import initialize_schema

    initialize_schema(connection)


if __name__ == "__main__":
    unittest.main()
