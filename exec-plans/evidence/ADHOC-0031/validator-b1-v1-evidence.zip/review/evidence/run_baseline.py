from __future__ import annotations

import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / 'evidence'
(EVIDENCE / 'tmp').mkdir(exist_ok=True)
env = os.environ.copy()
env['TMPDIR'] = str(EVIDENCE / 'tmp')
checks = [
    ('pytest', ['-m', 'pytest', 'tests', '-q', '-p', 'no:cacheprovider']),
    ('ruff', ['-m', 'ruff', 'check', '--no-cache', '.']),
    ('mypy', ['-m', 'mypy', 'trainlab', 'skills', 'tools', 'tests']),
    ('compileall', ['-m', 'compileall', '-q', 'trainlab', 'skills', 'tools', 'tests']),
    ('static', ['tools/check_b0_static.py']),
]
results = []
for name, args in checks:
    command = [sys.executable, *args]
    completed = subprocess.run(command, cwd=ROOT / 'source', env=env, capture_output=True, text=True)
    text = 'CWD: source/\nCOMMAND: ' + ' '.join(command) + '\n' + completed.stdout + completed.stderr + f'\nEXIT: {completed.returncode}\n'
    (EVIDENCE / f'baseline-{name}.log').write_text(text)
    results.append({'command': command, 'cwd': 'source', 'exit': completed.returncode, 'log': f'evidence/baseline-{name}.log'})
    print(name, 'EXIT', completed.returncode, completed.stdout.strip(), completed.stderr.strip())
(EVIDENCE / 'baseline-results.json').write_text(json.dumps(results, indent=2))
(EVIDENCE / 'environment.json').write_text(json.dumps({'python': sys.version, 'executable': sys.executable, 'dependencies': {name: importlib.metadata.version(name) for name in ('pytest', 'ruff', 'mypy', 'fastapi', 'httpx')}, 'source_contains_git': (ROOT / '.git').exists(), 'temporary_directory': 'evidence/tmp'}, indent=2))
raise SystemExit(int(any(r['exit'] for r in results)))
