from __future__ import annotations

import hashlib
import json
from pathlib import Path
import struct


def crc16(data: bytes) -> int:
    value = 0
    for byte in data:
        value ^= byte
        for _ in range(8):
            value = (value >> 1) ^ (0xA001 if value & 1 else 0)
    return value


def definition(local: int, number: int, fields: list[tuple[int, int, int]]) -> bytes:
    return bytes([0x40 | local, 0, 0]) + struct.pack('<H', number) + bytes([len(fields)]) + b''.join(bytes(f) for f in fields)


def frame(data: bytes) -> bytes:
    head = struct.pack('<BBHI4s', 14, 0x20, 2140, len(data), b'.FIT')
    head += struct.pack('<H', crc16(head))
    return head + data + struct.pack('<H', crc16(head + data))


def activity_data(*, record_count: int = 4, include_activity: bool = True, time_shift: int = 0) -> bytes:
    t = 1262390400 + time_shift
    data = definition(0, 0, [(0, 1, 0), (1, 2, 0x84), (4, 4, 0x86)])
    data += bytes([0]) + struct.pack('<BHI', 4, 1, t)
    data += definition(1, 20, [(253, 4, 0x86), (3, 1, 2), (5, 4, 0x86), (6, 2, 0x84), (7, 2, 0x84)])
    for i in range(record_count):
        offset = [0, 2, 2, 19][i % 4]
        data += bytes([1]) + struct.pack('<IBIHH', t + offset, [0, 120, 255, 130][i % 4], i * 125, [0, 2000, 0xFFFF, 3500][i % 4], i * 5)
    duration_fields = [(253, 4, 0x86), (0, 1, 0), (1, 1, 0), (2, 4, 0x86), (7, 4, 0x86), (8, 4, 0x86), (9, 4, 0x86)]
    data += definition(2, 19, duration_fields)
    data += bytes([2]) + struct.pack('<IBBIIII', t + 20, 9, 1, t, 19125, 15000, 375)
    data += definition(3, 18, duration_fields + [(5, 1, 0), (6, 1, 0), (25, 2, 0x84), (26, 2, 0x84)])
    data += bytes([3]) + struct.pack('<IBBIIIIBBHH', t + 20, 8, 1, t, 19125, 15000, 375, 1, 0, 0, 1)
    if include_activity:
        data += definition(4, 34, [(253, 4, 0x86), (0, 4, 0x86), (1, 2, 0x84), (2, 1, 0), (3, 1, 0), (4, 1, 0)])
        data += bytes([4]) + struct.pack('<IIHBBB', t + 20, 15000, 1, 0, 26, 1)
    return data


def inspect_frames(data: bytes) -> list[dict[str, object]]:
    offset = 0
    frames = []
    while offset < len(data):
        length = data[offset]
        assert length == 14
        size = struct.unpack_from('<I', data, offset + 4)[0]
        end = offset + length + size + 2
        assert data[offset + 8:offset + 12] == b'.FIT' and end <= len(data)
        assert crc16(data[offset:offset + length]) == 0
        assert crc16(data[offset:end]) == 0
        definitions = {}
        messages = []
        p = offset + length
        while p < end - 2:
            header = data[p]
            p += 1
            local = header & 0x0F
            if header & 0x40:
                assert data[p:p+2] == b'\x00\x00'
                number = struct.unpack_from('<H', data, p + 2)[0]
                count = data[p + 4]
                fields = [tuple(data[q:q+3]) for q in range(p + 5, p + 5 + count * 3, 3)]
                definitions[local] = (number, fields)
                p += 5 + 3 * count
            else:
                number, fields = definitions[local]
                messages.append(number)
                p += sum(f[1] for f in fields)
        assert p == end - 2
        frames.append({'message_numbers': messages, 'records': messages.count(20), 'definitions': len(definitions), 'bytes': end - offset})
        offset = end
    return frames


def write_fixtures(root: Path) -> dict[str, bytes]:
    root.mkdir(parents=True, exist_ok=True)
    good = frame(activity_data())
    corrupt_crc = good[:-1] + bytes([good[-1] ^ 0x40])
    fixtures = {
        'normal.fit': good,
        'bad-crc.fit': corrupt_crc,
        'bad-length.fit': good[:-5],
        'undefined-message.fit': frame(b'\x0f'),
        'missing-activity.fit': frame(activity_data(include_activity=False)),
        'zero-record.fit': frame(activity_data(record_count=0)),
        'chain.fit': good + frame(activity_data(time_shift=100)),
        'chain-bad-tail.fit': good + corrupt_crc,
    }
    manifest = {}
    for name, content in fixtures.items():
        (root / name).write_bytes(content)
        item = {'sha256': hashlib.sha256(content).hexdigest(), 'size': len(content)}
        if name in ('normal.fit', 'missing-activity.fit', 'zero-record.fit', 'chain.fit'):
            item['frames'] = inspect_frames(content)
        manifest[name] = item
    (root / 'manifest.json').write_text(json.dumps(manifest, indent=2))
    return fixtures


if __name__ == '__main__':
    result = write_fixtures(Path(__file__).parent / 'fits')
    print('Created', len(result), 'synthetic fixtures; good-frame length, CRC and definition traversal assertions passed.')
