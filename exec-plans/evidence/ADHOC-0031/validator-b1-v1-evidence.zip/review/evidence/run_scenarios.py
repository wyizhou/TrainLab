from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
E = ROOT / 'evidence'
SCENARIOS = {
    'S01-decoder': ['test_product_provides_concrete_fit_decoder'],
    'S02-layout': ['test_architecture_approved_physical_root', 'test_tools_contains_no_runtime_sys_path_patch'],
    'S03-schema': ['test_schema_shape_constraints_and_reinitialize_preserves'],
    'S04-records': ['test_storage_long_records_keep_order_zero_null_and_gaps'],
    'S05-nonrunning': ['test_storage_non_running_not_filtered'],
    'S06-time': ['test_storage_timezone_normalization_and_fraction', 'test_storage_rejects_naive_without_partial_write'],
    'S07-invalidvalues': ['test_storage_invalid_serializable_values_keep_old'],
    'S08-rollback': ['test_real_import_transaction_child_failure_is_atomic'],
    'S09-fileidentity': ['test_file_boundary_sha_and_original_untouched'],
    'S10-path': ['test_file_boundary_rejects_escape_before_decoder'],
    'S11-decodefailureboundary': ['test_decoder_error_does_not_create_or_destroy_database'],
    'S12-idempotence': ['test_same_bytes_import_is_fully_idempotent'],
    'S13-reportconflict': ['test_reparse_with_report_requires_conflict_and_keeps_all_facts'],
    'S14-noreportupdate': ['test_reparse_without_report_can_replace_atomically'],
    'S15-segments': ['test_accepted_segments_container_can_be_stored'],
    'S16-defaultfacts': ['test_default_123_shape_and_minimal_dictionary'],
    'S17-publiccontract': ['test_existing_public_contract_accepts_required_default_shape', 'test_existing_public_contract_rejects_unknown_keys'],
    'S18-jsonvalidation': ['test_storage_rejects_contract_invalid_json_before_commit'],
    'S19-notfound': ['test_unknown_activity_is_not_empty_success'],
}
(E / 'scenarios').mkdir(exist_ok=True)
(E / 'scenario-temp').mkdir(exist_ok=True)
env = os.environ.copy()
env['TMPDIR'] = str(E / 'tmp')
results = []
for name, tests in SCENARIOS.items():
    nodes = ['../evidence/test_b1_independent.py::' + test for test in tests]
    command = [sys.executable, '-m', 'pytest', *nodes, '-v', '-s', '--tb=short', '-p', 'no:cacheprovider', '--basetemp=../evidence/scenario-temp/' + name]
    result = subprocess.run(command, cwd=ROOT / 'source', env=env, text=True, capture_output=True)
    log = E / 'scenarios' / (name + '.log')
    log.write_text('CWD: source/\nCOMMAND: ' + ' '.join(command) + '\n' + result.stdout + result.stderr + f'\nEXIT: {result.returncode}\n')
    results.append({'scenario': name, 'nodes': nodes, 'command': command, 'cwd': 'source', 'exit': result.returncode, 'evidence': str(log.relative_to(ROOT))})
    print(name, 'EXIT', result.returncode)
(E / 'scenario-results.json').write_text(json.dumps(results, indent=2))
raise SystemExit(int(any(item['exit'] for item in results)))
