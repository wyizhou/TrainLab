import hashlib
import json
from pathlib import Path
import stat

root = Path(__file__).resolve().parents[1]
snapshot = json.loads((root / 'review-snapshot.json').read_text())
actual = []
for wanted in snapshot['items']:
    path = root / wanted['path']
    row = {'path': wanted['path'], 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'mode': oct(stat.S_IMODE(path.stat().st_mode)), 'size': path.stat().st_size}
    actual.append(row)
    print('OK' if row == wanted else 'MISMATCH', json.dumps(row, sort_keys=True))
aggregate = hashlib.sha256(json.dumps(actual, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
expected_paths = {item['path'] for item in snapshot['items']}
cache_names = {'__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache'}
actual_paths = {'.gitignore'} | {p.relative_to(root).as_posix() for p in (root / 'source').rglob('*') if p.is_file() and not cache_names.intersection(p.parts)}
print('COUNT', len(actual), 'AGGREGATE', aggregate)
print('NEW_NON_CACHE_PRODUCT_FILES', sorted(actual_paths - expected_paths))
print('MISSING_PRODUCT_FILES', sorted(expected_paths - actual_paths))
print('GIT_METADATA_PRESENT', (root / '.git').exists())
print('SOURCE_HEAD', snapshot['head'], 'SOURCE_BRANCH', snapshot['branch'])
assert actual == snapshot['items']
assert aggregate == snapshot['product_aggregate_sha256']
assert actual_paths == expected_paths
assert not (root / '.git').exists()
print('All 38 SHA256/size/mode checks and product inventory match. EXIT 0')
