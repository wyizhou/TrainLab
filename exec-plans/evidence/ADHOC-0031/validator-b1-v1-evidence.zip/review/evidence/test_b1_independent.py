from __future__ import annotations

import ast
from dataclasses import replace
from datetime import UTC, datetime, timedelta, timezone
import hashlib
import inspect
import json
from pathlib import Path
import sqlite3

import pytest

from trainlab.contracts.interfaces import validate_payload
from trainlab.contracts.time import format_utc
from trainlab.fit import (
    FitStorageError, ParsedActivity, ParsedRecord, get_activity_facts,
    import_activity, import_fit_file, initialize_schema, open_database,
)
from trainlab.fit.parser import FitDecoder

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / 'evidence'
T0 = datetime(2030, 1, 1, 1, 2, 3, 123456, tzinfo=UTC)
SHA = hashlib.sha256(b'storage-boundary-only').hexdigest()


def field(number=20, name='heart_rate', source_ref=None):
    return {'message_number': number, 'message_name': {20: 'record', 18: 'session', 23: 'device_info'}.get(number), 'field_number': 3,
            'name': name, 'base_type': 'uint8', 'unit': 'bpm', 'origin': 'direct', 'source_ref': source_ref,
            'definition_index': 0, 'chain_index': 0, 'component_of': None, 'value_form': 'physical'}


def message(index=0, number=18, standard=None, developer=None):
    return {'message_index': index, 'chain_index': 0, 'message_number': number,
            'message_name': {18: 'session', 19: 'lap', 23: 'device_info'}.get(number),
            'fields': {'standard': standard or {}, 'developer': developer or {}}}


def record(index=0, timestamp=T0):
    return ParsedRecord(timestamp, {'standard': {'f0': index}, 'developer': {'f1': None if index % 3 else 0},
                                   'time_evidence': {'kind': 'missing' if timestamp is None else 'absolute',
                                                     'raw': None if timestamp is None else 1262390400 + index, 'unit': 's'}})


def parsed():
    return ParsedActivity('running', None, T0, T0 + timedelta(seconds=19.125),
        {'sport': 'running', 'sub_sport': None, 'start_time_utc': format_utc(T0), 'end_time_utc': format_utc(T0 + timedelta(seconds=19.125)), 'messages': []},
        {'messages': [message(2, standard={'f2': 120})]},
        [],
        {'field_definitions': {'f0': field(), 'f1': field(name='same_name', source_ref='d0'), 'f2': field(18), 'f3': field(23)},
         'developer_sources': {'d0': {'chain_index': 0, 'developer_data_index': 0, 'application_name': 'synthetic', 'manufacturer': None}},
         'messages': [message(1, 23, standard={'f3': 1})]},
        (record(), record(1)))


@pytest.fixture
def database(tmp_path):
    c = open_database(tmp_path / 'states/data.db')
    initialize_schema(c)
    yield c
    c.close()


def store(c, value=None, sha=SHA, when=T0):
    return import_activity(c, activity_id=sha, fit_path='states/activities/synthetic.fit', parsed=parsed() if value is None else value, parsed_at_utc=when)


def dump(c):
    return {table: c.execute(f'SELECT * FROM {table} ORDER BY 1').fetchall() for table in ('activities', 'records', 'activties_report', 'weekly_report', 'config')}


def seed_reports(c):
    with c:
        c.execute('INSERT INTO activties_report VALUES(?,?,?)', (SHA, format_utc(T0), '完整的旧活动报告'))
        c.execute('INSERT INTO weekly_report(run_time_utc, summary) VALUES(?,?)', (format_utc(T0), '完整的历史周报告'))
        c.execute('INSERT INTO config VALUES(?,?,?)', ('synthetic', '{"enabled":true}', format_utc(T0)))


class StorageBoundaryDecoder:
    """Injected DTO only; these tests DO NOT verify FIT decoding."""
    def __init__(self, value=None):
        self.value = parsed() if value is None else value
        self.received = []

    def decode(self, content):
        self.received.append(content)
        return self.value


def test_product_provides_concrete_fit_decoder():
    classes = []
    for path in sorted((ROOT / 'source').rglob('*.py')):
        if 'tests' in path.parts:
            continue
        for item in ast.walk(ast.parse(path.read_text())):
            if isinstance(item, ast.ClassDef) and any(isinstance(child, ast.FunctionDef) and child.name == 'decode' for child in item.body):
                classes.append((str(path.relative_to(ROOT)), item.name))
    print('decode classes:', classes, 'entry signature:', inspect.signature(import_fit_file))
    with pytest.raises(TypeError):
        FitDecoder()
    assert any(name != 'FitDecoder' for _, name in classes), 'No concrete FIT decoder: import_fit_file requires caller-supplied decoder; FitDecoder is an uninstantiable Protocol.'


def test_architecture_approved_physical_root():
    outside = [str(p.relative_to(ROOT)) for p in (ROOT / 'source/trainlab').rglob('*.py') if p.name != '__init__.py']
    assert not outside, f'Runtime implementation outside approved Skill/scripts roots: {outside}'


def test_tools_contains_no_runtime_sys_path_patch():
    script = ROOT / 'source/tools/check_b0_static.py'
    assert 'sys.path.insert' not in script.read_text(), 'source/tools is documentation-only; check script patches sys.path'


def test_schema_shape_constraints_and_reinitialize_preserves(database):
    c = database
    assert c.execute('PRAGMA foreign_keys').fetchone() == (1,)
    assert c.execute('PRAGMA journal_mode').fetchone() == ('delete',)
    expected = {'activities': 12, 'records': 4, 'activties_report': 3, 'weekly_report': 3, 'config': 3}
    for table, count in expected.items():
        assert len(c.execute(f'PRAGMA table_info({table})').fetchall()) == count
    assert [(r[1], r[3], r[5]) for r in c.execute('PRAGMA table_info(records)').fetchall()[:2]] == [('activity_id', 1, 1), ('record_index', 1, 2)]
    assert c.execute('PRAGMA foreign_key_list(records)').fetchone()[2] == 'activities'
    for table, key in [('activities', 'activity_id'), ('activties_report', 'activity_id'), ('config', 'key')]:
        assert next(r for r in c.execute(f'PRAGMA table_info({table})') if r[1] == key)[3] == 1
    store(c)
    seed_reports(c)
    before = dump(c)
    initialize_schema(c)
    assert dump(c) == before
    assert c.execute('PRAGMA foreign_key_check').fetchall() == []
    with pytest.raises(sqlite3.IntegrityError), c:
        c.execute('INSERT INTO records VALUES(?,?,?,?)', ('nonexistent', 0, None, '{}'))
    with pytest.raises(sqlite3.IntegrityError), c:
        c.execute('INSERT INTO records VALUES(?,?,?,?)', (SHA, 0, None, '{}'))


def test_storage_long_records_keep_order_zero_null_and_gaps(database):
    n = 25001
    stamps = [T0 + timedelta(seconds=20), T0 + timedelta(seconds=3), T0 + timedelta(seconds=20), None]
    values = tuple(record(i, stamps[i % 4]) for i in range(n))
    store(database, replace(parsed(), records=values))
    rows = database.execute('SELECT record_index,timestamp_utc,metrics_json FROM records ORDER BY record_index').fetchall()
    assert len(rows) == n
    for i, (index, timestamp, metrics) in enumerate(rows):
        assert index == i
        assert timestamp == (None if stamps[i % 4] is None else format_utc(stamps[i % 4]))
        assert json.loads(metrics) == values[i].metrics
    print('verified record rows', len(rows), 'including duplicates, out-of-order timestamps, null and 0')


def test_storage_non_running_not_filtered(database):
    value = replace(parsed(), sport='cycling', basic={**parsed().basic, 'sport': 'cycling'})
    store(database, value)
    assert database.execute('SELECT sport FROM activities').fetchone() == ('cycling',)
    assert database.execute('SELECT count(*) FROM records').fetchone() == (2,)


def test_storage_timezone_normalization_and_fraction(database):
    offset = timezone(timedelta(hours=8))
    value = replace(parsed(), start_time_utc=T0.astimezone(offset), end_time_utc=(T0 + timedelta(seconds=19.125)).astimezone(offset), records=(record(0, T0.astimezone(offset)),))
    store(database, value, when=T0.astimezone(offset))
    assert database.execute('SELECT start_time_utc,end_time_utc,parsed_at_utc FROM activities').fetchone() == (format_utc(T0), format_utc(T0 + timedelta(seconds=19.125)), format_utc(T0))
    assert database.execute('SELECT timestamp_utc FROM records').fetchone() == (format_utc(T0),)


@pytest.mark.parametrize('where', ['start', 'end', 'record', 'parsed_at'])
def test_storage_rejects_naive_without_partial_write(database, where):
    naive = T0.replace(tzinfo=None)
    value = parsed()
    if where == 'start': value = replace(value, start_time_utc=naive)
    if where == 'end': value = replace(value, end_time_utc=naive)
    if where == 'record': value = replace(value, records=(record(0, naive),))
    with pytest.raises(ValueError):
        store(database, value, when=naive if where == 'parsed_at' else T0)
    assert database.execute('SELECT count(*) FROM activities').fetchone() == (0,)


@pytest.mark.parametrize('bad', [float('nan'), float('inf'), b'bad', object()], ids=['nan', 'infinity', 'bytes', 'object'])
def test_storage_invalid_serializable_values_keep_old(database, bad):
    store(database)
    seed_reports(database)
    before = dump(database)
    with pytest.raises(FitStorageError):
        store(database, replace(parsed(), records=(ParsedRecord(T0, {'standard': {'f0': bad}}),)))
    assert dump(database) == before


@pytest.mark.parametrize('existing', [False, True], ids=['first-import', 'reimport'])
def test_real_import_transaction_child_failure_is_atomic(database, existing):
    if existing:
        store(database)
        seed_reports(database)
    before = dump(database)
    database.executescript("CREATE TRIGGER validator_fail BEFORE INSERT ON records WHEN NEW.record_index = 1 BEGIN SELECT RAISE(ABORT, 'validator child failure'); END;")
    with pytest.raises(sqlite3.IntegrityError, match='validator child failure'):
        store(database, replace(parsed(), summary={'messages': []}), when=T0 + timedelta(seconds=1))
    assert dump(database) == before


def test_file_boundary_sha_and_original_untouched(tmp_path):
    root = tmp_path / 'instance'
    file = root / 'states/activities/misleading-name.fit'
    file.parent.mkdir(parents=True)
    content = (EVIDENCE / 'fits/normal.fit').read_bytes()
    file.write_bytes(content)
    decoder = StorageBoundaryDecoder()
    ident = import_fit_file(root, file, decoder, parsed_at_utc=T0)
    assert ident == hashlib.sha256(content).hexdigest() and decoder.received == [content]
    with open_database(root / 'states/data.db') as c:
        assert c.execute('SELECT activity_id,fit_path FROM activities').fetchone() == (ident, 'states/activities/misleading-name.fit')
    assert file.read_bytes() == content


@pytest.mark.parametrize('method', ['traversal', 'absolute', 'symlink'])
def test_file_boundary_rejects_escape_before_decoder(tmp_path, method):
    root = tmp_path / 'instance'
    root.mkdir()
    outside = tmp_path / 'synthetic-outside.fit'
    outside.write_bytes((EVIDENCE / 'fits/normal.fit').read_bytes())
    decoder = StorageBoundaryDecoder()
    if method == 'traversal': path = Path('../synthetic-outside.fit')
    elif method == 'absolute': path = outside
    else:
        path = root / 'link.fit'
        path.symlink_to(outside)
    with pytest.raises(FitStorageError):
        import_fit_file(root, path, decoder)
    assert decoder.received == [] and not (root / 'states/data.db').exists()


def test_decoder_error_does_not_create_or_destroy_database(tmp_path):
    root = tmp_path / 'instance'
    file = root / 'states/activities/input.fit'
    file.parent.mkdir(parents=True)
    file.write_bytes((EVIDENCE / 'fits/normal.fit').read_bytes())
    class Failure:
        def decode(self, content):
            raise ValueError('injected decoder failure, not a real FIT parse')
    with pytest.raises(ValueError, match='injected decoder failure'):
        import_fit_file(root, file, Failure())
    assert not (root / 'states/data.db').exists()
    import_fit_file(root, file, StorageBoundaryDecoder(), parsed_at_utc=T0)
    with open_database(root / 'states/data.db') as c: before = dump(c)
    with pytest.raises(ValueError, match='injected decoder failure'):
        import_fit_file(root, file, Failure())
    with open_database(root / 'states/data.db') as c: assert dump(c) == before


def test_same_bytes_import_is_fully_idempotent(tmp_path):
    root = tmp_path / 'instance'
    file = root / 'states/activities/old.fit'
    file.parent.mkdir(parents=True)
    content = (EVIDENCE / 'fits/normal.fit').read_bytes()
    file.write_bytes(content)
    ident = import_fit_file(root, file, StorageBoundaryDecoder(), parsed_at_utc=T0)
    with open_database(root / 'states/data.db') as c: before = dump(c)
    alias = file.with_name('new-name.fit')
    alias.write_bytes(content)
    assert import_fit_file(root, alias, StorageBoundaryDecoder(), parsed_at_utc=T0 + timedelta(days=1)) == ident
    with open_database(root / 'states/data.db') as c: after = dump(c)
    print('before path/parsed_at:', before['activities'][0][1], before['activities'][0][7])
    print('after path/parsed_at:', after['activities'][0][1], after['activities'][0][7])
    assert before == after, 'Same FIT bytes must not modify valid row, original path, or parsed_at'


def test_reparse_with_report_requires_conflict_and_keeps_all_facts(database):
    store(database)
    seed_reports(database)
    before = dump(database)
    changed = replace(parsed(), records=(record(777),))
    caught = None
    try:
        store(database, changed, when=T0 + timedelta(days=1))
    except FitStorageError as error:
        caught = str(error.code)
    after = dump(database)
    print('error code:', caught, 'old records:', before['records'], 'new records:', after['records'], 'report unchanged:', before['activties_report'] == after['activties_report'])
    assert caught == 'REPARSE_CONFLICT', 'Changing report-dependent facts must explicitly fail before updating rows'
    assert after == before


def test_reparse_without_report_can_replace_atomically(database):
    store(database)
    value = replace(parsed(), records=(record(42),))
    store(database, value, when=T0 + timedelta(days=1))
    rows = database.execute('SELECT metrics_json FROM records').fetchall()
    assert len(rows) == 1 and json.loads(rows[0][0]) == value.records[0].metrics


def test_accepted_segments_container_can_be_stored(database):
    value = replace(parsed(), segments={'items': [message(1, 19)]})
    store(database, value)
    assert json.loads(database.execute('SELECT segments_json FROM activities').fetchone()[0]) == value.segments


def test_default_123_shape_and_minimal_dictionary(database):
    store(database)
    actual = get_activity_facts(database, SHA)
    print('actual facts:', json.dumps(actual, ensure_ascii=False, sort_keys=True))
    expected = {'activity_id', 'schema_version', 'basic_json', 'summary_json', 'segments_json', 'field_definitions', 'developer_sources'}
    assert set(actual) == expected, 'Default facts must contain only approved 123 containers and minimal field/source dictionaries'
    assert set(actual['field_definitions']) == {'f2'}
    assert actual['developer_sources'] == {}


def test_existing_public_contract_accepts_required_default_shape():
    data = {'activity_id': SHA, 'schema_version': 1, 'basic_json': parsed().basic, 'summary_json': parsed().summary, 'segments_json': {'items': []}, 'field_definitions': {'f2': field(18)}, 'developer_sources': {}}
    validate_payload('ActivityFacts', data)


def test_existing_public_contract_rejects_unknown_keys():
    data = {'activity_id': SHA, 'basic': {}, 'summary': {}, 'segments': [], 'sensors': {}, 'source_timestamps_utc': {}, 'unapproved': 'extra'}
    with pytest.raises(ValueError):
        validate_payload('ActivityFacts', data)


@pytest.mark.parametrize('case', ['undefined-field', 'missing-time-evidence', 'wrong-source', 'bad-definition', 'extra-container-key', 'inconsistent-sport', 'inconsistent-time', 'unsafe-integer', 'arbitrary-value-object'])
def test_storage_rejects_contract_invalid_json_before_commit(database, case):
    value = parsed()
    if case == 'undefined-field': value.records[0].metrics['standard']['f404'] = 1
    if case == 'missing-time-evidence': value.records[0].metrics.pop('time_evidence')
    if case == 'wrong-source': value.sensors['field_definitions']['f1']['source_ref'] = 'd404'
    if case == 'bad-definition': value.sensors['field_definitions']['f0']['origin'] = 'invented'
    if case == 'extra-container-key': value.basic['unapproved'] = True
    if case == 'inconsistent-sport': value.basic['sport'] = 'cycling'
    if case == 'inconsistent-time': value.basic['start_time_utc'] = format_utc(T0 + timedelta(days=1))
    if case == 'unsafe-integer': value.records[0].metrics['standard']['f0'] = 9007199254740993
    if case == 'arbitrary-value-object': value.records[0].metrics['standard']['f0'] = {'secret_metadata': 'synthetic'}
    rejected = False
    try:
        store(database, value)
    except (FitStorageError, ValueError):
        rejected = True
    print(case, 'rejected=', rejected, 'rows=', database.execute('SELECT count(*) FROM activities').fetchone()[0])
    assert rejected, f'Invalid {case} accepted and committed instead of failing full DTO validation'
    assert database.execute('SELECT count(*) FROM activities').fetchone() == (0,)


def test_unknown_activity_is_not_empty_success(database):
    with pytest.raises(FitStorageError) as raised:
        get_activity_facts(database, 'f' * 64)
    assert str(raised.value.code) == 'ACTIVITY_NOT_FOUND'
