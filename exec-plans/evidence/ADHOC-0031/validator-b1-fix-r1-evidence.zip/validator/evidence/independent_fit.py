"""Independent encoder: byte layouts/CRC from public-sources/protocol-content.txt.
Complete baseline summary fields from public-sources/activity-content.txt.
Does not import product or product tests. Synthetic values only.
"""
import struct
T = 1262304000

def crc(data):
    result=0
    for b in data:
        result ^= b
        for _ in range(8):
            result=(result >> 1) ^ (0xA001 if result & 1 else 0)
    return result

def frame(data, size=14, zero_crc=False):
    head=struct.pack('<BBHI4s',size,0x20,21400,len(data),b'.FIT')
    if size>=14:head += b'\0\0' if zero_crc else struct.pack('<H',crc(head))
    head += b'\0'*(size-len(head))
    return head+data+struct.pack('<H',crc(head+data))

def field(n,t,fmt,value,endian='<'):
    value=value if isinstance(value,(tuple,list)) else (value,)
    return n,t,struct.pack(endian+fmt,*value)

def text(n,value):return n,7,value.encode()+b'\0'

def definition(local,number,fields,dev=(),endian='<'):
    result=bytes([0x40|local|(0x20 if dev else 0),0,0 if endian=='<' else 1])+struct.pack(endian+'H',number)+bytes([len(fields)])
    result+=b''.join(bytes([n,len(encoded),t]) for n,t,encoded in fields)
    if dev:result+=bytes([len(dev)])+b''.join(bytes([n,len(encoded),index]) for index,n,encoded in dev)
    return result

def data(local,fields,dev=()):return bytes([local])+b''.join(v for _,_,v in fields)+b''.join(v for _,_,v in dev)

def message(number,fields,local=0,dev=(),endian='<'):
    return definition(local,number,fields,dev,endian)+data(local,fields,dev)

def file_id(endian='<'):
    return message(0,[field(0,0,'B',4),field(1,0x84,'H',1,endian),field(2,0x84,'H',1,endian),field(3,0x8c,'I',13579,endian),field(4,0x86,'I',T,endian)],endian=endian)

def summary(number=18,sport=1,start=T,elapsed=23125,index=0,endian='<',omit=()):
    fields=[field(253,0x86,'I',start+99,endian),field(2,0x86,'I',start,endian),field(7,0x86,'I',elapsed,endian),field(8,0x86,'I',17000,endian),field(254,0x84,'H',index,endian)]
    if number==18:fields +=[field(5,0,'B',sport),field(6,0,'B',0),field(25,0x84,'H',index,endian),field(26,0x84,'H',1,endian)]
    return message(number,[f for f in fields if f[0] not in omit],endian=endian)

def activity(sessions=1):return message(34,[field(253,0x86,'I',T+99),field(1,0x84,'H',sessions),field(5,0x86,'I',T+28800+99)])

def records(count=5,start=T,endian='<'):
    output=b''
    for i in range(count):
        stamp=start+[0,3,3,19,7][i%5]
        f=[field(253,0x86,'I',stamp,endian),field(3,2,'B',[0,124,255,133,140][i%5]),field(6,0x84,'H',2250,endian),field(2,0x84,'H',2530,endian)]
        if i==0:output+=definition(1,20,f,endian=endian)
        output+=data(1,f)
    return output

def body(count=5,start=T,sport=1,extra=b'',endian='<',omit=()):
    parts=[(0,file_id(endian)),(20,records(count,start,endian)),(19,summary(19,start=start,endian=endian)),(18,summary(18,sport,start,endian=endian)),(34,activity())]
    return b''.join(b for n,b in parts if n not in omit)+extra

def complete(**kwargs):return frame(body(**kwargs))

def developer(index=0,number=0,unit='ms',scale=1,name='synthetic',type_id=0x84):
    source=message(207,[field(3,2,'B',index),field(2,0x84,'H',1), (1,13,bytes(range(16)))])
    desc=message(206,[field(0,2,'B',index),field(1,2,'B',number),field(2,2,'B',type_id),text(3,name),field(6,2,'B',scale),field(7,1,'b',0),text(8,unit)])
    return source+desc
