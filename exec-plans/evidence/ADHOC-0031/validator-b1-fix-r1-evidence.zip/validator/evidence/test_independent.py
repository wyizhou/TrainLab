import copy
import hashlib
import json
import shutil
import sqlite3
import struct
import threading
import time
from dataclasses import replace
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
from garmin_fit_sdk import Decoder, Stream

from independent_fit import T, activity, body, complete, crc, data, definition, developer, field, file_id, frame, message, records, summary, text
from trainlab.check_architecture import check_layout
from trainlab.contracts.json_validation import loads, validate
from trainlab.contracts.time import format_utc
from trainlab.database import read_view, write_gate
from trainlab.fit import import_fit_file, storage
from trainlab.fit.parser import ProfileFitDecoder

ROOT=Path(__file__).resolve().parent.parent
TABLES=('activities','records','activties_report','weekly_report','config')
NOW=datetime(2031,2,3,tzinfo=UTC)

def dump(connection):
    return {n:connection.execute(f'SELECT * FROM {n} ORDER BY 1,2').fetchall() for n in TABLES}

def seed(c,ident,report=True):
    with c:
        if report:c.execute('INSERT INTO activties_report VALUES(?,NULL,?)',(ident,'合成报告全文\n第二行'))
        c.execute('INSERT INTO weekly_report(run_time_utc,summary) VALUES(?,?)',(format_utc(NOW),'历史周报全文'))
        c.execute('INSERT INTO config VALUES(?,?,?)',('synthetic','{"x":1}',format_utc(NOW)))

def prepare(tmp_path,content=None):
    b=complete() if content is None else content
    p=tmp_path/'original.fit';p.write_bytes(b)
    ident=import_fit_file(tmp_path,p,parsed_at_utc=NOW)
    return p,ident,storage.open_database(tmp_path/'states/data.db')

def keyed(parsed,fields):
    return {(parsed.sensors['field_definitions'][k]['name'],parsed.sensors['field_definitions'][k]['origin']):v for k,v in fields.items()}

@pytest.mark.parametrize('endian',['<','>'])
@pytest.mark.parametrize('size,zero',[(12,False),(14,False),(14,True),(18,False)])
def test_V001_complete_real_entry(tmp_path,endian,size,zero):
    b=frame(body(endian=endian),size,zero)
    assert crc(b)==0
    p,ident,c=prepare(tmp_path,b)
    assert ident==hashlib.sha256(b).hexdigest()
    row=c.execute('SELECT * FROM activities').fetchone()
    assert row[1]=='original.fit' and row[2:4]==('running','generic')
    assert row[5]==format_utc(datetime(1989,12,31,tzinfo=UTC)+timedelta(seconds=T+23.125))
    assert row[5]!=row[4] and row[7]==format_utc(NOW)
    rr=c.execute('SELECT record_index,timestamp_utc,metrics_json FROM records ORDER BY record_index').fetchall()
    assert [r[0] for r in rr]==list(range(5)) and rr[1][1]==rr[2][1] and rr[3][1]>rr[4][1]
    parsed=ProfileFitDecoder().decode(b)
    expected=[0,124,None,133,140]
    for i,r in enumerate(rr):
        v=keyed(parsed,json.loads(r[2])['standard'])
        assert v['heart_rate','direct']==expected[i]
        assert v['speed','direct']==2.25 and v['altitude','direct']==6
    assert p.read_bytes()==b
    assert c.execute('PRAGMA foreign_key_check').fetchall()==[]
    assert [len(c.execute(f'PRAGMA table_info({n})').fetchall()) for n in TABLES]==[12,4,3,3,3]
    assert c.execute('PRAGMA foreign_keys').fetchone()==(1,)
    c.close()

def test_V001_sdk_crosscheck_not_only_oracle():
    b=complete()
    sdk,errors=Decoder(Stream.from_byte_array(bytearray(b))).read(merge_heart_rates=False)
    assert errors==[]
    assert len(sdk['record_mesgs'])==5
    assert sdk['record_mesgs'][0]['speed']==2.25
    assert sdk['session_mesgs'][0]['total_elapsed_time']==23.125
    assert sdk['lap_mesgs'][0]['total_timer_time']==17

def test_V001_full_long_sequence(tmp_path):
    p,ident,c=prepare(tmp_path,complete(count=30007))
    rr=c.execute('SELECT record_index,timestamp_utc,metrics_json FROM records ORDER BY record_index').fetchall()
    assert len(rr)==30007
    defs=json.loads(c.execute('SELECT sensors_json FROM activities').fetchone()[0])['field_definitions']
    hr=next(k for k,d in defs.items() if d['message_number']==20 and d['name']=='heart_rate')
    for i,r in enumerate(rr):
        assert r[0]==i
        assert r[1]==format_utc(datetime(1989,12,31,tzinfo=UTC)+timedelta(seconds=T+[0,3,3,19,7][i%5]))
        assert json.loads(r[2])['standard'][hr]==[0,124,None,133,140][i%5]
    assert len(storage.get_activity_facts(c,ident)['segments_json']['items'])==1
    c.close()

@pytest.mark.parametrize('kind',['relative','invalid','missing'])
def test_V001_time_evidence(tmp_path,kind):
    fs=[field(3,2,'B',0)]
    if kind!='missing':fs.insert(0,field(253,0x86,'I',123 if kind=='relative' else 0xffffffff))
    p,ident,c=prepare(tmp_path,complete(extra=message(20,fs)))
    stamp,metrics=c.execute('SELECT timestamp_utc,metrics_json FROM records WHERE record_index=5').fetchone()
    assert stamp is None
    assert json.loads(metrics)['time_evidence']==dict(kind=kind,raw=123 if kind=='relative' else None,unit=None if kind=='missing' else 's')
    c.close()

def test_V001_multisession_and_chain(tmp_path):
    b=frame(body(omit=(34,))+summary(19,index=1,start=T+60)+summary(18,2,T+60,index=1)+activity(2))+complete(start=T+120,sport=5)
    p,ident,c=prepare(tmp_path,b)
    facts=storage.get_activity_facts(c,ident)
    assert facts['basic_json']['sport'] is None
    assert len(facts['summary_json']['messages'])==3
    assert [m['chain_index'] for m in facts['summary_json']['messages']]==[0,0,1]
    assert c.execute('SELECT count(*) FROM records').fetchone()==(10,)
    c.close()

def test_V001_compressed_and_redefinitions(tmp_path):
    f=[field(253,0x86,'I',T+31),field(3,2,'B',120)]
    b=message(20,f,local=2)
    b+=bytes([0x80|(2<<5)|2,121])
    f2=[field(3,2,'B',122)]
    b+=definition(2,20,f2)+bytes([0x80|(2<<5)|4,122])
    p,ident,c=prepare(tmp_path,complete(extra=b))
    rr=c.execute('SELECT timestamp_utc,metrics_json FROM records WHERE record_index>=5 ORDER BY record_index').fetchall()
    assert [r[0] for r in rr]==[format_utc(datetime(1989,12,31,tzinfo=UTC)+timedelta(seconds=T+x)) for x in (31,34,36)]
    ids=[list(json.loads(r[1])['standard']) for r in rr]
    assert ids[0]==ids[1] and ids[1]!=ids[2]
    c.close()

def test_V001_components_and_array_bytes(tmp_path):
    extra=message(20,[field(253,0x86,'I',T+25),field(5,0x86,'I',10000),field(3,2,'B',120)])
    packed=(255|(1608<<12)).to_bytes(3,'little')
    extra+=message(20,[field(253,0x86,'I',T+26),(8,13,packed),field(73,0x86,'I',8000)])
    extra+=message(132,[(10,13,(100|(200<<12)|(300<<24)|(400<<36)).to_bytes(6,'little'))])
    p,ident,c=prepare(tmp_path,complete(extra=extra))
    parsed=ProfileFitDecoder().decode(p.read_bytes())
    fs=keyed(parsed,parsed.records[-1].metrics['standard'])
    assert fs['speed','expanded']==2.55 and fs['distance','expanded']==100.5
    assert fs['enhanced_speed','direct']==8 and fs['enhanced_speed','expanded']==2.55
    m=next(m for m in parsed.sensors['messages'] if m['message_number']==132)
    assert keyed(parsed,m['fields']['standard'])['event_timestamp','expanded']==[100/1024,200/1024,300/1024,400/1024]
    c.close()

def test_V001_developers_redefinition_privacy(tmp_path):
    extra=developer(0)+developer(1)
    f=[field(253,0x86,'I',T+30),field(3,2,'B',0)]
    extra+=message(20,f,local=2,dev=((0,0,struct.pack('<H',20)),(1,0,struct.pack('<H',65535))))
    extra+=developer(0,scale=2)
    extra+=message(20,f,local=2,dev=((0,0,struct.pack('<H',20)),(1,0,struct.pack('<H',0))))
    extra+=message(3,[text(0,'SYNTHETIC_PRIVATE_NAME'),field(1,0,'B',1)])
    p,ident,c=prepare(tmp_path,complete(extra=extra))
    parsed=ProfileFitDecoder().decode(p.read_bytes())
    one,two=(r.metrics['developer'] for r in parsed.records[-2:])
    assert list(one.values())==[20,None] and list(two.values())==[10,0]
    ds=parsed.sensors['field_definitions']
    assert ds[next(iter(one))]['source_ref']!=ds[next(iter(two))]['source_ref']
    assert len(parsed.sensors['developer_sources'])==3
    js=json.dumps(parsed.sensors)
    assert 'SYNTHETIC_PRIVATE_NAME' not in js and 'serial_number' not in js and 'application_id' not in js
    c.close()

def test_V001_unknown_fields_and_native_segments(tmp_path):
    extra=message(0xff00,[field(0,0x8f,'Q',9007199254740993),(1,13,b'\x01\xff\x02'),field(2,0x84,'3H',(0,65535,23)),field(3,0x88,'f',1.5)])
    for num in (101,142,225,312,313):extra+=message(num,[(250,0x86,struct.pack('<I',0))])
    p,ident,c=prepare(tmp_path,complete(extra=extra))
    parsed=ProfileFitDecoder().decode(p.read_bytes())
    m=next(x for x in parsed.sensors['messages'] if x['message_number']==0xff00)
    assert list(m['fields']['standard'].values())==[{'integer':'9007199254740993'},{'bytes_hex':'01ff02'},[0,None,23],1.5]
    assert m['message_name'] is None
    facts=storage.get_activity_facts(c,ident)
    assert [m['message_number'] for m in facts['segments_json']['items']]==[19,101,142,225,312,313]
    c.close()

@pytest.mark.parametrize('case',['crc','truncated','tail','undefined','missing-session','missing-lap','zero-record','missing-activity','duplicate-file','bad-chain','bad-base','bad-size','nonfinite','unknown-developer','duplicate-field'])
def test_V001_malformed_does_not_create_database(tmp_path,case):
    b=complete()
    if case=='crc':b=b[:-1]+bytes([b[-1]^64])
    elif case=='truncated':b=b[:-3]
    elif case=='tail':b+=b'garbage'
    elif case=='undefined':b=frame(body(extra=b'\x0f'))
    elif case=='missing-session':b=complete(omit=(18,))
    elif case=='missing-lap':b=complete(omit=(19,))
    elif case=='zero-record':b=complete(count=0)
    elif case=='missing-activity':b=complete(omit=(34,))
    elif case=='duplicate-file':b=complete(extra=file_id())
    elif case=='bad-chain':b+=complete(omit=(34,))
    elif case=='bad-base':b=complete(extra=message(65000,[(0,31,b'\0')]))
    elif case=='bad-size':b=complete(extra=message(65000,[(0,0x84,b'\0')]))
    elif case=='nonfinite':b=complete(extra=message(65000,[field(0,0x88,'f',float('inf'))]))
    elif case=='unknown-developer':b=complete(extra=message(20,[field(253,0x86,'I',T)],dev=((1,0,b'\0\0'),)))
    elif case=='duplicate-field':b=complete(extra=message(20,[field(3,2,'B',1),field(3,2,'B',2)]))
    p=tmp_path/'bad.fit';p.write_bytes(b)
    with pytest.raises(ValueError):import_fit_file(tmp_path,p)
    assert not (tmp_path/'states/data.db').exists() and p.read_bytes()==b

@pytest.mark.parametrize('case',['invalid-field-255','empty-session','empty-lap','empty-record'])
def test_V001_required_structure_not_empty_success(tmp_path,case):
    if case=='invalid-field-255':b=complete(extra=message(20,[field(253,0x86,'I',T+27),field(255,2,'B',7)]))
    else:
        n={'empty-session':18,'empty-lap':19,'empty-record':20}[case]
        b=complete(omit=(n,),extra=message(n,[]))
    p=tmp_path/'invalid-structure.fit';p.write_bytes(b)
    with pytest.raises(ValueError):import_fit_file(tmp_path,p)
    assert not (tmp_path/'states/data.db').exists()

@pytest.mark.parametrize('case',['root-package','tools-python','skill-outside-scripts','sys-insert','sys-assignment','tools-shell','root-runtime'])
def test_V002_negative_architecture(tmp_path,case):
    snapshot=json.loads((ROOT/'review-snapshot.json').read_text())
    for item in snapshot['items']:
        rel=Path(item['path'])
        if rel.parts[0]!='source':continue
        target=tmp_path.joinpath(*rel.parts[1:]);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/rel,target)
    check_layout(tmp_path)
    paths={'root-package':('trainlab/new.py','x=1'),'tools-python':('tools/new.py','x=1'),'skill-outside-scripts':('skills/fit-store/new.py','x=1'),'sys-insert':('skills/_shared/scripts/probe.py','import sys\nsys.path.insert(0,"x")'),'sys-assignment':('skills/_shared/scripts/probe.py','import sys\nsys.path = ["x"] + sys.path'),'tools-shell':('tools/probe.sh','#!/bin/sh\nexit 0'),'root-runtime':('service.py','def run(): return 123')}
    rel,content=paths[case];p=tmp_path/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content)
    with pytest.raises(ValueError):check_layout(tmp_path)

MUTATIONS=['segments-list','segments-extra','record-extra','basic-extra','nonfinite','bad-value-object','large-unwrapped','undefined-id','bad-category','absent-source','crosschain-source','component-absent','component-cycle','component-identity','definition-extra','message-order','message-identity','sql-sport','sql-start','missing-time-evidence','time-evidence-mismatch','timestamp-field-mismatch','record-message-name','definition-message-name']
@pytest.mark.parametrize('case',MUTATIONS)
def test_V003_single_mutation_real_repository(tmp_path,case):
    p,ident,c=prepare(tmp_path);seed(c,ident)
    v=ProfileFitDecoder().decode(p.read_bytes())
    storage.import_activity(c,activity_id='b'*64,fit_path='baseline.fit',parsed=copy.deepcopy(v),parsed_at_utc=NOW)
    before=dump(c)
    v=copy.deepcopy(v);defs=v.sensors['field_definitions'];r=v.records[0].metrics
    k=next(k for k,d in defs.items() if d['message_number']==20 and d['name']=='heart_rate')
    ts=next(k for k,d in defs.items() if d['message_number']==20 and d['name']=='timestamp')
    if case=='segments-list':v=replace(v,segments=[])
    elif case=='segments-extra':v.segments['extra']=1
    elif case=='record-extra':r['extra']=1
    elif case=='basic-extra':v.basic['extra']=1
    elif case=='nonfinite':r['standard'][k]=float('nan')
    elif case=='bad-value-object':r['standard'][k]={'data':1}
    elif case=='large-unwrapped':r['standard'][k]=9007199254740993
    elif case=='undefined-id':r['standard']['f999']=1
    elif case=='bad-category':r['developer'][k]=r['standard'].pop(k)
    elif case=='absent-source':defs[k]['source_ref']='d99'
    elif case=='crosschain-source':
        defs[k]['source_ref']='d0';r['developer'][k]=r['standard'].pop(k);v.sensors['developer_sources']['d0']=dict(chain_index=99,developer_data_index=0,application_name=None,manufacturer=None)
    elif case=='component-absent':defs[k].update(origin='expanded',component_of='f999')
    elif case=='component-cycle':defs[k].update(origin='expanded',component_of=k)
    elif case=='component-identity':defs[k].update(origin='expanded',component_of=next(x for x,d in defs.items() if d['message_number']==18))
    elif case=='definition-extra':defs[k]['extra']=1
    elif case=='message-order':v.basic['messages'].reverse()
    elif case=='message-identity':v.segments['items'][0]['chain_index']=2
    elif case=='sql-sport':v.basic['sport']='cycling'
    elif case=='sql-start':v.basic['start_time_utc']=format_utc(NOW)
    elif case=='missing-time-evidence':r.pop('time_evidence')
    elif case=='time-evidence-mismatch':r['time_evidence']['raw']+=1
    elif case=='timestamp-field-mismatch':r['standard'][ts]+=1000
    elif case=='record-message-name':defs[k]['message_name']='session'
    elif case=='definition-message-name':v.summary['messages'][0]['message_name']='record'
    try:
        with pytest.raises(ValueError):storage.import_activity(c,activity_id='c'*64,fit_path='new.fit',parsed=v,parsed_at_utc=NOW)
        assert dump(c)==before
    finally:c.close()

def test_V004_exact_minimal_closure(tmp_path):
    extra=developer(0)+developer(1)
    extra+=message(18,[field(253,0x86,'I',T+99),field(2,0x86,'I',T),field(7,0x86,'I',23125),field(8,0x86,'I',17000),field(5,0,'B',1),field(18,2,'B',90)],dev=((0,0,struct.pack('<H',30)),))
    extra+=message(19,[field(253,0x86,'I',T+99),field(2,0x86,'I',T),field(7,0x86,'I',23125),field(8,0x86,'I',17000)])
    extra+=message(20,[field(253,0x86,'I',T+31),field(3,2,'B',120)],dev=((1,0,struct.pack('<H',40)),))
    extra+=activity(2)
    p,ident,c=prepare(tmp_path,complete(omit=(34,),extra=extra))
    facts=storage.get_activity_facts(c,ident)
    assert set(facts)=={'activity_id','schema_version','basic_json','summary_json','segments_json','field_definitions','developer_sources'}
    validate('ActivityFacts',facts)
    parsed=ProfileFitDecoder().decode(p.read_bytes())
    assert facts['basic_json']==parsed.basic and facts['summary_json']==parsed.summary and facts['segments_json']==parsed.segments
    required={k for m in parsed.basic['messages']+parsed.summary['messages']+parsed.segments['items'] for category in ('standard','developer') for k in m['fields'][category]}
    for k in list(required):
        parent=parsed.sensors['field_definitions'][k]['component_of']
        while parent is not None:
            required.add(parent);parent=parsed.sensors['field_definitions'][parent]['component_of']
    assert set(facts['field_definitions'])==required
    assert set(facts['developer_sources'])=={'d0'}
    assert all(d['message_number']!=20 for d in facts['field_definitions'].values())
    c.close()

def test_V005_actual_duplicate_different_filename(tmp_path):
    p,ident,c=prepare(tmp_path);seed(c,ident);before=dump(c);dbbytes=(tmp_path/'states/data.db').read_bytes();b=p.read_bytes()
    alias=tmp_path/'unknown-alias.fit';alias.write_bytes(b)
    assert import_fit_file(tmp_path,alias,parsed_at_utc=NOW+timedelta(days=5))==ident
    assert dump(c)==before and (tmp_path/'states/data.db').read_bytes()==dbbytes
    assert p.read_bytes()==b and alias.read_bytes()==b
    c.close()

def test_V006_maintenance_sha_noop_conflict_update_rollback(tmp_path):
    p,ident,c=prepare(tmp_path);seed(c,ident,report=False);good=p.read_bytes();before=dump(c)
    storage.reparse_fit_file(tmp_path,ident,parsed_at_utc=NOW+timedelta(days=1))
    assert dump(c)==before
    p.write_bytes(good+b'altered')
    with pytest.raises(ValueError,match='SOURCE_CONFLICT'):storage.reparse_fit_file(tmp_path,ident)
    assert dump(c)==before
    p.write_bytes(good)
    old=ProfileFitDecoder().decode(good)
    # Deliberately install a previous valid interpretation; maintenance itself uses real default decoder.
    changed=copy.deepcopy(old);k=next(k for k,d in changed.sensors['field_definitions'].items() if d['name']=='heart_rate')
    changed.records[0].metrics['standard'][k]=199
    storage.replace_activity(c,activity_id=ident,parsed=changed,parsed_at_utc=NOW)
    with c:c.execute('INSERT INTO activties_report VALUES(?,NULL,?)',(ident,'依赖旧事实报告'))
    stale=dump(c)
    with pytest.raises(ValueError,match='REPARSE_CONFLICT'):storage.reparse_fit_file(tmp_path,ident)
    assert dump(c)==stale
    with c:c.execute('DELETE FROM activties_report WHERE activity_id=?',(ident,))
    stale=dump(c)
    c.execute("CREATE TRIGGER reject_child BEFORE INSERT ON records WHEN NEW.record_index=2 BEGIN SELECT RAISE(ABORT,'independent-child-failure'); END")
    with pytest.raises(sqlite3.IntegrityError,match='independent-child-failure'):storage.reparse_fit_file(tmp_path,ident)
    assert dump(c)==stale
    c.execute('DROP TRIGGER reject_child')
    storage.reparse_fit_file(tmp_path,ident,parsed_at_utc=NOW+timedelta(days=2))
    after=dump(c)
    assert after['records']==before['records'] and after['weekly_report']==before['weekly_report'] and after['config']==before['config']
    assert after['activities'][0][1]==before['activities'][0][1]
    assert after['activities'][0][7]==format_utc(NOW+timedelta(days=2))
    assert p.read_bytes()==good
    c.close()

def test_initial_real_import_transaction_rollback_and_foreign_key(tmp_path):
    db=tmp_path/'states/data.db';storage.init_database(db)
    c=storage.open_database(db)
    with c:
        c.execute('INSERT INTO weekly_report(run_time_utc,summary) VALUES(?,?)',(format_utc(NOW),'周报'))
        c.execute('INSERT INTO config VALUES(?,?,?)',('synthetic','{}',format_utc(NOW)))
    before=dump(c)
    c.execute("CREATE TRIGGER reject_child BEFORE INSERT ON records WHEN NEW.record_index=2 BEGIN SELECT RAISE(ABORT,'independent-child-failure'); END")
    p=tmp_path/'first.fit';p.write_bytes(complete())
    with pytest.raises(sqlite3.IntegrityError,match='independent-child-failure'):import_fit_file(tmp_path,p)
    assert dump(c)==before
    with pytest.raises(sqlite3.IntegrityError):c.execute('INSERT INTO records VALUES(?,?,?,?)',('f'*64,0,None,'{}'))
    c.rollback();c.close()

def test_readonly_view_actual_writer_waits_then_commits(tmp_path):
    p,ident,c=prepare(tmp_path);c.close()
    second=tmp_path/'second.fit';second.write_bytes(complete(sport=2))
    started=threading.Event();done=threading.Event();errors=[]
    def writer():
        started.set()
        try:import_fit_file(tmp_path,second)
        except Exception as e:errors.append(repr(e))
        finally:done.set()
    with read_view(tmp_path/'states/data.db') as view:
        before=view.execute('SELECT count(*) FROM activities').fetchone()
        with pytest.raises(sqlite3.OperationalError):view.execute('DELETE FROM records')
        t=threading.Thread(target=writer);t.start();assert started.wait(1)
        assert not done.wait(.2)
        assert view.execute('SELECT count(*) FROM activities').fetchone()==before==(1,)
    t.join(10);assert done.is_set() and not errors
    with read_view(tmp_path/'states/data.db') as view:assert view.execute('SELECT count(*) FROM activities').fetchone()==(2,)
    assert sorted(x.name for x in (tmp_path/'states').iterdir())==['data.db']

@pytest.mark.parametrize('s',['{"x":1,"x":2}','{"x":NaN}','{"x":Infinity}','{"x":-Infinity}','{"x":9007199254740993}'])
def test_b0_strict_json(s):
    with pytest.raises(ValueError):loads(s)
