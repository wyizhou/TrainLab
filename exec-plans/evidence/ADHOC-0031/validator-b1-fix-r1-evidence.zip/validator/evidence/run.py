import subprocess,sys,json,time
from pathlib import Path
root=Path(__file__).resolve().parent.parent
name,cwd,*command=sys.argv[1:]
start=time.time()
r=subprocess.run(command,cwd=root/cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
entry={'name':name,'cwd':cwd,'command':command,'exit_code':r.returncode,'seconds':round(time.time()-start,3)}
(root/'evidence'/f'{name}.log').write_text(json.dumps(entry,ensure_ascii=False)+'\n'+r.stdout)
with (root/'evidence/commands.jsonl').open('a') as f:f.write(json.dumps(entry,ensure_ascii=False)+'\n')
print(json.dumps(entry,ensure_ascii=False));print(r.stdout[-7000:]);sys.exit(r.returncode)
