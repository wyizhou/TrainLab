import copy,hashlib,json,sqlite3
from pathlib import Path
from independent_fit import T,complete,field,message
from test_independent import NOW,prepare,seed,dump
from trainlab.fit import storage,import_fit_file
from trainlab.fit.parser import ProfileFitDecoder

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'reproduction-data';BASE.mkdir(exist_ok=False)
results=[]
for case in ['invalid-field-255','empty-session','empty-lap','empty-record']:
    p=BASE/case;p.mkdir()
    if case=='invalid-field-255':b=complete(extra=message(20,[field(253,0x86,'I',T+27),field(255,2,'B',7)]))
    else:
        n={'empty-session':18,'empty-lap':19,'empty-record':20}[case]
        b=complete(omit=(n,),extra=message(n,[]))
    f=p/'invalid.fit';f.write_bytes(b)
    ident=import_fit_file(p,f)
    with sqlite3.connect(p/'states/data.db') as c:
        facts=storage.get_activity_facts(c,ident)
        records=c.execute('SELECT record_index,timestamp_utc,metrics_json FROM records ORDER BY record_index').fetchall()
    results.append(dict(issue='V31-B1-001',case=case,expected='reject without database',actual='successful import and ActivityFacts',activity_id=ident,facts=facts,records=records))
for case in ['timestamp-field-mismatch','record-message-name','definition-message-name']:
    p=BASE/case;p.mkdir()
    f,ident,c=prepare(p);seed(c,ident)
    v=ProfileFitDecoder().decode(f.read_bytes())
    storage.import_activity(c,activity_id='b'*64,fit_path='legal-baseline.fit',parsed=copy.deepcopy(v),parsed_at_utc=NOW)
    before=dump(c);v=copy.deepcopy(v)
    defs=v.sensors['field_definitions']
    k=next(k for k,d in defs.items() if d['message_number']==20 and d['name']=='heart_rate')
    ts=next(k for k,d in defs.items() if d['message_number']==20 and d['name']=='timestamp')
    if case=='timestamp-field-mismatch':v.records[0].metrics['standard'][ts]+=1000
    if case=='record-message-name':defs[k]['message_name']='session'
    if case=='definition-message-name':v.summary['messages'][0]['message_name']='record'
    storage.import_activity(c,activity_id='c'*64,fit_path='bad-dto.fit',parsed=v,parsed_at_utc=NOW)
    after=dump(c)
    results.append(dict(issue='V31-B1-003',case=case,expected='reject and keep all five tables',actual='invalid new activity persisted',before_counts={k:len(v) for k,v in before.items()},after_counts={k:len(v) for k,v in after.items()},new_activity=after['activities'][-1],new_records=[r for r in after['records'] if r[0]=='c'*64]))
    c.close()
(ROOT/'reproduction-details.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps([{k:v for k,v in r.items() if k in ('issue','case','expected','actual','before_counts','after_counts')} for r in results],ensure_ascii=False,indent=2))
