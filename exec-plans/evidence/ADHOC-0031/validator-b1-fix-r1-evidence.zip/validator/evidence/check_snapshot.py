import hashlib,json,stat,sys
from pathlib import Path
root=Path(__file__).resolve().parent.parent
snapshot=json.loads((root/'review-snapshot.json').read_text())
items=[]
for original in snapshot['items']:
 p=root/original['path'];s=p.stat()
 items.append(dict(path=original['path'],sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=s.st_size,mode=oct(stat.S_IMODE(s.st_mode))))
result={'count':len(items),'aggregate':hashlib.sha256(json.dumps(items,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'differences':[{'expected':a,'actual':b} for a,b in zip(snapshot['items'],items) if a!=b],'git_metadata_present':(root/'.git').exists(),'items':items}
(root/'evidence'/f'hashes-{sys.argv[1]}.json').write_text(json.dumps(result,indent=2))
print({k:v for k,v in result.items() if k!='items'})
assert not result['differences'] and result['aggregate']==snapshot['product_aggregate_sha256']
