from pathlib import Path
import hashlib,importlib,importlib.metadata,json,re,sys,tomllib
root=Path(__file__).resolve().parent.parent
config=tomllib.loads((root/'source/pyproject.toml').read_text())
rows=[]
for package,relative in config['tool']['setuptools']['package-dir'].items():
 installed=Path(importlib.import_module(package).__file__).parent
 for original in (root/'source'/relative).iterdir():
  if original.suffix not in ('.py','.json') and original.name!='py.typed':continue
  actual=installed/original.name
  assert actual.is_relative_to(root/'evidence/venv'),actual
  a=hashlib.sha256(original.read_bytes()).hexdigest();b=hashlib.sha256(actual.read_bytes()).hexdigest()
  assert a==b,(original,actual)
  rows.append({'source':str(original.relative_to(root)),'installed':str(actual),'sha256':a})
versions={d.metadata['Name']:d.version for d in importlib.metadata.distributions()}
lock=tomllib.loads((root/'source/uv.lock').read_text())
normalize=lambda name: re.sub(r'[-_.]+','-',name).lower()
locked={normalize(p['name']):p['version'] for p in lock['package']}
for name,version in versions.items():
 assert locked[normalize(name)]==version,(name,version)
print(json.dumps({'python':sys.version,'modules_and_schemas':rows,'all_installed_versions_match_lock':True,'versions':versions},indent=2))
