import json
import sqlite3
from pathlib import Path
import pytest
from independent_fit import complete
from test_independent import prepare,seed,dump
from trainlab.fit import storage,import_fit_file
from trainlab.database import read_view,write_gate

@pytest.mark.parametrize('case',['crc','later-chain','bad-structure'])
def test_invalid_actual_import_preserves_existing_five_tables(tmp_path,case):
    p,ident,c=prepare(tmp_path);seed(c,ident);before=dump(c)
    b=complete()
    if case=='crc':b=b[:-1]+bytes([b[-1]^1])
    elif case=='later-chain':b+=complete()[:-1]
    else:b=complete(omit=(18,))
    bad=tmp_path/'bad.fit';bad.write_bytes(b)
    with pytest.raises(ValueError):import_fit_file(tmp_path,bad)
    assert dump(c)==before and bad.read_bytes()==b
    c.close()


def test_rollback_journal_only_and_read_view_no_create(tmp_path):
    missing=tmp_path/'missing.db'
    with pytest.raises(sqlite3.OperationalError):
        with read_view(missing):pass
    assert not missing.exists()
    p,ident,c=prepare(tmp_path);c.close()
    path=tmp_path/'states/data.db'
    c=sqlite3.connect(path);assert c.execute('PRAGMA journal_mode=WAL').fetchone()==('wal',);c.close()
    with pytest.raises(ValueError):storage.open_database(path)
    with pytest.raises(ValueError):
        with read_view(path):pass
    with pytest.raises(ValueError):storage.reparse_fit_file(tmp_path,ident)


def test_read_view_timeout_and_release(tmp_path):
    p,ident,c=prepare(tmp_path);c.close()
    with read_view(tmp_path/'states/data.db'):
        with pytest.raises(ValueError,match='RUN_BUSY'):
            with write_gate(timeout=.01):pass
    with write_gate(timeout=.01):pass


def test_zero_dto_collection_and_absent_id_are_distinct(tmp_path):
    from dataclasses import replace
    from trainlab.fit.parser import ProfileFitDecoder
    p,ident,c=prepare(tmp_path)
    baseline=ProfileFitDecoder().decode(p.read_bytes())
    # Repository DTO format supports an empty collection. This does NOT assert a
    # zero-record FIT Activity is protocol-valid, or implement the B2 query API.
    storage.import_activity(c,activity_id='e'*64,fit_path='synthetic-dto.fit',parsed=replace(baseline,records=()))
    assert c.execute('SELECT count(*) FROM records WHERE activity_id=?',('e'*64,)).fetchone()==(0,)
    assert storage.get_activity_facts(c,'e'*64)['activity_id']=='e'*64
    with pytest.raises(ValueError,match='ACTIVITY_NOT_FOUND'):storage.get_activity_facts(c,'f'*64)
    c.close()
