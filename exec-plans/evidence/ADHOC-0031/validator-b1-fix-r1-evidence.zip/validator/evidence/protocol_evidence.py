import hashlib,inspect,json
from pathlib import Path
from garmin_fit_sdk import CrcCalculator
from garmin_fit_sdk.profile import Profile
import garmin_fit_sdk.profile as profile_module
from independent_fit import complete,crc
root=Path(__file__).resolve().parent.parent
profile_file=Path(inspect.getfile(profile_module))
values={'official_texts':{},'sdk_profile_sha256':hashlib.sha256(profile_file.read_bytes()).hexdigest(),'profile_fields':{},'date_time_type':Profile['types']['date_time'],'crc_agrees_with_sdk':crc(complete())==CrcCalculator.calculate_crc(complete(),0,len(complete()))==0}
for name in ('activity-content.txt','protocol-content.txt'):
 p=root/'public-sources'/name
 values['official_texts'][name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size}
for m,f in ((132,9),(132,10),(20,253),(20,8),(20,6),(20,2),(18,7),(18,8)):
 values['profile_fields'][f'{m}.{f}']=Profile['messages'][m]['fields'][f]
print(json.dumps(values,ensure_ascii=False,indent=2))
