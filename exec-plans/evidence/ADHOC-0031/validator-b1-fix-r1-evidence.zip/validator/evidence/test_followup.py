import hashlib
import json
import re
import shutil
import sqlite3
from datetime import UTC,datetime,timedelta,timezone
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from garmin_fit_sdk import Decoder,Stream
from garmin_fit_sdk.profile import Profile

from independent_fit import T,complete,field,message
from test_independent import ROOT,NOW,prepare,keyed,dump,seed
from trainlab.fit import storage
from trainlab.fit.parser import ProfileFitDecoder
from trainlab.contracts.paths import WEB_STATIC_DIR,validate_static_mount
from trainlab.contracts.session import InMemoryConversationHistory
from trainlab.contracts.time import format_utc,utc_fit_date,next_activity_report_run_utc,weekly_window
from trainlab.local_web.server import create_app,app_contract


def test_V001_accumulated_hr_array_seeds_later_components(tmp_path):
    # Profile 21.214.0 hr.event_timestamp: uint32[], scale 1024, accumulated;
    # hr.event_timestamp_12: 12-bit repeated components, same destination and scale.
    assert Profile['messages'][132]['fields'][9]['is_accumulated']
    assert Profile['messages'][132]['fields'][9]['scale']==[1024]
    extra=message(132,[field(9,0x86,'2I',(10240,11264))])
    extra+=message(132,[(10,13,(0|(1024<<12)).to_bytes(3,'little'))])
    b=complete(extra=extra)
    sdk,errors=Decoder(Stream.from_byte_array(bytearray(b))).read(merge_heart_rates=False)
    assert errors==[] and sdk['hr_mesgs'][-1]['event_timestamp']==[12,13]
    p,ident,c=prepare(tmp_path,b)
    sensors=json.loads(c.execute('SELECT sensors_json FROM activities').fetchone()[0])
    last=next(m for m in reversed(sensors['messages']) if m['message_number']==132)
    actual={sensors['field_definitions'][k]['name']:v for k,v in last['fields']['standard'].items()}
    c.close()
    assert actual['event_timestamp']==[12,13],actual


def test_V001_valid_profile_timestamp_threshold_raw_value(tmp_path):
    start=0x10000000
    p,ident,c=prepare(tmp_path,complete(start=start))
    defs=json.loads(c.execute('SELECT sensors_json FROM activities').fetchone()[0])['field_definitions']
    k=next(k for k,d in defs.items() if d['message_number']==20 and d['name']=='timestamp')
    values=json.loads(c.execute('SELECT metrics_json FROM records WHERE record_index=0').fetchone()[0])
    c.close()
    assert defs[k]['value_form']=='raw'
    assert values['standard'][k]==start,values


def test_V006_complete_decode_failure_after_sha_keeps_all_tables(tmp_path):
    original=complete();bad=original[:-1]+bytes([original[-1]^1])
    p=tmp_path/'original.fit';p.write_bytes(bad)
    ident=hashlib.sha256(bad).hexdigest()
    storage.init_database(tmp_path/'states/data.db');c=storage.open_database(tmp_path/'states/data.db')
    storage.import_activity(c,activity_id=ident,fit_path='original.fit',parsed=ProfileFitDecoder().decode(original),parsed_at_utc=NOW)
    seed(c,ident);before=dump(c)
    with pytest.raises(ValueError,match='CRC'):storage.reparse_fit_file(tmp_path,ident)
    assert dump(c)==before and p.read_bytes()==bad
    c.close()


def test_b0_built_react_real_asgi_static_and_privacy(tmp_path,monkeypatch):
    static=tmp_path/WEB_STATIC_DIR
    shutil.copytree(ROOT/'source/skills/local-web/web',static)
    assert list((static/'assets').glob('*.js'))
    (tmp_path/'states').mkdir();private=tmp_path/'states/synthetic.json';private.write_text('{"sensitive":"synthetic-only"}')
    (static/'private-link.json').symlink_to(private)
    monkeypatch.chdir(tmp_path)
    contract=app_contract();assert contract['host']=='127.0.0.1' and contract['port']==8080 and contract['starts_background_jobs'] is False
    with TestClient(create_app()) as client:
        page=client.get('/');assert page.status_code==200 and '<div id="root">' in page.text
        js=re.search(r'src="([^"]+\.js)"',page.text).group(1)
        result=client.get(js);assert result.status_code==200 and '本地训练数据与 AI 总结' in result.text
        assert client.get('/api/health').json()['ok'] is True
        for url in ('/api/does-not-exist','/states/synthetic.json','/%2e%2e/%2e%2e/states/synthetic.json','/private-link.json','/source/pyproject.toml'):
            result=client.get(url)
            assert result.status_code==404 and result.json()['ok'] is False and 'synthetic-only' not in result.text
    assert private.read_text()=='{"sensitive":"synthetic-only"}'


def test_b0_static_root_rejection(tmp_path,monkeypatch):
    private=tmp_path/'states';private.mkdir()
    p=tmp_path/WEB_STATIC_DIR;p.parent.mkdir(parents=True);p.symlink_to(private,target_is_directory=True)
    monkeypatch.chdir(tmp_path)
    with pytest.raises(ValueError):create_app()
    for p in (Path('source'),Path('states'),Path('../external')):
        with pytest.raises(ValueError):validate_static_mount(p)


def test_b0_memory_and_time_no_writes(tmp_path,monkeypatch):
    monkeypatch.chdir(tmp_path)
    h=InMemoryConversationHistory();t=datetime(2031,2,3,0,0,0,123456,tzinfo=timezone(timedelta(hours=8)))
    h.append('user','synthetic',t);snapshot=h.snapshot()
    assert snapshot[0].created_at_utc==t.astimezone(UTC)
    assert format_utc(t)=='2031-02-02T16:00:00.123456Z' and utc_fit_date(t)=='20310202'
    with pytest.raises(ValueError):h.append('user','bad',t.replace(tzinfo=None))
    h.append('assistant','synthetic');h.clear()
    assert len(snapshot)==1 and h.snapshot()==() and h.persistence_target is None
    assert weekly_window(t)==(t.astimezone(UTC)-timedelta(days=7),t.astimezone(UTC))
    exact=datetime(2031,2,3,20,tzinfo=UTC)
    assert next_activity_report_run_utc(exact)==exact+timedelta(days=1)
    assert not list(tmp_path.iterdir())


def test_fit_readme_relative_links():
    p=ROOT/'source/skills/fit-store/README.md'
    broken=[]
    for dest in re.findall(r'\]\(([^)]+)\)',p.read_text()):
        if '://' not in dest and not (p.parent/dest.split('#')[0]).exists():broken.append(dest)
    assert not broken,broken
