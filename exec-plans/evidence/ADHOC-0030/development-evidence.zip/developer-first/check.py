import hashlib
import json
import os
from pathlib import Path
import subprocess

os.environ['GIT_OPTIONAL_LOCKS'] = '0'
root = Path('/Volumes/DiskOther/Code/TrainLab')
evidence = Path('/private/var/tmp/trainlab-ci-pr-fydlv9x0/developer-checks')
baseline = json.loads((evidence.parent / 'before-developer.json').read_text())
original = json.loads((evidence.parent / 'baseline.json').read_text())
target = '.github/workflows/ci.yml'
allowed_states = {'states/Goal-example.md', 'states/activities/.gitkeep', 'states/health/.gitkeep', 'states/verification/.gitkeep'}
commands = []

def git(*args):
    r = subprocess.run(['git', *args], cwd=root, capture_output=True)
    commands.append({'command': 'git ' + ' '.join(args), 'exit_code': r.returncode})
    assert r.returncode == 0, (args, r.stderr.decode())
    return r.stdout

def digest(data):
    return hashlib.sha256(data).hexdigest()

def workflows(paths):
    return sorted(p for p in paths if p.startswith('.github/workflows/') and p.lower().endswith(('.yml', '.yaml')))

def snapshot():
    paths = set(git('ls-files', '--cached', '--others', '--exclude-standard', '-z').decode().strip('\0').split('\0'))
    present = {p for p in paths if (root / p).exists()}
    assert {p for p in present if p.startswith('states/')} == allowed_states
    expected = set(baseline['files'])
    assert present <= expected, sorted(present - expected)
    files = {}
    for p in sorted(present):
        f = root / p
        assert f.is_file() and not f.is_symlink(), p
        data = f.read_bytes()
        files[p] = {'sha256': digest(data), 'bytes': len(data)}
    tracked = set(git('ls-files', '-z').decode().strip('\0').split('\0'))
    return {
        'root': git('rev-parse', '--show-toplevel').decode().strip(),
        'branch': git('branch', '--show-current').decode().strip(),
        'head': git('rev-parse', 'HEAD').decode().strip(),
        'index_sha256': digest(git('ls-files', '--stage', '-z')),
        'index_file_sha256': digest((root / '.git/index').read_bytes()),
        'files': files,
        'tracked_absent': sorted(p for p in tracked if not (root / p).exists()),
        'workflows': sorted(str(p.relative_to(root)) for p in (root / '.github/workflows').rglob('*') if p.is_file()),
        'cached_diff': git('diff', '--cached', '--name-only').decode(),
    }

def save(name, data):
    (evidence / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

try:
    assert Path.cwd() == root
    assert len(baseline['files']) == 111 and len(original['files']) == 110
    assert len(baseline['tracked_absent']) == 326
    assert baseline['authorized_developer_delete'] == [target]
    assert {p for p in baseline['files'] if p.startswith('states/')} == allowed_states
    assert set(baseline['files']) - set(original['files']) == {'exec-plans/active/ADHOC-0030-retire-ci-and-publish.md'}
    assert [p for p in original['files'] if original['files'][p] != baseline['files'][p]] == ['PLAN.md']
    assert original['tracked_absent'] == baseline['tracked_absent']
    before = snapshot()
    save('before.json', before)
    for k in ['root', 'branch', 'head', 'index_sha256', 'files', 'tracked_absent']:
        assert before[k] == baseline[k], k
    assert before['workflows'] == [target] and before['cached_diff'] == ''
    assert workflows([]) == []
    assert workflows(['README.md', '.github/workflows/notes.md']) == []
    assert workflows([target]) == [target]
    assert workflows(['.github/workflows/replacement.yaml']) == ['.github/workflows/replacement.yaml']
    expected_after = dict(before['files'])
    del expected_after[target]
    mutated = dict(expected_after)
    mutated['README.md'] = {'sha256': 'synthetic-change', 'bytes': 1}
    assert mutated != expected_after
    assert set(before['tracked_absent'][:-1]) != set(before['tracked_absent'])
    synthetic = {'cases': 6, 'passed': 6, 'scenarios': ['empty workflow set', 'non-workflow boundary', 'old workflow detected', 'replacement yaml detected', 'protected file mutation detected', 'old deletion restored detected']}
    save('synthetic.json', synthetic)
    (root / target).unlink()
    after = snapshot()
    save('after.json', after)
    assert after['files'] == expected_after
    assert after['tracked_absent'] == sorted(before['tracked_absent'] + [target])
    assert after['workflows'] == []
    for k in ['root', 'branch', 'head', 'index_sha256', 'index_file_sha256', 'cached_diff']:
        assert after[k] == before[k], k
    diff_check = git('diff', '--check')
    assert diff_check == b''
    (evidence / 'ci-deletion.patch').write_bytes(git('diff', '--', target))
    save('result.json', {'result': 'PASS', 'deleted': target, 'before_files': len(before['files']), 'after_files': len(after['files']), 'protected_files_unchanged': len(expected_after), 'old_deletions_preserved': len(before['tracked_absent']), 'after_deletions': len(after['tracked_absent']), 'synthetic': synthetic, 'commands': commands})
    print(json.dumps({'result': 'PASS', 'deleted': target, 'head_before_after': after['head'], 'logical_index_before_after': after['index_sha256'], 'raw_index_before_after': after['index_file_sha256'], 'ci_sha256_before': before['files'][target]['sha256'], 'ci_after': 'absent', 'protected_files_unchanged': len(expected_after), 'old_deletions_preserved': 326, 'workflow_files_after': after['workflows'], 'synthetic_passed': 6, 'diff_check_exit': 0}, indent=2))
except BaseException as e:
    save('failure.json', {'error': repr(e), 'commands': commands})
    raise
