# ADHOC-0030 首次规划（待主 Agent 审核）

目标来源：首发 request.md 的 RC-0030-01、AC-01～06；适用 AGENTS.md 与 subagent-templates/planner.md，均已完整读取。规划调整补充不适用。

范围：删除唯一旧 CI，承接已认可公开迁移工作区完成本地提交、正常推送、创建指向 main 的 PR；不是产品开发，也不是恢复旧测试。沿用 work/adhoc-0029-agentsmd-upgrade，不开新分支、不合并 main。Developer 仅删 `.github/workflows/ci.yml`；主 Agent 独占协调记录与全部 Git 写入；全新 Validator 独立只读验证，写入串行。

## 核对事实

- Git 根与工作目录相同；HEAD 为 `ec36ce7bbdf9d70a509238dd771b155eb6f84261`，分支符合首发材料。
- 精细状态434项：M=5、D=326、未跟踪=103；暂存差异为空。逻辑索引 SHA-256 与 baseline.json 一致。
- 基线列110公开文件；本次仅哈希读取 states 以外106文件，全部大小/摘要一致；326个既有删除仍缺失。未读取任何 states 文件内容。
- 唯一 workflow 是 `.github/workflows/ci.yml`，push/pull_request 触发，工作目录和依赖/测试入口均指向已删 source。
- `core.ignorecase=true`；磁盘为 `MEMORY.md`、索引仍为 `memory.md`，必须以候选 Git 树确认大小写迁移，不能只看磁盘或相似度改名显示。
- 需保护五个既有公开 ZIP：`exec-plans/evidence/ADHOC-0029/` 下 history、parent-check、validation-v1/v2/v3 证据包。本次只核对外层摘要，不阅读旧验收来增加要求。
- 现行衔接定位：PLAN 的授权范围/当前关注/CI事实；MEMORY 第26行当前工程；ADHOC-0023～0028 的 PR交付栏；0024第130行、0025第138行仍称 CI 引用旧入口。未来适用测试和产品未实施状态应保留，不把所有历史“CI”字样批量替换。
- 远端只读取既有预检材料，没有网络复核：当时 main=HEAD、无保护、功能分支未推送、无PR。规则集403限制按 request 保留，不据此宣称全部合并条件已查明。

## 审核拆解

以下编号在 ADHOC-0030 内稳定；执行顺序 T1→T2→T3→T4→T5→T6→T7，各阶段初始 [plan]。

| 阶段/任务、负责人 | AC | 输入 → 输出及接口 | 依赖、检查与预期 | 错误边界 |
| --- | --- | --- | --- | --- |
| S1/T1 主 Agent：批准拆解并登记 | 02、03、04 | 首发要求、baseline、此规划 → 本次执行计划、总计划入口、明确编辑白名单与保护清单 | 审核后、派发前按 exec-plans/template.md 建计划；复核根/分支/HEAD/索引/公开基线 | 不重写旧合同；意外基线变化停止，不能清理/重置整树 |
| S1/T2 全新 Developer：退役CI | 01、03、05 | 明确单文件及冻结前状态 → 仅删除 ci.yml、自查证据 | T1；确认目标原文匹配、文件删除、无替代 workflow，其他公开文件和索引不变 | 不改协调文档、不暂存、不安装、不网络、不运行旧产品测试；目标异常或额外差异立即停止 |
| S1/T3 主 Agent：现行记录衔接与候选冻结 | 02～05 | T2证据、before-public、现行协调文档 → 最小CI/Git事实更新、完整候选路径/内容摘要清单 | T2结束后写入；核对产品字段/接口/时间/权限/状态及历史证据不变；冻结最终公开候选 | 只改批准的现行段落；不改0029及更早合同，不扩展未来CI或产品需求 |
| S2/T4 全新 Validator：独立本地验收 | 01～05、06交付前提 | 客观要求、审核拆解、固定HEAD＋候选清单/摘要及基线 → 正常/错误/边界结果、复现证据、未验证项 | T3冻结；独立检查CI缺失、协调一致性、106非states旧文件的例外白名单差异、326旧删除、全部候选树和压缩包隐私、JSON/Markdown/链接、差异格式 | 不改受审内容、不读取私人states、不继承历史裁决；实质后改必须新实例复验 |
| S2/T5 主 Agent：亲自验收与精确暂存 | 01～06 | 独立结果、冻结候选 → 主验收证据、与已验候选一致的暂存完整树 | T4通过；重跑适用本地检查；逐路径暂存已批准新增/修改/删除，落实 memory.md→MEMORY.md；检查 `git diff --cached --check` 和索引完整树 | 禁用整树 add/重置；不以diff列表代替完整树审查；索引多一项、少一项、内容不符都停止 |
| S3/T6 主 Agent：提交/推送/PR | 01、04、06 | 已验暂存树、及时远端预检 → 本地提交、远端分支、真实PR及SHA证据 | T5；提交前核树，推送/PR前重查触发/合并条件及main基准；正常推送当前分支；创建main为base的PR并读取实际状态 | 冲突、权限/环境失败停止，不force-push、不改设置、不主动远端CI、不合并；基准变化影响验收则补验 |
| S3/T7 主 Agent：真实收口 | 02、05、06 | 本地/远端/PR查询结果 → 真实交付记录、归档与最终报告 | T6；本地HEAD=远端分支SHA=PR head SHA，核对仓库/head/base、PR URL和open/未合并状态、检查/合并限制；先执行计划后总计划，完成后归档并更新链接 | 不预写成功；仅结果/状态/证据收口可由主 Agent核差后另行提交推送，仍复核最终SHA；实质修改返回独立验证 |

## 检查预期与接口细节

- **正常**：候选 workflow 集合为空；其余差异仅现行协调白名单和本次记录；110基线文件除CI删除及批准协调变更外保持原字节，326删除保持删除。Markdown人工结构与本地链接检查、JSON解析、`git diff --check`/暂存差异检查均须记录实际退出结果。历史快照中的旧路径是非执行证据，不当成现行坏入口或新要求。
- **错误**：在隔离合成清单中加入额外 workflow、禁止路径、旧入口、摘要变化、坏JSON/本地链接，应被候选检查拒绝；不在仓库注入错误，不新增永久产品测试。合法例外需人工按要求解释，不能为通过削弱检查。
- **边界**：使用精确/NUL分隔路径清单核验空格与大小写；最终树只能有 `MEMORY.md`，不能残留 `memory.md`、`PLANS.md`、docs、source等旧执行入口。改名显示成删除＋新增亦可，树结果才是验收依据。326删除外，本轮新增CI删除须单独记账。
- **隐私**：候选完整文件树（不只本次diff）先按公开白名单核路径/类型；states仅三个既定 `.gitkeep` 和虚构 `Goal-example.md`，核内容只能针对这些公开样例，绝不递归读取真实states。拒绝 `.DS_Store`、数据库及sidecar、私人FIT/GPS/Goal/健康/报告/凭据、临时研究输出。
- **压缩包**：保持原包摘要；发布前在隔离环境审查成员清单与公开文本内容，不执行成员、不直接解压到仓库；检查路径穿越/链接/嵌套包及可疑秘密线索。发现疑似私人内容停止并只返回脱敏线索，不继续读取或擅改历史包。扫描无命中不等于绝对无秘密。
- **精确暂存**：主 Agent 用明确清单包含既有公开新增与326删除、本次CI删除及记录；处理大小写索引时仅调整目标条目并保留工作区内容，不修改全局或本地 ignorecase 配置；暂存后从索引读取完整树与冻结候选逐项比对，再提交。不得把临时预检原件直接放进Git。
- **PR**：预检403只说明观测限制，不等于规则不存在；若无法判断安全推送/PR条件，记录无法判断并停止受影响步骤；没有成功结果不能把本地提交称作远端交付。无需等“绿色CI”作为删除CI的新要求，但实际检查状态和合并限制必须如实记录。

## 实际检查与限制

1. `pwd; git rev-parse --show-toplevel; git branch --show-current; git rev-parse HEAD; git --no-optional-locks status --short; git config --get core.ignorecase`：退出0；根、分支、HEAD符合材料，ignorecase=true。
2. Python标准库只读解析 baseline，并调用 `git --no-optional-locks status --porcelain=v1 -uall -z`、`git diff --cached --raw`、`git ls-files -z`：退出0；434记录、暂存为空、大小写索引差异已证实。
3. Python标准库核对106非states公开文件SHA/大小、326缺失路径、workflow列表、`git ls-files --stage -z`摘要及解析既有预检JSON：退出0；106无差异、326仍缺失、逻辑索引摘要匹配。
4. read完整读取规范、模板、request、PLAN与ci.yml；grep仅定位现行MEMORY及0023～0028 CI/Git/暂停衔接；工具均成功。没有从旧历史验收抽取附加要求。
5. 未运行产品测试、远端命令、完整发布隐私/压缩包内容审查或最终候选验收；此报告不是功能通过或PR成功证明。未创建临时检查文件、未修改仓库或Git状态。

剩余风险：大小写索引容易漏掉；公开压缩包内容仍待发布前检查；远端预检会过时且规则集权限受限。预检原件存在服务返回的带查询参数下载链接，应视作敏感材料，不复制原件/原始输出到公开证据或PR，证据仅保存脱敏摘要。本规划无阻塞基线异常；下一步仅供主 Agent 审核，实施需新任务。

```acceptance-report
{
  "criteriaSatisfied": [{"id":"criterion-1","status":"satisfied","evidence":"返回S1～S3/T1～T7稳定拆解、全部AC映射、实际只读基线核对及残余风险"}],
  "changedFiles": [],
  "testsAddedOrUpdated": [],
  "commandsRun": [
    {"command":"Git根/分支/HEAD/status/core.ignorecase只读核对","result":"passed","summary":"退出0；符合首发基线，ignorecase=true"},
    {"command":"Python解析baseline与Git状态/索引核对","result":"passed","summary":"退出0；434项状态、无暂存差异；memory.md索引与MEMORY.md磁盘大小写不同"},
    {"command":"Python公开摘要/缺失路径/workflow/逻辑索引核对","result":"passed","summary":"退出0；106非states文件匹配、326删除保持、索引摘要匹配"},
    {"command":"产品测试、远端复核、完整发布候选验收","result":"not-run","summary":"规划阶段未授权执行；不得视为通过"}
  ],
  "validationOutput": ["规划基线核对通过；功能实施及Git/PR交付尚未执行"],
  "residualRisks": ["大小写改名须核索引最终树","完整候选及压缩包隐私待验","远端预检时效与规则集403限制","原始预检含敏感下载链接，不可公开复制"],
  "noStagedFiles": true,
  "diffSummary": "未修改仓库或Git状态，仅输出规划报告",
  "reviewFindings": ["无规划阻塞；仅主Agent审核后进入实施"],
  "manualNotes": "完整读取首发要求及规范；未读私人states、未网络调用或安装；公开历史包仅核摘要，不以旧验收增加要求。"
}
```
