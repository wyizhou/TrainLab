import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess

os.umask(0o077)
os.environ['GIT_OPTIONAL_LOCKS'] = '0'
root = Path('/Volumes/DiskOther/Code/TrainLab')
out = Path('/private/var/tmp/trainlab-ci-pr-fydlv9x0/developer-v2-checks')
baseline = json.loads((out.parent / 'before-developer-v2.json').read_text())
target = '.github/workflows/ci.yml'
allowed_states = {'states/Goal-example.md', 'states/activities/.gitkeep', 'states/health/.gitkeep', 'states/verification/.gitkeep'}
commands = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, data):
    (out / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

def git(*args):
    p = subprocess.run(['git', *args], cwd=root, capture_output=True)
    commands.append({'command': 'git ' + ' '.join(args), 'exit_code': p.returncode})
    assert p.returncode == 0, (args, p.stderr.decode())
    return p.stdout

def paths(data):
    return set(filter(None, data.decode().split('\0')))

def common(files):
    return {p: {k: v[k] for k in ('sha256', 'bytes')} for p, v in files.items()}

def canonical(p, names):
    if p.lower() == 'memory.md':
        matches = [n for n in names if n.lower() == 'memory.md']
        assert matches == ['MEMORY.md'], matches
        return matches[0]
    return p

def snapshot():
    names = os.listdir(root)
    assert canonical('memory.md', names) == 'MEMORY.md'
    listed = {canonical(p, names) for p in paths(git('ls-files', '--cached', '--others', '--exclude-standard', '-z'))}
    present = {p for p in listed if os.path.lexists(root / p)}
    assert {p for p in present if p.startswith('states/')} == allowed_states
    assert present <= set(baseline['files']), sorted(present - set(baseline['files']))
    files = {}
    for p in sorted(present):
        f = root / p
        assert f.is_file() and not f.is_symlink(), p
        data = f.read_bytes()
        files[p] = {'sha256': sha(data), 'bytes': len(data)}
    tracked = paths(git('ls-files', '-z'))
    workflow_dir = root / '.github/workflows'
    workflows = sorted(str(p.relative_to(root)) for p in workflow_dir.rglob('*') if p.is_file() or p.is_symlink())
    return {
        'root': git('rev-parse', '--show-toplevel').decode().strip(),
        'branch': git('branch', '--show-current').decode().strip(),
        'head': git('rev-parse', 'HEAD').decode().strip(),
        'index_sha256': sha(git('ls-files', '--stage', '-z')),
        'raw_index_sha256': sha((root / '.git/index').read_bytes()),
        'files': files,
        'tracked_absent': sorted(p for p in tracked if not os.path.lexists(root / canonical(p, names))),
        'workflows': workflows,
        'cached_diff': git('diff', '--cached', '--name-only').decode(),
        'memory_disk_names': [n for n in names if n.lower() == 'memory.md'],
    }

def validate(actual, expected, deleted):
    for k in ('root', 'branch', 'head', 'index_sha256'):
        assert actual[k] == expected[k], k
    for k in ('raw_index_sha256', 'cached_diff'):
        if k in expected:
            assert actual[k] == expected[k], k
    wanted = common(expected['files'])
    if deleted:
        del wanted[target]
    assert common(actual['files']) == wanted, 'protected SHA/bytes or file set'
    assert actual['tracked_absent'] == sorted(expected['tracked_absent'] + ([target] if deleted else [])), 'deletions'
    assert actual['workflows'] == ([] if deleted else [target]), 'workflows'
    assert actual['cached_diff'] == '', 'staged changes'

try:
    assert Path.cwd() == root
    assert len(baseline['files']) == 111 and len(baseline['tracked_absent']) == 326
    assert baseline['authorized_developer_delete'] == [target]
    assert {p for p in baseline['files'] if p.startswith('states/')} == allowed_states
    assert common(baseline['files'])[target] == {'sha256': '0d99ab915ed210db264e4eb9758048d6c3e488b41af4cd72982e62048966f94c', 'bytes': 3435}
    before = snapshot()
    save('before.json', before)
    validate(before, baseline, False)
    (out / 'status-before.txt').write_bytes(git('status', '--porcelain=v1', '--untracked-files=all'))
    expected = copy.deepcopy(before)
    del expected['files'][target]
    expected['tracked_absent'] = sorted(expected['tracked_absent'] + [target])
    expected['workflows'] = []
    validate(expected, before, True)
    richer = copy.deepcopy(before)
    for v in richer['files'].values():
        v['mode'] = 0o644
    validate(expected, richer, True)
    cases = ['normal deletion accepted', 'extra baseline mode accepted']
    def reject(name, mutation):
        changed = copy.deepcopy(expected)
        mutation(changed)
        try:
            validate(changed, before, True)
        except AssertionError:
            cases.append(name)
        else:
            raise AssertionError('negative case incorrectly accepted: ' + name)
    reject('SHA-only mutation rejected', lambda s: s['files']['README.md'].update(sha256='0' * 64))
    reject('size-only mutation rejected', lambda s: s['files']['README.md'].update(bytes=0))
    reject('multiple mutations rejected', lambda s: (s['files']['README.md'].update(bytes=0), s['files']['PLAN.md'].update(bytes=0)))
    reject('extra deletion rejected', lambda s: s['files'].pop('README.md'))
    reject('restored old deletion rejected', lambda s: s['tracked_absent'].remove(before['tracked_absent'][0]))
    reject('restored CI rejected', lambda s: s['files'].update({target: before['files'][target]}))
    reject('replacement workflow rejected', lambda s: s['workflows'].append('.github/workflows/replacement.yaml'))
    reject('extra public file rejected', lambda s: s['files'].update({'extra.txt': {'sha256': '0' * 64, 'bytes': 0}}))
    reject('logical index mutation rejected', lambda s: s.update(index_sha256='0' * 64))
    assert canonical('memory.md', ['MEMORY.md']) == 'MEMORY.md'
    assert canonical('MEMORY.md', ['MEMORY.md']) == 'MEMORY.md'
    try:
        canonical('memory.md', ['memory.md', 'MEMORY.md'])
    except AssertionError:
        cases.append('ambiguous memory directory entries rejected')
    else:
        raise AssertionError('ambiguous memory accepted')
    save('synthetic.json', {'passed': len(cases), 'cases': cases})
    validate(snapshot(), before, False)
    (root / target).unlink()
    after = snapshot()
    save('after.json', after)
    validate(after, before, True)
    check = git('diff', '--check')
    assert check == b''
    (out / 'ci-deletion.patch').write_bytes(git('diff', '--', target))
    (out / 'status-after.txt').write_bytes(git('status', '--porcelain=v1', '--untracked-files=all'))
    result = {'result': 'PASS', 'deleted': target, 'protected_files_unchanged': 110, 'original_deletions_preserved': 326, 'after_tracked_absent': len(after['tracked_absent']), 'workflows_after': after['workflows'], 'synthetic_passed': len(cases), 'commands': commands, 'historical_failure_count': 1, 'repair_attempts_this_run': 1, 'new_failures': 0}
    save('result.json', result)
    print(json.dumps(result, indent=2))
except BaseException as e:
    save('failure.json', {'error': repr(e), 'commands': commands, 'ci_exists': os.path.lexists(root / target)})
    raise
