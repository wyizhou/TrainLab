# ADHOC-0030 T2 / CHECK-BASELINE-01

结果：已仅删除 `.github/workflows/ci.yml`，Developer 自查通过；未实施 T3 以后事项。

- 原 CI：3435 字节，SHA-256 `0d99ab915ed210db264e4eb9758048d6c3e488b41af4cd72982e62048966f94c`；删除后 workflow 文件为零。
- 以 `before-developer-v2.json` 为唯一保护基准，其余110个公开文件 SHA/字节数不变，原326项删除保留，删除总数327。Git状态435→436项，仅新增该CI删除。
- 分支仍为 `work/adhoc-0029-agentsmd-upgrade`，HEAD仍为 `ec36ce7bbdf9d70a509238dd771b155eb6f84261`；逻辑索引和原始索引摘要不变，暂存为空。
- 修复方式：明确比较 `sha256`、`bytes`，不再比较异构整对象；核对真实根目录项唯一为 `MEMORY.md`，将Git旧名称映射到该项，不改索引或ignorecase。人工核查检查逻辑后，先运行合成正反例和删除前复核，再删除CI。
- 12项合成检查通过：正常删除、额外mode字段兼容；拒绝单独摘要变化、单独大小变化、多文件变化、额外删除、恢复原删除、恢复CI、替代workflow、额外文件、索引变化以及大小写歧义。
- CHECK-BASELINE-01 历史累计失败仍为1；本轮首次修复尝试自查通过，新增失败0，尚待独立复验。原失败脚本及证据未运行、未覆盖。

## 检查及证据

外部证据目录：`/private/var/tmp/trainlab-ci-pr-fydlv9x0/developer-v2-checks/`。

| 实际检查 | 退出码 | 证据 |
| --- | --- | --- |
| `python3 -B /private/var/tmp/trainlab-ci-pr-fydlv9x0/developer-v2-checks/check.py` | 0 | check.py、before.json、after.json、synthetic.json、result.json |
| 脚本内 `git diff --check`（未关闭全局空白规则） | 0 | result.json命令记录 |
| Git根/分支/HEAD、文件列表、逻辑索引、暂存、状态及目标diff只读检查 | 均0 | result.json、status-before.txt、status-after.txt、ci-deletion.patch |
| 独立于删除脚本的内联Python证据权限/状态差集核对 | 0 | final-audit.json：目录0700、文件0600，仅新增CI删除 |

仅读取四个允许的states公开骨架，未读取其他states内容；未网络、安装、运行旧产品、写Git状态或协调记录。项目及已检查的常见全局技能位置无适用技能；一个可选全局目录查询返回路径不存在，未执行恢复或安装。

剩余事项：此结果仅为Developer自查，不是独立验证或主验收。未运行产品pytest/Ruff/mypy、远端检查、推送或PR；现行记录衔接、历史补丁格式适用性核验及完整发布候选审计由后续任务处理。公开文件摘要保护不等于绝对无秘密或持续OS级保护审计。

```acceptance-report
{
  "criteriaSatisfied": [{"id":"criterion-1","status":"satisfied","evidence":"仅删除CI；110公开文件及326原删除保护、12项合成检查、git diff --check均通过，残余边界已明确。"}],
  "changedFiles": [".github/workflows/ci.yml"],
  "testsAddedOrUpdated": ["/private/var/tmp/trainlab-ci-pr-fydlv9x0/developer-v2-checks/check.py"],
  "commandsRun": [
    {"command":"python3 -B /private/var/tmp/trainlab-ci-pr-fydlv9x0/developer-v2-checks/check.py","result":"passed","summary":"退出0，删除前基线及12项合成检查通过，删除后保护检查通过"},
    {"command":"git diff --check","result":"passed","summary":"退出0，无输出；未修改空白规则"},
    {"command":"python3 -B 内联权限及Git状态差集审计","result":"passed","summary":"退出0，权限0700/0600，Git状态只新增CI删除"}
  ],
  "validationOutput": ["workflow文件0；保护公开文件110；原删除326；当前删除327；暂存为空；HEAD/分支/逻辑及原始索引不变"],
  "residualRisks": ["独立复验和主验收未运行；T3以后记录及发布检查未执行", "旧产品测试未运行；历史diff载荷格式诊断未在本轮重验"],
  "noStagedFiles": true,
  "diffSummary": "相对v2基线仅删除.github/workflows/ci.yml；检查脚本和证据留在批准的仓库外目录。",
  "reviewFindings": ["本轮T2自查无阻塞；不代替独立验证"],
  "manualNotes": "CHECK-BASELINE-01累计失败1不清零；本轮修复尝试1、新增失败0。采用共同字段及真实目录项核验，保留全部有效保护断言与拒绝负例，旧失败证据未覆盖。"
}
```
