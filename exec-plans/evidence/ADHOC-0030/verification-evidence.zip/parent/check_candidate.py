import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
from urllib.parse import unquote, urlsplit
import zipfile

ROOT = Path('/Volumes/DiskOther/Code/TrainLab')
E = Path('/private/var/tmp/trainlab-ci-pr-fydlv9x0')
BASE = json.loads((E / 'baseline.json').read_text())
PUBLIC_STATES = {'states/Goal-example.md', 'states/activities/.gitkeep', 'states/health/.gitkeep', 'states/verification/.gitkeep'}
PATCH = 'exec-plans/evidence/ADHOC-0029/closeout-status.diff'
CI = '.github/workflows/ci.yml'
COORD = {'PLAN.md', 'MEMORY.md'} | {p for p in BASE['files'] if re.match(r'exec-plans/active/ADHOC-002[3-8]-', p)}
SIGNATURE = re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{36,}|github_pat_[A-Za-z0-9_]{60,}|AKIA[0-9A-Z]{16}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)')
LINK = re.compile(r'!?\[([^\[\]\n]+)\]\(([^)\n]+)\)')
results = []
commands = []

def check(name, value, detail=None):
    results.append({'check': name, 'passed': bool(value), 'detail': detail})

def git(*args):
    p = subprocess.run(['git', *args], cwd=ROOT, capture_output=True, env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})
    commands.append({'command': ['git', *args], 'exit': p.returncode})
    if p.returncode:
        raise RuntimeError(str(args) + ': ' + p.stderr.decode())
    return p.stdout

def digest(data):
    return hashlib.sha256(data).hexdigest()

def public_paths():
    names = set(git('ls-files', '--cached', '--others', '--exclude-standard', '-z').decode().split('\0')) - {''}
    root_names = {p.name for p in ROOT.iterdir()}
    if 'memory.md' in names and 'MEMORY.md' in root_names:
        names.remove('memory.md')
        names.add('MEMORY.md')
    return sorted(p for p in names if (ROOT / p).is_file())

def forbidden(path):
    p = Path(path)
    return p.is_absolute() or '..' in p.parts or '.DS_Store' in p.parts or path.lower().endswith(('.fit', '.db', '.db-wal', '.db-shm', '.sqlite', '.sqlite3'))

def main():
    frozen = json.loads(Path(sys.argv[1]).read_text())
    paths = public_paths()
    check('Git root', git('rev-parse', '--show-toplevel').decode().strip() == str(ROOT))
    check('Branch', git('branch', '--show-current').decode().strip() == BASE['branch'])
    check('Frozen HEAD', git('rev-parse', 'HEAD').decode().strip() == frozen['head'])
    expected_index = frozen['index_entries']['sha256'] if 'index_entries' in frozen else frozen['index_sha256']
    if 'index_entries' in frozen:
        check('Index digest command definition', frozen['index_entries']['command'] == ['git', 'ls-files', '--stage', '-z'])
    check('Frozen logical index', digest(git('ls-files', '--stage', '-z')) == expected_index)
    check('Exact public path set', set(paths) == set(frozen['files']))
    check('Only approved public states', {p for p in paths if p.startswith('states/')} == PUBLIC_STATES)
    check('No private-type paths', not [p for p in paths if forbidden(p)])
    check('No old product or naming entry', not any(p == 'memory.md' or p == 'PLANS.md' or p.startswith(('source/', 'docs/')) for p in paths))
    check('Physical uppercase memory', 'MEMORY.md' in {p.name for p in ROOT.iterdir()} and 'memory.md' not in {p.name for p in ROOT.iterdir()})
    check('No workflow files', not [p for p in paths if p.startswith('.github/workflows/')])
    check('CI absent', not (ROOT / CI).exists())
    check('Prior deletions preserved', all(not (ROOT / p).exists() for p in BASE['tracked_absent']))
    protection_failures = []
    for p, m in BASE['files'].items():
        if p not in COORD | {CI}:
            f = ROOT / p
            if f.is_symlink() or not f.is_file() or digest(f.read_bytes()) != m['sha256']:
                protection_failures.append(p)
    check('All 101 unchanged original public files', not protection_failures, protection_failures)
    hash_failures = []
    links = []
    json_errors = []
    whitespace = []
    secret_hits = []
    archives = {}
    safe_paths = [p for p in paths if p in frozen['files'] and not forbidden(p) and (not p.startswith('states/') or p in PUBLIC_STATES)]
    for p in safe_paths:
        f = ROOT / p
        check('Regular nonsymlink: ' + p, f.is_file() and not f.is_symlink())
        if f.is_symlink():
            continue
        data = f.read_bytes()
        if p not in frozen['files'] or digest(data) != frozen['files'][p]['sha256'] or len(data) != frozen['files'][p]['bytes']:
            hash_failures.append(p)
        if p.endswith('.zip'):
            with zipfile.ZipFile(f) as z:
                infos = z.infolist()
                check('ZIP unique safe names: ' + p, len(infos) == len(set(x.filename for x in infos)) and all(not forbidden(x.filename) for x in infos))
                check('ZIP no symlink/encrypted/nested: ' + p, all(not stat.S_ISLNK(x.external_attr >> 16) and not x.flag_bits & 1 and not x.filename.endswith('.zip') for x in infos))
                if any(forbidden(x.filename) or stat.S_ISLNK(x.external_attr >> 16) or x.flag_bits & 1 or x.filename.endswith('.zip') for x in infos):
                    continue
                check('ZIP CRC: ' + p, z.testzip() is None)
                for x in infos:
                    if SIGNATURE.search(z.read(x)):
                        secret_hits.append(p + '::' + x.filename)
                archives[p] = len(infos)
            continue
        if SIGNATURE.search(data):
            secret_hits.append(p)
        if p.endswith('.json'):
            try:
                json.loads(data)
            except (ValueError, UnicodeError) as exc:
                json_errors.append({'path': p, 'error': str(exc)})
        if p.endswith('.md'):
            text = data.decode()
            text = re.sub(r'^```[^\n]*\n.*?^```\s*$', '', text, flags=re.M | re.S)
            for _, target in LINK.findall(text):
                target = target.strip().split(' "')[0]
                url = urlsplit(target)
                if url.scheme or target.startswith(('#', '//', '/')):
                    continue
                if url.path and not (f.parent / unquote(url.path)).exists():
                    links.append({'path': p, 'target': target})
        q = subprocess.run(['git', 'diff', '--no-index', '--check', '--', '/dev/null', p], cwd=ROOT, capture_output=True)
        if p == PATCH:
            lines = data.decode().splitlines()
            bad = [line for line in lines if line.rstrip() != line]
            check('Historical patch whitespace is only required empty-context markers', len(bad) == 19 and all(line == ' ' for line in bad))
            check('Historical patch original hash', digest(data) == BASE['files'][PATCH]['sha256'])
            a = subprocess.run(['git', 'apply', '--numstat', p], cwd=ROOT, capture_output=True)
            commands.append({'command': ['git', 'apply', '--numstat', p], 'exit': a.returncode})
            check('Historical patch parses without applying', a.returncode == 0)
            commands.append({'command': ['git', 'diff', '--no-index', '--check', '--', '/dev/null', p], 'exit': q.returncode, 'note': 'Raw diagnostic retained; unified-diff payload checked separately, not trimmed or globally suppressed.'})
        elif q.returncode not in (0, 1) or q.stdout or q.stderr:
            whitespace.append({'path': p, 'exit': q.returncode, 'stdout': q.stdout.decode(), 'stderr': q.stderr.decode()})
    check('Every frozen SHA and byte size', not hash_failures, hash_failures)
    check('All public JSON parses', not json_errors, json_errors)
    check('Local Markdown file targets exist', not links, links)
    check('Non-patch public text whitespace', not whitespace, whitespace)
    check('No common secret signatures', not secret_hits, secret_hits)
    for p in ['states/private-negative.fit', 'states/data.db', 'states/data.db-wal', 'states/data.db-shm', 'states/Goal.md', 'states/verification/private-token.json', '.DS_Store']:
        q = subprocess.run(['git', 'check-ignore', '-q', '--', p], cwd=ROOT)
        check('Synthetic ignored path: ' + p, q.returncode == 0)
    for p in sorted(COORD):
        if not p.startswith('exec-plans/active/'):
            continue
        old = (E / 'before-public' / p).read_text()
        new = (ROOT / p).read_text()
        check('Product JSON examples unchanged: ' + p, re.findall(r'```json\n(.*?)\n```', old, re.S) == re.findall(r'```json\n(.*?)\n```', new, re.S))
        check('Product AC rows unchanged: ' + p, re.findall(r'^\| AC-[^\n]+', old, re.M) == re.findall(r'^\| AC-[^\n]+', new, re.M))
        check('Product states unchanged: ' + p, re.findall(r'\[(?:plan|exec|completed)\]', old) == re.findall(r'\[(?:plan|exec|completed)\]', new))
    q = subprocess.run(['git', 'diff', '--check'], cwd=ROOT, capture_output=True)
    commands.append({'command': ['git', 'diff', '--check'], 'exit': q.returncode})
    check('Tracked diff whitespace', q.returncode == 0, q.stdout.decode())
    check('Negative forbidden FIT path', forbidden('states/private.fit'))
    check('Negative traversal', forbidden('../private.txt'))
    check('Negative changed digest', digest(b'synthetic original') != digest(b'synthetic mutation'))
    check('Negative additional workflow path', bool([p for p in ['.github/workflows/replacement.yaml'] if p.startswith('.github/workflows/')]))
    try:
        json.loads('{bad-json}')
        rejected = False
    except ValueError:
        rejected = True
    check('Negative malformed JSON', rejected)
    report = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'snapshot_sha256': digest(Path(sys.argv[1]).read_bytes()), 'passed': all(x['passed'] for x in results), 'checks': len(results), 'results': results, 'commands': commands, 'public_files': len(paths), 'archives': archives, 'limits': ['No product tests, private state, business providers, or remote CI run.', 'Secret-signature absence is not a proof against all possible secrets.', 'Local link existence checked; anchors changed by this task require manual review.', 'Historical unified-diff blank-context markers are data, independently parsed and original-hash protected.']}
    Path(sys.argv[2]).write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'passed': report['passed'], 'checks': len(results), 'failures': [x for x in results if not x['passed']]}, ensure_ascii=False))
    return 0 if report['passed'] else 1

if __name__ == '__main__':
    sys.exit(main())
