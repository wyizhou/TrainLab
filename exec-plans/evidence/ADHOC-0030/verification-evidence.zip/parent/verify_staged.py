import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Volumes/DiskOther/Code/TrainLab')
E = Path('/private/var/tmp/trainlab-ci-pr-fydlv9x0')
PATCH = 'exec-plans/evidence/ADHOC-0029/closeout-status.diff'
expected = json.loads(Path(sys.argv[1]).read_text())
rows = subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT).split(b'\0')
entries = {}
for row in rows:
    if not row:
        continue
    meta, path = row.split(b'\t', 1)
    mode, oid, stage = meta.split()
    assert stage == b'0', 'Unmerged index entry'
    name = path.decode()
    assert name not in entries, 'Duplicate index path'
    entries[name] = (mode.decode(), oid.decode())
assert set(entries) == set(expected['files']), 'Index path set differs from explicit accepted candidate'
assert 'MEMORY.md' in entries and 'memory.md' not in entries
assert not any(p.startswith(('source/', 'docs/', '.github/workflows/')) or p == 'PLANS.md' for p in entries)
allowed_states = {'states/activities/.gitkeep', 'states/health/.gitkeep', 'states/verification/.gitkeep', 'states/Goal-example.md'}
assert {p for p in entries if p.startswith('states/')} == allowed_states
for path, (mode, oid) in entries.items():
    record = expected['files'][path]
    expected_mode = '100755' if int(record['mode'], 8) & 0o111 else '100644'
    assert mode == expected_mode, ('mode', path)
    data = subprocess.check_output(['git', 'cat-file', 'blob', oid], cwd=ROOT)
    assert len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256'], ('blob', path)
raw = subprocess.run(['git', 'diff', '--cached', '--check'], cwd=ROOT, capture_output=True, text=True)
scoped = subprocess.run(['git', 'diff', '--cached', '--check', '--', '.', ':(exclude)' + PATCH], cwd=ROOT, capture_output=True, text=True)
assert scoped.returncode == 0 and not scoped.stdout and not scoped.stderr, 'Ordinary staged text whitespace failure'
if raw.returncode:
    diagnostics = [s for s in raw.stdout.splitlines() if s.endswith(': trailing whitespace.')]
    assert raw.returncode == 2 and not raw.stderr and len(diagnostics) == 19
    assert all(s.startswith(PATCH + ':') for s in diagnostics), 'Unexpected whitespace diagnostic'
    assert all(s.endswith(': trailing whitespace.') or s == '+ ' for s in raw.stdout.splitlines()), 'Unexpected raw check output'
patch = (ROOT / PATCH).read_bytes()
base = json.loads((E / 'baseline.json').read_text())
assert hashlib.sha256(patch).hexdigest() == base['files'][PATCH]['sha256']
trailing = [s for s in patch.decode().splitlines() if s.rstrip() != s]
assert len(trailing) == 19 and all(s == ' ' for s in trailing)
parse = subprocess.run(['git', 'apply', '--numstat', PATCH], cwd=ROOT, capture_output=True, text=True)
assert parse.returncode == 0
write_tree = subprocess.check_output(['git', 'write-tree'], cwd=ROOT).decode().strip()
report = {'accepted_manifest_sha256': hashlib.sha256(Path(sys.argv[1]).read_bytes()).hexdigest(), 'index_file_count': len(entries), 'exact_names_modes_and_blob_bytes_match': True, 'memory_case_resolved': True, 'tree': write_tree, 'raw_cached_check': {'command': ['git', 'diff', '--cached', '--check'], 'exit': raw.returncode, 'stdout': raw.stdout, 'stderr': raw.stderr}, 'ordinary_cached_check': {'command': ['git', 'diff', '--cached', '--check', '--', '.', ':(exclude)' + PATCH], 'exit': scoped.returncode}, 'historical_patch': {'original_hash_unchanged': True, 'empty_context_markers': 19, 'parse_only_exit': parse.returncode}, 'note': 'Exact immutable unified-diff payload is validated as patch data. No global whitespace rule changed; no diagnostic suppressed from this report.'}
Path(sys.argv[2]).write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'index_file_count': len(entries), 'tree': write_tree, 'ordinary_cached_check_exit': scoped.returncode, 'raw_cached_check_exit': raw.returncode, 'exact_candidate_match': True}, ensure_ascii=False))
