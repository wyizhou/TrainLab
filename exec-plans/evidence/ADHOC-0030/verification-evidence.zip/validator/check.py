import os,json,pathlib,hashlib,subprocess,stat,difflib,re,zipfile,io
os.umask(0o077)
R=pathlib.Path('/Volumes/DiskOther/Code/TrainLab'); os.chdir(R)
D=pathlib.Path('/private/var/tmp/trainlab-ci-pr-fydlv9x0'); O=D/'validator-v2-checks'
s=json.loads((D/'review-snapshot-v2.json').read_bytes());b=json.loads((R/'exec-plans/evidence/ADHOC-0030/baseline.json').read_bytes())
def git(*a):return subprocess.check_output(['git',*a],env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'))
def sha(x):return hashlib.sha256(x).hexdigest()
def freeze():
 errors=[]
 for p,v in s['files'].items():
  f=R/p; st=f.lstat();actual={'sha256':sha(f.read_bytes()),'bytes':st.st_size,'mode':oct(st.st_mode)}
  if actual!=v:errors.append([p,actual,v])
 tracked=git('ls-files','-z').decode().split('\0')[:-1]
 absent=sorted(p for p in tracked if not (R/p).exists())
 paths=[]
 # Never enumerate private states; only explicitly authorized skeletons.
 for root,dirs,files in os.walk(R):
  rel=pathlib.Path(root).relative_to(R)
  dirs[:]=[d for d in dirs if d not in ('.git','states')]
  for f in files:paths.append((rel/f).as_posix())
 ignored=subprocess.run(['git','check-ignore','--stdin','-z'],input=('\0'.join(paths)+'\0').encode(),stdout=subprocess.PIPE,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')).stdout.decode().split('\0')
 paths=[p for p in paths if p not in ignored]
 paths+= [p for p in s['files'] if p.startswith('states/') and (R/p).exists()]
 return dict(errors=errors,paths_equal=sorted(paths)==sorted(s['files']),extra=sorted(set(paths)-set(s['files'])),absent_equal=absent==sorted(s['tracked_absent']),absent_count=len(absent),head=git('rev-parse','HEAD').decode().strip(),branch=git('branch','--show-current').decode().strip(),index_entries=sha(git('ls-files','--stage','-z')),index_container=sha((R/'.git/index').read_bytes()),cached=git('diff','--cached','--name-only','-z').decode())
r={'freeze_before':freeze()}
(O/'before.json').write_text(json.dumps(r,indent=2))
if r['freeze_before']['errors'] or not r['freeze_before']['paths_equal'] or not r['freeze_before']['absent_equal']:raise SystemExit('FREEZE FAILURE')
changed=[p for p in b['files'] if p in s['files'] and b['files'][p]['sha256']!=s['files'][p]['sha256']]
r['baseline']={'changed':changed,'removed':sorted(set(b['files'])-set(s['files'])),'added':sorted(set(s['files'])-set(b['files'])),'unchanged':sum(b['files'][p]['sha256']==s['files'][p]['sha256'] for p in b['files'] if p in s['files']),'old_deletions_preserved':set(b['tracked_absent'])<=set(s['tracked_absent'])}
diffs=[]
for p in changed:
 old=(D/'before-public'/p).read_bytes();assert sha(old)==b['files'][p]['sha256']
 diffs.extend(difflib.unified_diff(old.decode().splitlines(True),(R/p).read_text().splitlines(True),fromfile='before/'+p,tofile=p))
(O/'coordination.diff').write_text(''.join(diffs))
r['json']=[];r['whitespace']=[];r['links']=[];r['archives']=[];r['secret_hits']=[];r['types']={}
patterns={'private_key':r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----','github_token':r'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})\b','aws_key':r'\bAKIA[A-Z0-9]{16}\b','bearer':r'(?i)bearer\s+[A-Za-z0-9_.-]{24,}','secret_assignment':r'(?i)(?:password|client_secret|access_token|refresh_token)\s*[=:]\s*[\"\x27][A-Za-z0-9_./+=-]{20,}'}
def scan(name,data):
 text=data.decode('utf-8',errors='replace')
 for tag,pat in patterns.items():
  for m in re.finditer(pat,text):r['secret_hits'].append({'file':name,'line':text[:m.start()].count('\n')+1,'type':tag})
 return text
def archive(name,data,depth=0):
 assert depth<4
 with zipfile.ZipFile(io.BytesIO(data)) as z:
  for i in z.infolist():
   path=pathlib.PurePosixPath(i.filename);assert not path.is_absolute() and '..' not in path.parts and '\\' not in i.filename
   assert not stat.S_ISLNK(i.external_attr>>16);assert not i.flag_bits&1
   if i.is_dir():continue
   assert i.file_size<30_000_000
   d=z.read(i);r['archives'].append({'zip':name,'path':i.filename,'bytes':len(d)})
   if d.startswith(b'PK\x03\x04'):archive(name+'!'+i.filename,d,depth+1)
   else:scan(name+'!'+i.filename,d)
for p in s['files']:
 d=(R/p).read_bytes();r['types'][p]=('zip' if d.startswith(b'PK\x03\x04') else 'utf8')
 if d.startswith(b'PK\x03\x04'):archive(p,d);continue
 text=scan(p,d);d.decode('utf8')
 if p.endswith('.json'):json.loads(text);r['json'].append(p)
 if not p.endswith('.diff'):
  for n,line in enumerate(text.splitlines(),1):
   if line.rstrip(' \t')!=line:r['whitespace'].append([p,n])
 if p.endswith('.md'):
  for match in re.finditer(r'(?<!!)\[[^\]\n]*\]\(([^\s)]+)(?:\s+[^)]*)?\)',text):
   target=match[1]
   if target.startswith(('#','http:','https:','mailto:')):continue
   target=target.split('#')[0]
   if target and not (R/p).parent.joinpath(target).exists():r['links'].append([p,text[:match.start()].count('\n')+1,target])
r['workflow_paths']=[p for p in s['files'] if p.startswith('.github/workflows/')]
r['case_collisions']=len({p.casefold() for p in s['files']})!=len(s['files'])
r['freeze_after']=freeze()
(O/'results.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in r.items() if k not in ('types','archives','json')},ensure_ascii=False,indent=2));print('JSON',len(r['json']),'archive members',len(r['archives']))
