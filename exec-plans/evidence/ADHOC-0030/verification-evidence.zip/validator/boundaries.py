import pathlib,subprocess,os,json,re,hashlib,io,zipfile,stat
os.umask(0o077);R=pathlib.Path('/Volumes/DiskOther/Code/TrainLab');os.chdir(R);O=pathlib.Path('/private/var/tmp/trainlab-ci-pr-fydlv9x0/validator-v2-checks')
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0');results={}
def run(args,data=None):
 p=subprocess.run(args,input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env);return {'command':args,'exit':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()}
p='exec-plans/evidence/ADHOC-0029/closeout-status.diff';d=pathlib.Path(p).read_bytes()
raw=run(['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab','diff','--no-index','--check','/dev/null',p]);results['raw_patch_whitespace']=raw
results['patch_parse']=run(['git','apply','--numstat','--'],d)
lines=d.decode().splitlines();diag=[int(x) for x in re.findall(re.escape(p)+r':(\d+): trailing whitespace',raw['stdout'])]
results['patch_diagnostics']={'count':len(diag),'all_single_context_space':all(lines[n-1]==' ' for n in diag),'lines':diag,'sha256':hashlib.sha256(d).hexdigest()}
assert len(diag)==19 and all(lines[n-1]==' ' for n in diag) and results['patch_parse']['exit']==0
bad=d.replace(b'@@ -4,7 +4,7 @@',b'@@ -4,999 +4,7 @@',1);results['bad_patch']=run(['git','apply','--numstat','--'],bad);assert results['bad_patch']['exit']!=0
f=O/'bad-whitespace.txt';f.write_bytes(b'bad \n');results['bad_plain_whitespace']=run(['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab','diff','--no-index','--check','/dev/null',str(f)]);assert results['bad_plain_whitespace']['exit']!=0
s=json.loads(pathlib.Path('/private/var/tmp/trainlab-ci-pr-fydlv9x0/review-snapshot-v2.json').read_text());ordinary=[]
for p in s['files']:
 if p.endswith(('.zip','.diff')):continue
 q=run(['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab','diff','--no-index','--check','/dev/null',p]);assert q['exit'] in (0,1) and not q['stdout'] and not q['stderr'],q;ordinary.append(p)
results['ordinary_git_whitespace']={'count':len(ordinary),'exit':'0 for empty files; 1 for differences, no diagnostics'}
private=['states/Goal.md','states/goal.md','states/activities/demo.FIT','states/health/demo.json','states/verification/token.json','states/data.db-wal','.DS_Store','references/.DS_Store','demo.FiT','x.sqlite3','x.db-shm','.env','credentials.json']
public=['states/activities/.gitkeep','states/health/.gitkeep','states/verification/.gitkeep','states/Goal-example.md']
q=run(['git','check-ignore','--no-index','--stdin','-z'],('\0'.join(private+public)+'\0').encode());ignored=set(q['stdout'].split('\0'));assert set(private)<=ignored and not set(public)&ignored
results['ignore_synthetic']={'private_rejected':len(private),'public_allowed':len(public),'exit':q['exit']}
def accept(path,mode=stat.S_IFREG|0o644):
 a=pathlib.PurePosixPath(path)
 return not a.is_absolute() and '..' not in a.parts and '\\' not in path and stat.S_ISREG(mode) and path in s['files']
invalid=['../PLAN.md','/PLAN.md','states/Goal.md','memory.md','PLANS.md','docs/README.md','.github/workflows/replacement.yml','x.db','x.FIT','.DS_Store','remote-preflight.json']
assert all(not accept(p) for p in invalid);assert not accept('PLAN.md',stat.S_IFLNK|0o777);assert all(accept(p) for p in s['files'])
results['candidate_synthetic']={'allowed':len(s['files']),'rejected':len(invalid)+1}
results['markdown']={'json_blocks':0,'files':0}
for p in s['files']:
 if not p.endswith('.md'):continue
 text=pathlib.Path(p).read_text();fence=None;block=[]
 for line in text.splitlines():
  m=re.match(r'^\s*(`{3,}|~{3,})(.*)$',line)
  if m:
   if fence is None:fence=(m[1][0],len(m[1]),m[2].strip());block=[]
   elif m[1][0]==fence[0] and len(m[1])>=fence[1]:
    if fence[2]=='json':json.loads('\n'.join(block));results['markdown']['json_blocks']+=1
    fence=None
  elif fence:block.append(line)
 assert fence is None,p
 results['markdown']['files']+=1
for n in range(24,29):
 p=next(p for p in s['files'] if p.startswith('exec-plans/active/ADHOC-00'+str(n)))
 assert '- 功能状态：[plan]' in pathlib.Path(p).read_text()
results['five_product_states']='plan'
results['index_memory_entries']=[p for p in subprocess.check_output(['git','ls-files','-z'],env=env).decode().split('\0') if p.lower()=='memory.md']
(O/'boundaries.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(json.dumps(results,ensure_ascii=False,indent=2))
