# coding: utf-8
from pathlib import Path
import json,re,zipfile,hashlib,html,sys
R=Path('/Volumes/DiskOther/Code/TrainLab');E=Path('/private/var/tmp/trainlab-agentsmd-upgrade-tciokw12');V=R/'exec-plans/evidence/ADHOC-0029'
checks=[]
def check(k,ok,d=''):checks.append({'check':k,'passed':bool(ok),'detail':d})
def col(line):return [v.strip() for v in re.split(r'(?<!\\)\|',line.strip().strip('|'))]
def normalize(s):
    s=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'\1（原定位：\2）',s)
    return s.replace('\\|','|')
def equivalent(s):return html.unescape(s).replace('`','')
def source_rows(text):
    lines=text.splitlines();header=None;rows=[];i=0
    while i<len(lines):
        line=lines[i]
        if i+1<len(lines) and line.startswith('|') and re.fullmatch(r'[|:\-\s]+',lines[i+1]):
            header=col(line);i+=2;continue
        if not line.startswith('|'):header=None
        elif header and header[0] in ['步骤','Step','任务','阶段','模块']:
            statecol=next((j for j,h in enumerate(header) if h.startswith(('状态','Status'))),None)
            if statecol is not None:
                vals=col(line);assert len(vals)==len(header)
                rows.append({'line':i+1,'label':vals[0],'status':vals[statecol].strip('` '),'details':[v for j,v in enumerate(vals) if j not in [0,statecol]]})
        i+=1
    return rows

def target_rows(text):
    lines=text.splitlines();in_tasks=False;out=[]
    for line in lines:
        if line.startswith('| 任务编号 |'):in_tasks=True;continue
        if not line.startswith('|'):in_tasks=False
        if in_tasks and not re.fullmatch(r'[|:\-\s]+',line):
            vals=col(line)
            if len(vals)==7:out.append(vals)
    return out

def original_id(label):
    token=re.split(r'[\s：]',label.strip('` '),1)[0].strip('`')
    if any(c.isdigit() for c in token) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9./-]*',token):return token
    if token=='0001/0002及0003a-m':return token
    return None

def matches(row,target):
    label=equivalent(normalize(row['label']))
    return [v for v in target if equivalent(v[3]).startswith(label+'；')]

mapped=json.loads((V/'decomposition-mapping.json').read_text())
allmapping=json.loads((V/'migration-manifest.json').read_text())
oldsource_count=0;oldaggregate_missing=0
with zipfile.ZipFile(V/'history.zip') as z:
    for x in mapped:
        src=z.read(x['source']).decode();text=(R/x['destination']).read_text();target=target_rows(text);sr=source_rows(src)
        check('task-IDs-unique:'+x['source'],len({t[0] for t in target})==len(target))
        check('not-single-summary:'+x['source'],len(target)>1,len(target))
        oldbad=target_rows((E/'before-v001-repair'/Path(x['destination']).name).read_text())
        for row in sr:
            oldsource_count+=1;found=matches(row,target)
            check('source-task-present:'+x['source']+':'+str(row['line']),len(found)==1,row['label'])
            oldaggregate_missing+=not bool(matches(row,oldbad))
            if len(found)!=1:continue
            now=found[0];ident=original_id(row['label'])
            if ident:check('source-ID-kept:'+x['source']+':'+ident,now[0]==ident,[ident,now[0]])
            expected='[completed]' if row['status'] in ['done','completed'] else ('[plan]' if row['status'] in ['pending','planned','ready'] else '[exec]')
            if row['status']=='validated' and Path(x['source']).name.startswith('M10-'):
                road=z.read('PLANS.md').decode()
                check('validated-final-delivery-basis:'+ident,bool(re.search(r'^\| \[x\] `'+re.escape(ident)+r'`[^\n]*\| `completed`',road,re.M)))
                expected='[completed]'
                check('validated-mapping-explained:'+ident,'原PLANS' in now[-1])
            check('source-state-preserved:'+x['source']+':'+str(row['line']),now[2]==expected,[row['status'],now[2]])
            for n,value in enumerate(row['details']):
                check('source-result-preserved:'+x['source']+':'+str(row['line'])+':'+str(n),equivalent(normalize(value)) in equivalent(now[-1]))
        check('mapping-current-count:'+x['source'],len(target)==sum(len(g['tasks']) for g in x['groups']+x['excluded_groups']))
        for group in x['groups']+x['excluded_groups']:
            for task in group['tasks']:
                sourcefile=task.get('source_file',x['source']);lines=z.read(sourcefile).decode().splitlines()
                check('source-location:'+x['source']+':'+task['id'],1<=task['line']<=len(lines))
                check('dependency-no-header-artifact:'+x['source']+':'+task['id'],not task['dependency'].startswith('：'))
        for issue in x['issues']:
            check('issue-source-text:'+x['source']+':'+str(issue['line']),src.splitlines()[issue['line']-1]==issue['source_text'])
            check('issue-row-migrated:'+x['source']+':'+str(issue['line']),equivalent(normalize(issue['source_text'])) in equivalent(text))
    one=next(x for x in mapped if 'ADHOC-0018-' in x['source'])
    one_rows=target_rows((R/one['destination']).read_text())
    check('S1-S2-S3-regression',[(r[0],r[2]) for r in one_rows]==[('S1','[completed]'),('S2','[completed]'),('S3','[exec]')])
    m12=next(x for x in mapped if Path(x['source']).name.startswith('M12-'))
    m12text=(R/m12['destination']).read_text();m12rows=target_rows(m12text)
    check('M12-ten-original-items',len(m12rows)==10)
    for tid,dep in [('0004A','0003'),('0004B','0004A'),('0004C','0004B'),('0004D','0004C'),('0005','0004'),('0006','0005')]:
        check('M12-dependency:'+tid,next(t[4] for t in m12rows if t[0]==tid)==dep)
    check('M12-historical-unknown-preserved','ai_process_stop_unconfirmed' in m12text and 'UNDETERMINED' in m12text)
    ad17=next(x for x in mapped if 'ADHOC-0017-' in x['source'])
    text=(R/ad17['destination']).read_text();rr=target_rows(text)
    check('D01-D03-original-IDs',[v[0] for v in rr[:3]]==['D-01','D-02','D-03'])
    check('VC001-not-current-completion',len(ad17['excluded_groups'])==1 and len(ad17['excluded_groups'][0]['tasks'])==19 and '不计入当前适用阶段' in text)
    ad11=next(x for x in mapped if 'ADHOC-0011-' in x['source'])
    rr=target_rows((R/ad11['destination']).read_text())
    check('ADHOC0011-all-original-leaves-and-closeout',len(rr)==8 and [r[0] for r in rr[:4]]==['ADHOC-0011-000'+str(i) for i in range(1,5)])
    # Negative fixtures: old aggregate, one omitted step, renamed stable ID and changed state.
    check('V001-original-repro-detected',oldaggregate_missing==oldsource_count and oldsource_count>200,{'missing':oldaggregate_missing,'source_rows':oldsource_count})
    src=source_rows(z.read(one['source']).decode())[0]
    removed=one_rows[1:];check('negative-omitted-step',not matches(src,removed))
    renamed=[r[:] for r in one_rows];renamed[0][0]='wrong-ID';check('negative-renamed-ID',matches(src,renamed)[0][0]!=original_id(src['label']))
    wrong=[r[:] for r in one_rows];wrong[0][2]='[plan]';check('negative-completed-downgrade',matches(src,wrong)[0][2]!='[completed]')
# Current six design plans and all out-of-repair reviewed content stay byte-identical.
snapshot=json.loads((V/'review-snapshot.json').read_text())
repaired={x['destination'] for x in mapped}
allowed=repaired|{'exec-plans/active/ADHOC-0029-agentsmd-upgrade.md','exec-plans/evidence/ADHOC-0029/README.md'}
for path,spec in snapshot['files'].items():
    if path not in allowed:check('outside-repair-unchanged:'+path,hashlib.sha256((R/path).read_bytes()).hexdigest()==spec['sha256'])
report={'passed':all(c['passed'] for c in checks),'count':len(checks),'source_task_rows':oldsource_count,'checks':checks,'failed':[c for c in checks if not c['passed']]}
(E/'decomposition-regression.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='checks'},ensure_ascii=False,indent=2))
sys.exit(0 if report['passed'] else 1)
