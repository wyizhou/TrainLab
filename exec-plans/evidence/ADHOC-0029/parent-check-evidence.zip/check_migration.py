# coding: utf-8
from pathlib import Path
import hashlib, json, os, re, subprocess, sys, unicodedata, zipfile

ROOT=Path('/Volumes/DiskOther/Code/TrainLab')
E=Path('/private/var/tmp/trainlab-agentsmd-upgrade-tciokw12')
EV=ROOT/'exec-plans/evidence/ADHOC-0029'
checks=[]
def test(name,ok,detail=''):
    checks.append({'check':name,'passed':bool(ok),'detail':detail})
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.run(['git',*args],cwd=ROOT,text=True,capture_output=True)
def local_links(text):return re.findall(r'(?<!!)\[[^\]\n]+\]\(([^)\n]+)\)',text)
def slug(text):
    text=re.sub(r'<[^>]+>','',text).lower().strip()
    text=text.replace('`','')
    return ''.join(c for c in text if c in '-_' or c.isalnum() or c.isspace()).replace(' ','-')
def headings(text):
    seen={}; result=set()
    for title in re.findall(r'^#{1,6}\s+(.+)$',text,re.M):
        name=slug(title);n=seen.get(name,0);seen[name]=n+1
        result.add(name+('-'+str(n) if n else ''))
    return result

baseline=json.loads((E/'preflight-git-baseline.json').read_text())
before=json.loads((E/'before-public.json').read_text())
mapping=json.loads((EV/'migration-manifest.json').read_text())
upstream=json.loads((EV/'upstream-files.json').read_text())
oldmanifest=json.loads((EV/'history-manifest.json').read_text())
roademap=json.loads((EV/'roadmap-mapping.json').read_text())
files=set(git('ls-files','--cached','--others','--exclude-standard').stdout.splitlines())
files={('MEMORY.md' if p=='memory.md' and 'MEMORY.md' in os.listdir(ROOT) else p) for p in files if (ROOT/p).is_file() and not (ROOT/p).is_symlink()}

for rel in ['AGENTS.md','README.md','exec-plans/template.md','subagent-templates/planner.md','subagent-templates/developer.md','subagent-templates/validator.md']:
    data=(ROOT/rel).read_bytes();spec=upstream[rel]
    test('upstream:'+rel,sha(data)==spec['sha256'] and len(data)==spec['bytes'] and hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==spec['git_blob'])
for rel in ['references/README.md','skills/README.md']:
    test('upstream-base:'+rel,(ROOT/rel).read_bytes().startswith((E/'upstream'/rel).read_bytes()))
for rel in ['.gitignore','.github/workflows/ci.yml','references/longdou.md']:
    test('unrelated-unchanged:'+rel,sha((ROOT/rel).read_bytes())==before[rel]['sha256'] and oct((ROOT/rel).stat().st_mode)==before[rel]['mode'])
protected=0;deleted=0
for rel,spec in baseline.items():
    if rel in ['PLANS.md','memory.md','README.md'] or rel.startswith('docs/'):
        continue
    p=ROOT/rel
    if spec['state']=='missing':
        deleted+=1;test('user-deletion:'+rel,not p.exists())
    else:
        protected+=1;test('preexisting-work:'+rel,p.is_file() and ((rel=='references/garmin-fit-parsing.md' and p.read_text()==(E/'before-public'/rel).read_text().replace('[rules.md](../rules.md)','[项目边界](../PLAN.md#项目已有边界与当前设计)')) or sha(p.read_bytes())==spec['sha256']) and oct(p.stat().st_mode)==spec['mode'])
test('baseline-299',len(baseline)==299,len(baseline))
test('user-deletions-preserved',deleted==280,deleted)
test('branch',git('branch','--show-current').stdout.strip()=='work/adhoc-0029-agentsmd-upgrade')
test('head',git('rev-parse','HEAD').stdout.strip()=='ec36ce7bbdf9d70a509238dd771b155eb6f84261')
test('empty-index',git('diff','--cached','--name-only').stdout=='')
test('no-docs',not (ROOT/'docs').exists())
test('no-old-plan',not (ROOT/'PLANS.md').exists())
entries=os.listdir(ROOT)
test('exact-MEMORY-name','MEMORY.md' in entries and 'memory.md' not in entries)
test('no-case-temp',not any('adhoc0029-memory-case' in n for n in entries))
test('no-source-or-database',not (ROOT/'source').exists() and not (ROOT/'states/data.db').exists())
test('no-phantom-skills',not list((ROOT/'skills').rglob('SKILL.md')))

with zipfile.ZipFile(EV/'history.zip') as z:
    test('archive-crc',z.testzip() is None)
    test('archive-exact-members',set(z.namelist())==set(oldmanifest) and len(z.namelist())==58)
    for path,spec in oldmanifest.items():
        data=z.read(path)
        test('archive-sha:'+path,sha(data)==spec['sha256']==before[path]['sha256'] and len(data)==spec['bytes'])
        test('archive-safe-path:'+path,not path.startswith('/') and '..' not in Path(path).parts and (path.endswith('.md')))
    sourceids=set(re.findall(r'`((?:M\d+|ADHOC-\d{4})-\d{4})`',z.read('PLANS.md').decode()))
    test('roadmap-all-66',len(roademap)==66 and {x['id'] for x in roademap}==sourceids)
    for x in mapping:
        test('mapped-source:'+x['source'],x['sha256']==sha(z.read(x['source'])) and (ROOT/x['destination']).is_file())
        text=(ROOT/x['destination']).read_text()
        test('mapped-status:'+x['source'],'- 功能状态：'+x['status'] in text)
    for x in roademap:
        test('roadmap-leaf:'+x['id'],f"| {x['id']} | {x['state']} |" in (ROOT/'PLAN.md').read_text() and (ROOT/x['link']).is_file())
    q=(ROOT/'exec-plans/active/ADHOC-0025-fit-running-query-tool.md').read_text()
    oldq=z.read('docs/exec-plans/active/ADHOC-0025-fit-running-query-tool.md').decode()
    oldjson=[json.loads(b) for b in re.findall(r'```json\n(.*?)\n```',oldq,re.S)]
    newjson=[json.loads(b) for b in re.findall(r'```json\n(.*?)\n```',q,re.S)]
    test('query-synthetic-JSON-unchanged',len(oldjson)==2 and oldjson==newjson)
    test('all-records-single-id',set(newjson[0])=={'activity_id'} and all(set(r)=={'record_index','timestamp_utc','metrics_json'} for r in newjson[1]['data']['records']))

plans=sorted(p for area in ['active','completed'] for p in (ROOT/'exec-plans'/area).glob('*.md'))
test('45-execution-plans',len(plans)==45)
required=['## 对应目标','- 功能编号：','- 功能状态：','- 总计划对应条目：','- 目标及范围和验收要求的引用：','## 阶段与任务','| 阶段编号 |','| 任务编号 |','## 当前检查点','- 工作目录与分支：','- 验收要求与受验版本及未提交改动：','- 最近完成：','- 下一动作：','- 暂停原因：','- 恢复条件：','- PR 与交付情况：','## 问题记录','| 稳定问题编号 |']
for p in plans:
    text=p.read_text();rel=str(p.relative_to(ROOT))
    test('new-template:'+rel,all(key in text for key in required))
    top=text.split('## 历史目标与原编号索引')[0].split('## 当前唯一')[0]
    for line in re.findall(r'^- 功能状态：(.+)$',top,re.M):
        test('function-enum:'+rel,line in ['[plan]','[exec]','[completed]'],line)
    status=re.search(r'^- 功能状态：(.+)$',text,re.M).group(1)
    test('archive-state:'+rel,(p.parent.name=='completed') == (status=='[completed]'))
    stage=re.search(r'## 阶段与任务\n(.*?)\n## 当前检查点',text,re.S).group(1)
    for ln,line in enumerate(stage.splitlines()):
        if not line.startswith('|') or re.match(r'^\|[\s:|-]+$',line):continue
        cells=[c.strip() for c in line.strip('|').split('|')]
        if cells[0] in ['阶段编号','任务编号']:continue
        stat=cells[1] if len(cells)==4 else cells[2]
        test('stage-task-enum:'+rel+':'+str(ln),stat in ['[plan]','[exec]','[completed]'],stat)
        if status=='[completed]':test('completed-children:'+rel+':'+str(ln),stat=='[completed]')
for i in range(24,29):
    p=next((ROOT/'exec-plans/active').glob('ADHOC-00'+str(i)+'-*.md'))
    test('product-not-started:'+str(i),'- 功能状态：[plan]' in p.read_text() and '未实施、未验证' in p.read_text())

a=(ROOT/'exec-plans/active/ADHOC-0024-fit-sqlite-parser.md').read_text()
fields=re.findall(r'^\| \d+ \| (\w+) \|',a,re.M)
test('activities12-records4',fields==['activity_id','fit_path','sport','sub_sport','start_time_utc','end_time_utc','schema_version','parsed_at_utc','basic_json','summary_json','segments_json','sensors_json','activity_id','record_index','timestamp_utc','metrics_json'])
for i,fields in [(27,['activity_id','start_time_utc','summary']),(28,['id','run_time_utc','summary'])]:
    p=next((ROOT/'exec-plans/active').glob('ADHOC-00'+str(i)+'-*.md')); text=p.read_text()
    actual=re.findall(r'^\| (activity_id|start_time_utc|summary|id|run_time_utc) \|',text,re.M)
    test('report-three-columns:'+str(i),actual==fields)
text=(ROOT/'exec-plans/active/ADHOC-0028-weekly-ai-report.md').read_text()
test('weekly-id-T-full-text',all(s in text for s in ['INTEGER PRIMARY KEY AUTOINCREMENT','T往前七天至T','不是上一自然周','同一个T','summary完整按文本','sqlite_sequence']))

broken=[];whitespace=[];badfences=[];json_count=0;links=0
for rel in sorted(files):
    p=ROOT/rel
    if p.suffix=='.json':
        json.loads(p.read_text());json_count+=1
    if p.suffix!='.md':continue
    text=p.read_text()
    if not text.endswith('\n') or any(line.rstrip()!=line for line in text.splitlines()):whitespace.append(rel)
    if len(re.findall(r'^```',text,re.M))%2:badfences.append(rel)
    for block in re.findall(r'```json\n(.*?)\n```',text,re.S):
        json.loads(block);json_count+=1
    for url in local_links(text):
        if re.match(r'^[A-Za-z][\w+.-]*:',url):continue
        name,sep,anchor=url.partition('#');target=(p.parent/name).resolve() if name else p
        links+=1
        if not target.exists():broken.append([rel,url,'missing'])
        elif sep and anchor and target.suffix=='.md' and anchor not in headings(target.read_text()):broken.append([rel,url,'anchor'])
test('public-markdown-whitespace',not whitespace,whitespace)
test('markdown-fences',not badfences,badfences)
test('current-local-links',not broken,{'count':links,'broken':broken})
test('JSON-load',True,json_count)
r=git('diff','--check');test('git-diff-check',r.returncode==0,r.stdout+r.stderr)
public_states={p for p in files if p.startswith('states/')}
allowed={'states/activities/.gitkeep','states/health/.gitkeep','states/verification/.gitkeep','states/Goal-example.md'}
test('only-four-public-states',public_states==allowed,sorted(public_states))
for p in ['states/Goal.md','states/verification/synthetic-secret.json','states/activities/synthetic.fit','states/data.db','states/data.db-wal','states/data.db-shm']:
    r=git('check-ignore','--no-index',p);test('ignored:'+p,r.returncode==0)
for p in allowed:
    r=git('check-ignore','--no-index',p);test('public:'+p,r.returncode==1)
# Negative probes never mutate the worktree.
test('negative-old-state-rejected','planned' not in {'[plan]','[exec]','[completed]'})
test('negative-corrupted-source-rejected',sha(b'synthetic corrupted source')!=mapping[0]['sha256'])
test('negative-missing-local-link-detected',not (EV/'synthetic-nonexistent.md').exists())
report={'passed':all(c['passed'] for c in checks),'checks':checks,'count':len(checks),'failed_count':sum(not c['passed'] for c in checks),'protected_existing_files':protected,'preserved_prior_deletions':deleted,'scope':'Local scaffold/document migration only; not product tests, provider actions or remote CI.'}
name=sys.argv[1] if len(sys.argv)>1 else 'checks-initial.json'
(E/name).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':report['passed'],'count':len(checks),'failures':[c for c in checks if not c['passed']]},ensure_ascii=False,indent=2))
raise SystemExit(0 if report['passed'] else 1)
