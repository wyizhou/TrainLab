# coding: utf-8
from pathlib import Path
import re,json,zipfile,hashlib,sys
R=Path('/Volumes/DiskOther/Code/TrainLab');E=Path('/private/var/tmp/trainlab-agentsmd-upgrade-tciokw12');V=R/'exec-plans/evidence/ADHOC-0029'
checks=[]
def ck(k,ok,d=''):checks.append({'check':k,'passed':bool(ok),'detail':d})
def display(s):return re.sub(r'!?\[([^\[\]\n]+)\]\(([^)\n]+)\)',r'\1（原定位：\2）',s)
def projected_chunks(text):
    section=text.split('## 原任务定义与验收\n',1)[1].split('## 历史来源与证据\n',1)[0]
    chunks={};current=None
    for line in section.splitlines():
        m=re.fullmatch(r'### 原定义-L(\d+)',line)
        if m:current=int(m.group(1));chunks[current]=[]
        elif current is not None:
            if line=='>':chunks[current].append('')
            elif line.startswith('> '):chunks[current].append(line[2:])
    return chunks

def task_rows(text):
    return {c[0]:c for line in text.splitlines() if line.startswith('|') for c in [[v.strip() for v in line.strip('|').split('|')]] if len(c)==7 and c[2] in ['[plan]','[exec]','[completed]']}

mapping=json.loads((V/'definition-mapping.json').read_text());total=0
with zipfile.ZipFile(V/'history.zip') as z:
    for item in mapping:
        source=z.read(item['source']).decode();lines=source.splitlines();text=(R/item['destination']).read_text();chunks=projected_chunks(text);rows=task_rows(text)
        ck('source-sha:'+item['source'],hashlib.sha256(source.encode()).hexdigest()==item['source_sha256'])
        ck('source-line-count:'+item['source'],len(lines)==item['source_lines'])
        nextline=1;reconstructed=[]
        for ch in item['chunks']:
            start,end=ch['start_line'],ch['end_line'];ck('continuous-source:'+item['source']+':'+str(start),start==nextline and end>=start);nextline=end+1
            observed=chunks.get(start,[]);expected=display('\n'.join(lines[start-1:end])).split('\n')
            ck('complete-source-chunk:'+item['source']+':'+str(start),observed==expected,{'source_lines':[start,end],'observed_lines':len(observed)})
            reconstructed.extend(observed)
        ck('all-original-content-projected:'+item['source'],reconstructed==display(source).splitlines() and nextline==len(lines)+1)
        ck('historical-not-current-authority:'+item['source'],'不是当前开发协议、可运行示例或新的业务授权' in text and '不把后续规则回套早期结果' in text)
        for assoc in item['task_associations']:
            row=rows[assoc['task_id']]
            ck('task-definition-input-and-check-link:'+item['source']+':'+assoc['task_id'],all('](#原任务定义与验收)' in row[col] for col in [3,5]))
            for anchor in assoc['specific_anchors']:
                ck('specific-task-link:'+item['source']+':'+assoc['task_id']+':'+anchor,all('](#'+anchor+')' in row[col] for col in [3,5]))
        ck('all-current-tasks-associated:'+item['source'],len(rows)==len(item['task_associations']))
        total+=len(lines)
    m4=next(x for x in mapping if Path(x['source']).name.startswith('M4-'))
    text=(R/m4['destination']).read_text();chunks=projected_chunks(text);rows=task_rows(text)
    for tid,start in [('M4-0001',34),('M4-0002',46),('M4-0003',58),('M4-0004',70)]:
        row=rows[tid];anchor='](#原定义-l'+str(start)+')'
        ck('M4-specific-original-definition:'+tid,anchor in row[3] and anchor in row[5])
    original=z.read(m4['source']).decode().splitlines()
    ck('M4-input-exclusion-ambiguity-complete',chunks[46]==display('\n'.join(original[45:57])).split('\n'))
    ck('M4-coaching-contract-errors-complete',chunks[58]==display('\n'.join(original[57:69])).split('\n'))
    ck('M4-original-serial-dependency',all('原Roadmap同编号依赖：M4-000'+str(i-1) in rows['M4-000'+str(i)][4] for i in range(2,5)))
    # This check derives expected definition text from the immutable source, not from migrated result summaries.
    damaged={k:v[:] for k,v in chunks.items()};damaged[46]=[s for s in damaged[46] if '禁止猜测' not in s]
    ck('negative-omit-non-table-error-boundary',damaged[46]!=display('\n'.join(original[45:57])).split('\n'))
    wrong=rows['M4-0002'][3].replace('](#原定义-l46)','](#原定义-l58)')
    ck('negative-misassociate-task-definition','](#原定义-l46)' not in wrong)
    previous=(E/'before-definition-repair'/Path(m4['destination']).name).read_text()
    ck('V001-second-repro-detected','## 原任务定义与验收\n' not in previous and '](#原定义-l46)' not in previous)
ck('half-open-interval-not-link-label',display('[start,end); [CI](https://example.invalid)')=='[start,end); CI（原定位：https://example.invalid）')
ck('no-cross-section-link-label',display('[start,end)\n## section\n[CI](https://example.invalid)')=='[start,end)\n## section\nCI（原定位：https://example.invalid）')
report={'passed':all(c['passed'] for c in checks),'count':len(checks),'source_lines':total,'current_task_associations':sum(len(x['task_associations']) for x in mapping),'checks':checks,'failed':[c for c in checks if not c['passed']]}
(E/'definition-regression.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='checks'},ensure_ascii=False,indent=2));sys.exit(0 if report['passed'] else 1)
