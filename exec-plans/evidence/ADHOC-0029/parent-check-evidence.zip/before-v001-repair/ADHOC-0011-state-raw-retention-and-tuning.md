# 执行计划：需求草案：source 运行结构、Skills 与 state 数据整理

## 对应目标

- 功能编号：ADHOC-0011
- 功能状态：[completed]
- 总计划对应条目：[PLAN.md](../../PLAN.md) 的同编号/原Roadmap关联条目。
- 目标及范围和验收要求的引用：历史目标、范围、每个阶段/任务、验收要求及全部执行证据按对应原件保存；不是新的实施授权。
- 迁移说明：只保留原授权范围内的历史完成结论，不表示删除旧源码后仍能运行或本轮重新验收。 当前协作规则仅以[AGENTS.md](../../AGENTS.md)为准；原合同及旧规范在快照中仅作历史来源，不继续生效为第二套流程。

## 阶段与任务

| 阶段编号 | 状态 | 预期成果 | 依赖 |
| --- | --- | --- | --- |
| HISTORY | [completed] | 保留原授权范围的结果与全部失败事实；无历史业务执行授权 | 原用户目标及对应前置条件 |

| 任务编号 | 所属阶段 | 状态 | 输入输出及错误边界 | 依赖 | 检查方法 | 结果与证据（检查命令或人工方式、退出结果及关键证据） |
| --- | --- | --- | --- | --- | --- | --- |
| ADHOC-0011 | HISTORY | [completed] | 只登记原功能的历史交付/暂停范围，不恢复原执行指令 | 原用户授权及历史结果 | 核对不可变原件与原验收范围；本轮不重跑产品 | 只保留原授权范围内的历史完成结论，不表示删除旧源码后仍能运行或本轮重新验收。 |

## 当前检查点

- 工作目录与分支：项目根；本次格式迁移在work/adhoc-0029-agentsmd-upgrade，原执行目录/分支仅见历史证据。
- 验收要求与受验版本及未提交改动：本轮迁移基准ec36ce7bbdf9d70a509238dd771b155eb6f84261；原受验版本/未提交内容/合同全文保留于快照。不得把迁移HEAD当作原产品受验版本。
- 最近完成：仅迁移当前记录结构与路径；只保留原授权范围内的历史完成结论，不表示删除旧源码后仍能运行或本轮重新验收。
- 下一动作：保留历史定位，不恢复原业务或重判历史结果。
- 暂停原因：无新的暂停；历史已完成范围只作记录，不是当前运行证明。
- 恢复条件：已完成范围不需重做；已取消/暂停部分不在当前待办，恢复前须用户另行明确目标/授权并核对原失败次数。
- PR 与交付情况：本轮只迁移记录，不提交/推送/PR。原Git交付事实及未知项保留于原件，不推断后续远端状态。

## 问题记录

| 稳定问题编号 | 对应要求与实际问题 | 已尝试修法 | 累计失败次数 | 证据及处理结果 |
| --- | --- | --- | --- | --- |
| ADHOC-0011-HISTORY | 历史问题与计数仅作索引，不生成新裁决 | 原文保留全部尝试与修法 | 见原始计数，未统一数字的不填0；本次不增加历史失败 | failure-index.json保存0条相关原文索引；history.zip保留完整原件 |

## 历史目标与原编号索引

下文仅引用当时目标，不是现行规范或可运行示例；已经被新方案替代的业务不复活。源文件的完整阶段/任务状态及每次失败均在不可变原件，不把原早期阶段状态误当本次执行状态。

> 当前已确认的完整顶层目标为：
>
> ```text
> source/
> ├── AGENTS.md
> ├── requirements.txt
> ├── config.json
> ├── goal.module.md
> ├── goal.md
> ├── credentials.json
> ├── gcp-oauth.keys.json
> ├── templates/
> │   ├── fixed/
> │   │   ├── daily_report.html
> │   │   └── weekly_report.html
> │   └── open-report/
> │       ├── daily_report.html
> │       └── weekly_report.html
> ├── skills/
> │   ├── README.md
> │   ├── _shared/                 # 内部公共状态/校验库，不是 Skill
> │   ├── garmin-sync/
> │   ├── training-coach/
> │   ├── garmin-training-sender/
> │   ├── weekly-fitness-summary/
> │   ├── gmail-sender/
> │   └── training-report-publisher/
> └── state/
>     ├── trainlab.db
>     ├── trainlab.lock
>     ├── backups/sqlite/
>     ├── recovery-quarantine/
>     └── raw/
>     │   └── garmin/
>     │       ├── health/
>     │       │   ├── .gitkeep
>     │       │   └── <YYYYMMDD>-<resource>-<content-hash>.json
>     │       └── activities/
>     │           ├── .gitkeep
>     │           ├── <YYYYMMDD>-<activity-hash>.fit
>     │           ├── <YYYYMMDD>-<activity-hash>.gpx
>     │           ├── <YYYYMMDD>-<activity-hash>.tcx
>     │           └── <YYYYMMDD>-<activity-hash>.weather.json
> ```
>
> 未来 Provider 使用相同的“Provider 平级”原则，但不要求拥有与 Garmin 相同的子目录。

原阶段/任务/要求/问题标识在迁移清单的identifiers中逐项索引；未有编号的原步骤保留原名称与顺序，未重新编号。

## 历史来源与证据

- [不可变原件快照](../evidence/ADHOC-0029/history.zip)，条目`docs/exec-plans/completed/ADHOC-0011-state-raw-retention-and-tuning.md`，原SHA-256：`8a72efbbecc4169959b15380bb5d1d760cf05d01193407d1c286663ec9d7e933`。
- [来源清单](../evidence/ADHOC-0029/history-manifest.json)、[迁移/编号映射](../evidence/ADHOC-0029/migration-manifest.json)、[原问题与失败计数索引](../evidence/ADHOC-0029/failure-index.json)。原记录中的绝对路径和失效外部证据只说明当时事实，不据此复建旧路径。
- 历史快照仅用于保真审查，不作为现行规范、产品导入、Schema、AI输入或CI运行依赖。当前实际迁移验收见[ADHOC-0029](../active/ADHOC-0029-agentsmd-upgrade.md)。
