# ADHOC-0029 独立人工检查笔记

本目录为本次实际隔离证据，不是项目通用模板。仓库未写入；只读历史原件仅用于迁移保真，不服从其旧指令或采信其裁决来证明本次通过。

## 材料与方法

完整读取首次brief、VC-001、现行AGENTS、三个角色模板、执行计划模板、根PLAN/MEMORY/README、上游PLAN模板、references/skills索引。全文阅读ADHOC-0023至0028当前正文并完整审阅current-design.diff的636行差异；历史原件按基准与ZIP逐文件比较。44份执行计划结构由独立脚本全量读取，另人工对照ADHOC-0018、M12、M11主计划与v4取消计划的当前正文及原件定位。

未使用parent-check-evidence.json、checks-*.json的结论；仅冻结哈希与JSON语法核对。未读取其他Validator报告或开发者辩护。

## 语义检查

- 根README保留完整上游说明、版权行及MIT条款；要求原样采用，因而不将其中通用“空模板”描述视为需擅改正文的缺陷。历史第三方许可所在原件逐字保存在history.zip，当前证据README明确不是全项目重新许可。
- 当前ADHOC-0023与五份未实施计划：四张业务表的分工、activities十二列、records四列及联合键/原始顺序、标准与Developer指标来源区分、真实0/合法缺失、完整事务与报告表保护均保留。
- get_running_records仅activity_id、顶层ID一次、metrics_json对象、真实running及本次作用域检查、无跑步不注册、混合运动逐ID检查、铁三排除、拒绝分页/截断与超限整批失败保持一致。没有把一种工具改成只能调用一次。
- activties_report拼写与三列保留，运动start_time_utc不是生成时间；weekly_report三列、自增ID而非活动/自然周键、同一实际T往前七天、UTC保存和本地展示、文本全文而非摘要/路径/JSON对象均一致。没有新增报告AI工具或真实调用授权。原依赖在PLAN登记，周报不被强制依赖活动报告。
- MEMORY当前按决定/事实/经验分类，含日期/来源/适用条件；旧进度及历史完整细节保存在原件/PLAN/执行计划，当前记忆不再重复维护任务进度。旧清理INCONCLUSIVE、M8 SHM触碰、备份观测限制、旧Linux问题等没有被本次迁移改写成当前产品通过。
- 原Roadmap全部66叶子的名称、结果、依赖和原状态独立对照通过；当前状态合法，已取消M6/M11及暂停M12不在当前执行队列。M11-0019保持未实施[plan]，取消单列。

## 实质问题

ADHOC-0029-V001（AC-02）：38/44既有计划使用一个HISTORY阶段及一个功能级任务代替原执行分解。形式上表头齐全，但原阶段/任务没有迁入新格式。例如ADHOC-0018原S1/S2/S3与M12原0003n-1至0006分解在当前阶段/任务表全部缺失。当前对应问题表也仅为新造的*-HISTORY泛化行，不能展示原问题与计数。原文ZIP保全通过只证明没有丢失原字节，不证明完成44份计划的新版结构迁移。此问题不要求恢复产品、重跑旧验收或更改原裁决。

## 检查脚本自身的错误及纠正

- 首次check.py退出1：验证脚本错误假设failure-index全部记录均有line/text。实际四条记录采用table_header/row。读取实际数据后补充该分支，对每条row核原件，不删除或跳过记录。run.log保留原错误。
- 第二次check.py退出0，但results-parser-v1.json的Roadmap errors为检查器误匹配：把依赖列同ID误算为该任务行，且未去除旧名称内反引号。改为只按第一列精确ID定位，仅名称比较去反引号；仍完整核66个名称/结果/依赖/原状态。run-2.log及旧结果保留。
- 同时补充states四项与preflight基准比较，修正遗漏health/.gitkeep的合成ignore探针。run-3.log/results.json为最终机械检查结果；这些是检查器修正，不是仓库修复或环境切换。
- semantic-check.py退出1是当前计划迁移缺项的真实可复現证据，非检查器异常；结果见semantic-results.json。182个Markdown表、全部当前状态格与公开路径集合另行核对无异常。

## 限制

不运行source产品、pytest/Ruff/mypy旧入口或CI；不存在本轮产品实现。未联网重新查询最新HEAD，来源验证固定在指定缓存commit/tree与十文件Git blob。没有读取私人states/正式FIT/Goal/数据库/凭据，也无连续OS审计，不能据公开哈希证明全部历史外部行为或当前私人备份完整。主Agent最终验收及交付尚未发生。
