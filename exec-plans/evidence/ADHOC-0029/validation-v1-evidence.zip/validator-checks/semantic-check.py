# -*- coding: utf-8 -*-
import pathlib,json,re,os,sys,zipfile,subprocess
os.umask(0o077)
R=pathlib.Path('/Volumes/DiskOther/Code/TrainLab');O=pathlib.Path('/private/var/tmp/trainlab-agentsmd-upgrade-tciokw12/validator-checks');E=R/'exec-plans/evidence/ADHOC-0029'
Z=zipfile.ZipFile(E/'history.zip')
M=json.loads((E/'migration-manifest.json').read_text());S=json.loads((E/'review-snapshot.json').read_text())
rows=[]
for ident,ids in [('ADHOC-0018',['S1','S2','S3']),('M12',['0003n-1','0003n-2','0003n-3','0004A','0004B','0004C','0004D','0005','0006'])]:
 d=next(x for x in M if x['id']==ident);old=Z.read(d['source']).decode();new=(R/d['destination']).read_text()
 section=new.split('## 阶段与任务')[1].split('## 当前检查点')[0]
 source_lines=[{'line':i,'text':l} for i,l in enumerate(old.splitlines(),1) if l.startswith('|') and any(re.match(r'^\| '+re.escape(k)+r'(?:\s|\|)',l) for k in ids)]
 assert len(source_lines)==len(ids)
 missing=[k for k in ids if not re.search(r'^\| '+re.escape(k)+r'(?:\s|\|)',section,re.M)]
 rows.append({'id':ident,'source':d['source'],'source_lines':source_lines,'current':d['destination'],'current_lines':[{'line':i,'text':l} for i,l in enumerate(new.splitlines(),1) if 11<=i<=39],'expected_identifiers_in_new_plan':ids,'missing':missing,'pass':not missing})
# Check actual table states/shape separately from historical semantic completeness.
state_errors=[];table_errors=[];num_tables=0
for p in [p for p in S['files'] if p.endswith('.md')]:
 text=(R/p).read_text();fence=False;expected=None
 for i,l in enumerate(text.splitlines(),1):
  if l.startswith('```'):fence=not fence;expected=None;continue
  if fence:continue
  if not l.startswith('|'):expected=None;continue
  cells=[x.strip() for x in re.split(r'(?<!\\)\|',l)[1:-1]]
  if expected is None:expected=len(cells);num_tables+=1
  elif len(cells)!=expected:table_errors.append([p,i,expected,len(cells),l])
  if p=='PLAN.md' or p.startswith('exec-plans/active/') or p.startswith('exec-plans/completed/'):
   for c in cells:
    if re.fullmatch(r'\[[^\]]+\]',c) and c not in ['[plan]','[exec]','[completed]']:state_errors.append([p,i,c])
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=R,env=env).decode().split('\0')
public={p for p in paths if p and (R/p).is_file()}
# The actual directory spelling differs from the unchanged index on this case-insensitive filesystem.
if 'memory.md' in public:public.remove('memory.md');public.add('MEMORY.md')
expected=set(S['files'])|{'exec-plans/evidence/ADHOC-0029/review-snapshot.json'}
public_diff={'extra':sorted(public-expected),'missing':sorted(expected-public)}
result={'scenarios':rows,'all_current_state_cells_valid':not state_errors,'state_errors':state_errors,'markdown_tables':num_tables,'table_errors':table_errors,'public_path_set_difference':public_diff,'conclusion':'FAIL' if any(not x['pass'] for x in rows) else 'PASS','note':'The source archive is byte-preserved; this checks AC-02 current plan migration completeness, not old product behavior or loss of archive data.'}
(O/'semantic-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
sys.exit(1 if result['conclusion']=='FAIL' else 0)
