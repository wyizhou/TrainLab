# -*- coding: utf-8 -*-
import os, sys, re, json, hashlib, pathlib, subprocess, zipfile, difflib, datetime
os.umask(0o077)
os.environ['GIT_OPTIONAL_LOCKS']='0'
R=pathlib.Path('/Volumes/DiskOther/Code/TrainLab')
B=pathlib.Path('/private/var/tmp/trainlab-agentsmd-upgrade-tciokw12')
O=B/'validator-checks'
os.chdir(R)
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],env=os.environ)
def load(p):return json.loads(pathlib.Path(p).read_text())
S=load(R/'exec-plans/evidence/ADHOC-0029/review-snapshot.json')
E=R/'exec-plans/evidence/ADHOC-0029'
results={}
def freeze():
 errors=[]
 for p,d in S['files'].items():
  q=R/p
  if not q.is_file():errors.append([p,'missing']);continue
  actual={'sha256':sha(q.read_bytes()),'bytes':q.stat().st_size,'mode':oct(q.stat().st_mode)}
  if actual!=d:errors.append([p,actual,d])
 absent=sorted(p for p in git('ls-files','-z').decode().split('\0') if p and not (R/p).exists())
 checks={'files':len(S['files']),'file_errors':errors,'absent_count':len(absent),'absent_match':absent==sorted(S['tracked_absent']),'head':git('rev-parse','HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'index_sha256':sha(git('ls-files','--stage','-z')),'snapshot_sha256':sha((E/'review-snapshot.json').read_bytes()),'contract_sha256':sha((B/'contract-vc001.md').read_bytes()),'staged_diff':git('diff','--cached','--name-only').decode(),'memory_names':[p for p in os.listdir(R) if p.lower()=='memory.md']}
 assert not errors and checks['absent_match']
 assert checks['head']==S['head'] and checks['branch']==S['branch'] and checks['index_sha256']==S['index_entries_sha256']
 assert checks['snapshot_sha256']=='b49d7f667c4e9cf92039dbb22a701083e534091e00d7881f886b5077292545a4'
 assert checks['contract_sha256']==S['contract_sha256']
 return checks
results['freeze']=freeze()
if len(sys.argv)>1 and sys.argv[1]=='freeze':
 (O/'freeze-end.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(json.dumps(results,ensure_ascii=False,indent=2));sys.exit(0)
T=load(B/'upstream-tree.json')
C=load(B/'upstream-commit.json')
assert T['sha']=='768a3143bff5e970b6c4ce03431dbfce425e2e32' and C['sha']==T['sha']
up=[]
for e in T['tree']:
 if e['type']!='blob':continue
 p=e['path'];b=(B/'upstream'/p).read_bytes()
 blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 assert blob==e['sha']
 up.append({'path':p,'blob_verified':True,'same_bytes':(R/p).read_bytes()==b,'prefix_preserved':(R/p).read_bytes().startswith(b)})
results['upstream']=up
six=['AGENTS.md','README.md','exec-plans/template.md']+['subagent-templates/'+x+'.md' for x in ['planner','developer','validator']]
assert all((R/p).read_bytes()==(B/'upstream'/p).read_bytes() for p in six)
Z=zipfile.ZipFile(E/'history.zip');H=load(E/'history-manifest.json');before=load(B/'before-public.json')
assert set(Z.namelist())==set(H)
for p in H:
 b=Z.read(p)
 assert sha(b)==H[p]['sha256']==before[p]['sha256']
 assert b==(B/'before-public'/p).read_bytes()
results['history']={'entries':len(H),'original_markdown_count':sum(p.endswith('.md') for p in before),'all_bytes_equal_baseline':True,'zip_integrity':Z.testzip()}
F=load(E/'failure-index.json')
entry_count=0
for p,d in F.items():
 lines=Z.read(p).decode().splitlines()
 assert d['sha256']==sha(Z.read(p))
 for e in d['entries']:
  if 'line' in e:assert lines[e['line']-1]==e['text']
  else:
   assert e['row'] in lines
   assert all(any(label in line for line in lines) for label in e['table_header'])
  entry_count+=1
results['failure_index']={'sources':len(F),'indexed_lines_verified':entry_count,'full_originals_retained':True}
M=load(E/'migration-manifest.json')
oldplans={p for p in H if re.match(r'docs/exec-plans/(active|completed)/.+\.md$',p) and pathlib.Path(p).name!='README.md'}
assert {d['source'] for d in M}==oldplans
assert len({d['destination'] for d in M})==len(M)
mandatory=['## 对应目标','## 阶段与任务','## 当前检查点','## 问题记录','- 功能编号：','- 功能状态：','- 总计划对应条目：','- 目标及范围和验收要求的引用：','- 工作目录与分支：','- 验收要求与受验版本及未提交改动：','- 最近完成：','- 下一动作：','- 暂停原因：','- 恢复条件：','- PR 与交付情况：']
plan_report=[]
for d in M:
 p=d['destination'];text=(R/p).read_text()
 assert all(x in text for x in mandatory)
 assert '- 功能状态：'+d['status'] in text
 assert ('/completed/' in p)==(d['status']=='[completed]')
 original=Z.read(d['source']).decode()
 section=text.split('## 阶段与任务')[1].split('## 当前检查点')[0]
 plan_report.append({'source':d['source'],'destination':p,'status':d['status'],'generic_history':bool(re.search(r'^\| HISTORY \|',section,re.M)),'current_task_rows':[l for l in section.splitlines() if l.startswith('|') and len(l.split('|'))>=9 and '[plan]' in l or l.startswith('|') and len(l.split('|'))>=9 and ('[exec]' in l or '[completed]' in l)],'original_heading_lines':[{'line':i,'text':l} for i,l in enumerate(original.splitlines(),1) if l.startswith('#')], 'original_stage_table_rows':[{'line':i,'text':l} for i,l in enumerate(original.splitlines(),1) if l.startswith('|') and re.search(r'\b(S\d+|M\d+-\d+|ADHOC-\d+)',l)]})
results['plans']={'existing_plans':len(M),'headings_present':True,'generic_history_count':sum(d['generic_history'] for d in plan_report),'details_file':'plan-structure.json'}
(O/'plan-structure.json').write_text(json.dumps(plan_report,ensure_ascii=False,indent=2))
road=load(E/'roadmap-mapping.json');old=Z.read('PLANS.md').decode();current=(R/'PLAN.md').read_text()
leaf_rows=[l for l in old.splitlines() if l.startswith('|') and re.search(r'\b(?:M\d+|ADHOC-\d+)-\d{4}\b',l)]
road_errors=[]
for d in road:
 matches=[l for l in leaf_rows if '`'+d['id']+'`' in l.split('|')[1]]
 if len(matches)!=1:road_errors.append([d['id'],'row_match_count',len(matches)]);continue
 src=matches[0]
 for k in ['name','result','dependency','original_state']:
  candidate=src.replace('`','') if k=='name' else src
  if d[k] not in candidate:road_errors.append([d['id'],k,d[k],src])
 dst=[l for l in current.splitlines() if l.startswith('| '+d['id']+' |')]
 if not any(all(d[k] in l for k in ['state','name','result','dependency','link']) for l in dst):road_errors.append([d['id'],'current row not matched'])
results['roadmap']={'mapping_count':len(road),'original_leaf_rows':len(leaf_rows),'errors':road_errors}
refdiff=[]
for p in ['references/garmin-fit-parsing.md','references/longdou.md']:
 a=(B/'before-public'/p).read_text();b=(R/p).read_text()
 refdiff.extend(difflib.unified_diff(a.splitlines(),b.splitlines(),fromfile='before/'+p,tofile=p,lineterm=''))
(O/'reference.diff').write_text('\n'.join(refdiff)+'\n')
results['references']={'diff_file':'reference.diff','reference_files':sorted(p.name for p in (R/'references').iterdir() if p.is_file()),'skill_files':sorted(str(p.relative_to(R/'skills')) for p in (R/'skills').rglob('*') if p.is_file())}
mds=[R/p for p in S['files'] if p.endswith('.md')]
link_issues=[];fmt_issues=[];links=0;json_blocks=0
for p in mds:
 text=p.read_text();fence=None;outside=[];block=[]
 for i,l in enumerate(text.splitlines(),1):
  if l.startswith('```'):
   if fence is None:fence=l[3:].strip();block=[]
   else:
    if fence=='json':json.loads('\n'.join(block));json_blocks+=1
    fence=None
   continue
  if fence is not None:block.append(l);continue
  outside.append((i,l))
 if fence is not None:fmt_issues.append([str(p.relative_to(R)),'unclosed fence'])
 for i,l in outside:
  for match in re.finditer(r'(?<!!)\[[^\]]+\]\(([^)]+)\)',l):
   target=match.group(1)
   if re.match(r'[a-zA-Z][a-zA-Z0-9+.-]*:',target):continue
   links+=1
   path,sep,anchor=target.partition('#')
   dest=(p.parent/path) if path else p
   if not dest.exists():link_issues.append([str(p.relative_to(R)),i,target,'missing path']);continue
   if anchor and dest.is_file() and dest.suffix=='.md':
    heads=re.findall(r'^#{1,6}\s+(.+)',dest.read_text(),re.M)
    slugs=[re.sub(r'[^\w\-\s]','',x.lower()).replace(' ','-') for x in heads]
    if anchor not in slugs:link_issues.append([str(p.relative_to(R)),i,target,'anchor not found'])
results['markdown']={'files':len(mds),'links':links,'link_issues':link_issues,'fence_issues':fmt_issues,'json_blocks_parsed':json_blocks}
parsed_json=[]
for p in S['files']:
 if p.endswith('.json'):
  # Parse reviewed metadata; self-check conclusions are not used as evidence.
  json.loads((R/p).read_bytes());parsed_json.append(p)
results['json_files_parsed']=len(parsed_json)
protected=['.gitignore','.github/workflows/ci.yml']+[p for p in before if p.startswith('states/')]
for p in protected:assert sha((R/p).read_bytes())==before[p]['sha256']
pre=load(B/'preflight-git-baseline.json')
for p,d in pre.items():
 if p.startswith('states/'):
  assert sha((R/p).read_bytes())==d['sha256'] and oct((R/p).stat().st_mode)==d['mode']
  protected.append(p)
restored=[p for p,d in pre.items() if d['state']=='missing' and (R/p).exists()]
assert restored==['README.md']
results['protection']={'protected_equal':protected,'baseline_missing_count':sum(d['state']=='missing' for d in pre.values()),'restored':restored,'docs_exists':(R/'docs').exists(),'source_exists':(R/'source').exists(),'old_entry_names_present':[p for p in ['PLANS.md','memory.md','rules.md','CLAUDE.md'] if p in os.listdir(R)]}
probes=['states/data.db','states/Goal.md','states/verification/test.json','states/activities/synthetic.fit','states/activities/synthetic.weather.json','states/anything.txt','states/.gitkeep','states/activities/.gitkeep','states/health/.gitkeep','states/verification/.gitkeep','states/Goal-example.md']
ignore=[]
for p in probes:
 c=subprocess.run(['git','check-ignore','--no-index',p],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=os.environ)
 ignore.append({'path':p,'ignored':c.returncode==0,'exit':c.returncode})
results['ignore_synthetic_paths']=ignore
# Negative fixtures operate only on in-memory copies, no reviewed content modified.
orig=(R/'exec-plans/active/ADHOC-0028-weekly-ai-report.md').read_text()
def valid_state(t):
 return all(x in {'plan','exec','completed'} for x in re.findall(r'\|\s*\[([^\]]+)\]\s*\||功能状态：\[([^\]]+)\]',t) for x in x if x)
def stable_payload(b,expected):return b is not None and sha(b)==expected
synthetic={'good_state':valid_state(orig),'bad_state_rejected':not valid_state(orig.replace('[plan]','[blocked]',1)),'good_hash':stable_payload(b'ok',sha(b'ok')),'bad_hash_rejected':not stable_payload(b'bad',sha(b'ok')),'missing_file_rejected':not stable_payload(None,sha(b'ok')),'bad_link_detected':not (O/'nonexistent-synthetic-target.md').exists()}
assert all(synthetic.values())
results['negative_fixtures']=synthetic
results['git_diff_check']={'exit':subprocess.run(['git','diff','--check'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=os.environ).returncode}
results['timestamp']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(O/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps(results,ensure_ascii=False,indent=2))
