import pathlib,json,zipfile,re,subprocess,hashlib,os
os.umask(0o077)
R=pathlib.Path('/Volumes/DiskOther/Code/TrainLab');O=pathlib.Path(__file__).parent;E=R/'exec-plans/evidence/ADHOC-0029';z=zipfile.ZipFile(E/'history.zip');results=[]
def check(n,b,d=''):results.append({'check':n,'passed':bool(b),'detail':d})
s=json.loads((E/'review-snapshot-v3.json').read_text())
# Enumerate only public non-states Git paths; states examined only from the four-item allowlist.
raw=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','--','.',':(exclude)states'],cwd=R).decode().split('\0')
actual={('MEMORY.md' if p=='memory.md' else p) for p in raw if p and (R/p).is_file()};actual.update(p for p in s['files'] if p.startswith('states/'));actual.discard('exec-plans/evidence/ADHOC-0029/review-snapshot-v3.json')
check('public-snapshot-closed',actual==set(s['files']),{'extra':sorted(actual-set(s['files'])),'missing':sorted(set(s['files'])-actual),'actual':len(actual)})
fail=json.loads((E/'failure-index.json').read_text());count=0
for p,v in fail.items():
 lines=z.read(p).decode().splitlines();bad=[]
 for entry in v['entries']:
  count+=1
  if 'line' in entry:
   if lines[entry['line']-1]!=entry['text']:bad.append(entry['line'])
  elif entry['row'] not in lines:bad.append(entry['row'])
 check('failure-index-source:'+p,not bad,bad)
check('failure-index-total',True,count)
# Verify source-heading-to-task association without trusting declared specific anchors.
defs=json.loads((E/'definition-mapping.json').read_text());total=0
for item in defs:
 src=z.read(item['source']).decode().splitlines();dst=(R/item['destination']).read_text();current=dst.split('## 原任务定义与验收')[0];bad=[]
 for n,line in enumerate(src,1):
  if not line.startswith('#'):continue
  for a in item['task_associations']:
   ident=a['task_id']
   if not re.search(r'(?<![A-Za-z0-9-])'+re.escape(ident)+r'(?![A-Za-z0-9-])',line):continue
   row=next((l for l in current.splitlines() if l.startswith('| '+ident+' |')),'');total+=1
   if '(#原定义-l'+str(n)+')' not in row:bad.append([ident,n,line])
 check('source-heading-task:'+item['source'],not bad,bad)
check('source-heading-associations-total',True,total)
# Source-first M4 counterexamples executed entirely in memory.
p='exec-plans/completed/M4-source-root-0001-product-consolidation.md';text=(R/p).read_text();source=z.read('docs/'+p).decode().splitlines()
def m4valid(txt):
 for ident,start,end in [('M4-0001',34,45),('M4-0002',46,57),('M4-0003',58,69),('M4-0004',70,78)]:
  row=next((l for l in txt.splitlines() if l.startswith('| '+ident+' |')),'')
  if '(#原定义-l'+str(start)+')' not in row:return False
  for line in source[start-1:end]:
   if line and '> '+line not in txt:return False
 return True
check('m4-normal-exact-definition',m4valid(text))
mutations={'drop-legacy-binding-boundary':text.replace('> - 无法唯一绑定的 legacy FIT 只归档并登记缺口，禁止猜测。',''), 'wrong-task-anchor':text.replace('(#原定义-l46)','(#原定义-l58)'), 'omit-contract-sleep-ambiguity':text.replace('>   采用半开区间，nap/未结束/多主睡眠明确缺失或歧义，日报只评估不修改正式计划。',''), 'remove-entire-definition':text.split('## 原任务定义与验收')[0]}
for name,txt in mutations.items():check('negative:'+name,not m4valid(txt))
(O/'final-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)); print('CHECKS',len(results),'FAIL',sum(not x['passed'] for x in results));print(json.dumps([x for x in results if not x['passed']],ensure_ascii=False,indent=2))
