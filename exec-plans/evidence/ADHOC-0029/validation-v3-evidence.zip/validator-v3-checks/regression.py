import pathlib,json,re,zipfile,subprocess,os,difflib,hashlib
os.umask(0o077)
R=pathlib.Path('/Volumes/DiskOther/Code/TrainLab');O=pathlib.Path(__file__).parent;E=R/'exec-plans/evidence/ADHOC-0029';B=O.parent
z=zipfile.ZipFile(E/'history.zip');mapping=json.loads((E/'decomposition-mapping.json').read_text());results=[]
def check(n,b,d=''):results.append({'check':n,'passed':bool(b),'detail':d})
# Source-first independent worksheet discovery (headers identify work, not attempt or feature mapping tables).
count=0; summaries=[]
for p in z.namelist():
 if not any(x['source']==p for x in mapping):continue
 lines=z.read(p).decode().splitlines(); item=next(x for x in mapping if x['source']==p);alltasks=[t for g in item['groups']+item.get('excluded_groups',[]) for t in g['tasks']];seen=[]
 for i,l in enumerate(lines):
  if not re.match(r'^\|\s*(?:步骤|任务|Step)\s*\|',l):continue
  for j in range(i+2,len(lines)):
   if not lines[j].startswith('|'):break
   row=lines[j];seen.append(j+1); count+=1
   candidates=[t for t in alltasks if t.get('source_row')==row]
   check('worksheet:'+p+':'+str(j+1),len(candidates)==1,[t['id'] for t in candidates])
 summaries.append({'source':p,'source_work_rows':len(seen),'mapped_tasks_including_retired':len(alltasks),'headings':[l for l in lines if l.startswith('#')]})
check('source-worksheet-total',count>200,count)
# Dependencies and stable identifiers from original roadmap, not the migration mapping as truth.
old=z.read('PLANS.md').decode();plan=(R/'PLAN.md').read_text();leaves=[]
headers=[]
for line in old.splitlines():
 if line.startswith('| 任务 |'):headers=[c.strip() for c in line.split('|')[1:-1]]
 if not line.startswith('| ['):continue
 m=re.match(r'\| \[[^\]]*\] `([^`]+)` ([^|]+)\|',line)
 if not m:continue
 cells=line.split('|')[1:-1]; ident=m[1];dep=cells[headers.index('显式依赖')].strip();leaves.append(ident)
 matches=[l for l in plan.splitlines() if l.startswith('| '+ident+' |')]
 check('roadmap-leaf:'+ident,any(dep in row for row in matches),{'dependency':dep,'rows':len(matches)})
check('independent-roadmap-count',len(leaves)==66,len(leaves))
# Exact retained technical bytes except authorized obsolete navigation update.
for p in ['references/garmin-fit-parsing.md','references/longdou.md']:
 a=(B/'before-public'/p).read_text();b=(R/p).read_text();expected=a.replace('[rules.md](../rules.md)','[项目边界](../PLAN.md#项目已有边界与当前设计)')
 check('reference-technical-preservation:'+p,b==expected)
check('skills-real-directory',sorted(p.name for p in (R/'skills').iterdir())==['README.md'])
# Literal invented paths only; no list/read private states.
paths=['states/activities/.gitkeep','states/verification/.gitkeep','states/reports/.gitkeep','states/Goal-example.md','states/Goal.md','states/example.fit','states/data.db','states/private-report.md','states/verification/synthetic-token.json']
snap=json.loads((E/'review-snapshot-v3.json').read_text());public=[p for p in snap['files'] if p.startswith('states/')];paths=public+[p for p in paths[4:]]
proc=subprocess.run(['git','check-ignore','--no-index','--stdin'],cwd=R,input='\n'.join(paths)+'\n',text=True,capture_output=True)
ignored=proc.stdout.splitlines();check('ignore-public-four',len(public)==4 and not set(public)&set(ignored),{'public':public,'exit':proc.returncode})
check('ignore-private-synthetic',set(paths[4:])<=set(ignored),{'ignored':ignored,'exit':proc.returncode})
proc=subprocess.run(['git','diff','--check'],cwd=R,text=True,capture_output=True);check('git-diff-check',proc.returncode==0,{'exit':proc.returncode,'output':proc.stdout+proc.stderr})
# Newly untracked Markdown whitespace/fences/JSON snippets, independent of tracked diff.
for p in snap['files']:
 if not p.endswith('.md') or '/evidence/' in p:continue
 txt=(R/p).read_text();fence=None;buf=[];errors=[]
 for n,line in enumerate(txt.splitlines(),1):
  if line.startswith('>'):continue
  if re.match(r'^\s*```',line):
   if fence=='json':
    try:json.loads('\n'.join(buf))
    except ValueError:errors.append('bad JSON fence '+str(n))
   fence=None if fence else line.strip()[3:];buf=[];continue
  if fence is not None:buf.append(line)
  if line.rstrip()!=line:errors.append('trailing whitespace '+str(n))
 if fence is not None:errors.append('unclosed fence')
 check('markdown-syntax:'+p,not errors,errors)
# Preserve source-backed differences for full five-plan semantic review.
diffs=[]
for i in range(24,29):
 src=next(p for p in z.namelist() if '/active/ADHOC-00'+str(i)+'-' in p);dst=src.removeprefix('docs/');a=z.read(src).decode();b=(R/dst).read_text()
 diffs.append('\n'.join(difflib.unified_diff(a.splitlines(),b.splitlines(),fromfile=src,tofile=dst)))
(O/'five-plan-diff.md').write_text('\n\n'.join(diffs))
(O/'source-inventory.json').write_text(json.dumps(summaries,ensure_ascii=False,indent=2))
(O/'regression-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print('CHECKS',len(results),'FAIL',sum(not r['passed'] for r in results));print(json.dumps([r for r in results if not r['passed']],ensure_ascii=False,indent=2))
