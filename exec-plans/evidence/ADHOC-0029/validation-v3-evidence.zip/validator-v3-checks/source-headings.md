## docs/exec-plans/active/ADHOC-0018-data-fit-year-cleanup.md
Tasks: S1, S2, S3
1: # ADHOC-0018：data精简与FIT按运动年份命名
7: ## 冻结合同
31: ## 执行步骤
39: ## 检查点
59: ## 当前只读补证
71: ## 迭代日志

## docs/exec-plans/active/M12-fit-weekly-0001-rebuild.md
Tasks: 0001/0002及0003a-m, 0003n-1, 0003n-2, 0003n-3, 0004A, 0004B, 0004C, 0004D, 0005, 0006
1: # M12：新旧系统收敛与 FIT-only 每周系统
12: ## 当前完整冻结合同 VC-005
50: ## 工作分解
67: ## 当前保护与检查点
75: ## 历史失败与修订索引
80: ## 派发与迭代
97: ## 完成条件
99: ### 本批独立验证回写（2026-09-08）
115: ### 旧CLI退出实施边界（同一VC-005，基准25e8b92）

## docs/exec-plans/completed/ADHOC-0001-agentforge-0.4.2-upgrade.md
Tasks: L01, L02, L03, L04, L05, L06
1: # 执行计划：升级并严格适配 agentForge 0.4.2
12: ## 目标与验收标准
24: ## 范围与非目标
34: ## 适用规则与参考资料
41: ## 依赖与隔离
51: ## 功能与测试映射
55: ## 工具采用情况
67: ## Subagent 派发
75: ## 工作分解
86: ## 当前检查点
96: ## 决策与发现
113: ## 任务级独立验证
129: ## 集成级独立验证
134: ## PLANS 回写清单
141: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0002-repository-root-cleanup.md
Tasks: L01, L02, L03, L04, L05
1: # 执行计划：审计并精简 TrainLab 根目录生成物与辅助目录
12: ## 目标与验收标准
20: ## 范围与非目标
26: ## 适用规则与参考资料
31: ## 依赖与隔离
41: ## 功能与测试映射
45: ## 工具采用情况
51: ## Subagent 派发
58: ## 工作分解
68: ## 当前检查点
78: ## 决策与发现
93: ## 任务级独立验证
103: ## 集成级独立验证
108: ## PLANS 回写清单
115: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0003-generated-and-crash-artifact-cleanup.md
Tasks: L01, L02, L03, L04
1: # 执行计划：删除根目录无用生成物和崩溃文件
12: ## 目标与验收标准
19: ## 范围与非目标
24: ## 适用规则与参考资料
29: ## 依赖与隔离
36: ## 功能与测试映射
40: ## 工具采用情况
45: ## Subagent 派发
51: ## 工作分解
60: ## 当前检查点
70: ## 决策与发现
77: ## 任务级独立验证
87: ## 集成级独立验证
92: ## PLANS 回写清单
99: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0004-support-directory-classification.md
Tasks: L01, L02, L03, L04, L05
1: # 执行计划：厘清辅助目录职责并迁移第三方许可声明
12: ## 目标与验收标准
20: ## 范围与非目标
26: ## 适用规则与参考资料
31: ## 依赖与隔离
38: ## 功能与测试映射
44: ## 工具采用情况
49: ## Subagent 派发
55: ## 工作分解
65: ## 当前检查点
75: ## 决策与发现
83: ## 任务级独立验证
93: ## 集成级独立验证
98: ## PLANS 回写清单
105: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0005-authentication-health-check.md
Tasks: L01, L02, L03, L04
1: # 执行计划：Gmail 与 Garmin 认证健康检查
12: ## 目标与验收标准
19: ## 范围与非目标
25: ## 适用规则与参考资料
31: ## 依赖与隔离
38: ## 功能与测试映射
42: ## 工具采用情况
48: ## Subagent 派发
52: ## 工作分解
61: ## 当前检查点
71: ## 决策与发现
80: ## 任务级独立验证
84: ## 集成级独立验证
88: ## PLANS 回写清单
92: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0006-garmin-token-sync.md
Tasks: L01, L02, L03, L04
1: # 执行计划：同步已验证的 Garmin token
12: ## 目标与验收标准
19: ## 范围与非目标
25: ## 适用规则与参考资料
30: ## 依赖与隔离
37: ## 功能与测试映射
41: ## 工具采用情况
46: ## Subagent 派发
50: ## 工作分解
59: ## 当前检查点
69: ## 决策与发现
76: ## 任务级独立验证
80: ## 集成级独立验证
84: ## PLANS 回写清单
88: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0007-production-backfill-and-monitor.md
Tasks: L01, L02, L03, L04, L05, L06, L07
1: # 执行计划：增量更新、补发日报周计划并监测 12 小时
12: ## 目标与验收标准
21: ## 范围与非目标
27: ## 适用规则与参考资料
35: ## 依赖与隔离
42: ## 功能与测试映射
51: ## 工具采用情况
58: ## Subagent 派发
62: ## 工作分解
74: ## 当前检查点
86: ## 12 小时监测记录
94: ## 决策与发现
118: ## 任务级独立验证
123: ## 集成级独立验证
127: ## PLANS 回写清单
131: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0008-runtime-bundle-and-repository-simplification.md
Tasks: L01, L02, L03, L04, L05, L06
1: # 执行计划：简化 TrainLab 仓库并形成单一可部署产物
12: ## 目标与验收标准
23: ## 范围与非目标
31: ## 适用规则与参考资料
38: ## 依赖与隔离
48: ## 功能与测试映射
56: ## 工具采用情况
62: ## Subagent 派发
79: ## 工作分解
90: ## 当前检查点
100: ## 决策与发现
109: ## 任务级独立验证
118: ## 集成级独立验证
122: ## PLANS 回写清单
129: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0009-source-data-provenance-audit.md
Tasks: L01, L02, L03, L04, L05, L06
1: # 执行计划：source 开发、数据与数据库来源审计
12: ## 目标与验收标准
20: ## 范围与非目标
27: ## 适用规则与参考资料
33: ## 依赖与隔离
44: ## 功能与测试映射
48: ## 工具采用情况
54: ## Subagent 派发
62: ## 工作分解
73: ## 当前检查点
83: ## 决策与发现
112: ## 任务级独立验证
119: ## 集成级独立验证
123: ## PLANS 回写清单
130: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0010-raw-directory-taxonomy-audit.md
Tasks: L01, L02, L03, L04, L05
1: # 执行计划：raw 目录分层与用途审计
12: ## 目标与验收标准
18: ## 范围与非目标
24: ## 适用规则与参考资料
30: ## 依赖与隔离
37: ## Subagent 派发
45: ## 工作分解
55: ## 当前检查点
62: ## 决策与发现
83: ## 独立验证
87: ## PLANS 回写清单
93: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0011-state-raw-retention-and-tuning.md
Tasks: ADHOC-0011-0001, ADHOC-0011-0002, ADHOC-0011-0003, ADHOC-0011-0004, CLOSE-01, CLOSE-02, CLOSE-03, CLOSE-04
1: # 需求草案：source 运行结构、Skills 与 state 数据整理
12: ## 文档用途
18: ## 当前执行检查点
58: ## 已确认需求
60: ### R-001：按数据来源保留 Provider 层
77: ### R-002：移除非 Provider 命名空间
87: ### R-003：把运动活动文件与天气平铺归为一组
117: ### R-004：把健康 raw 平铺到独立目录
138: ### R-005：Activity Inventory 只作为数据库控制状态
148: ### R-006：取消 Activity Summary 依赖
156: ### R-007：每日一次、无历史回读的同步窗口
172: ### R-008：重置现有非 raw state
189: ### R-009：运行时改为完全由 AI 与本地 Skills 驱动
202: ### R-010：最小 source 顶层结构
227: ### R-011：goal 与 state 的 Git 表达
246: ### R-012：六个初始本地 Skills
312: ### R-013：Skill 采用脚本优先
330: ### R-014：source 运行 AGENTS
340: ### R-015：两套日报与周计划邮件模板
358: ### R-020：两套报告展示路径与可选 Sites 快照
376: ### R-016：无状态定时运行原则
388: ### R-017：两个 cron Prompt
433: ### R-018：管理 Garmin My Workouts 中的 GTS 模板
446: ### R-019：SQLite 保存所有项目输出与状态
476: ## 技术合同 1：SQLite 六表 Schema v1（初始设计记录；后续已实施）
482: ### 全局规则
496: ### 1. `skill_runs`：每次 Skill 的运行状态
528: ### 2. `activity_inventory`：活动发现与文件采集控制状态
558: ### 3. `raw_files`：原始文件索引与不可变修订
596: ### 4. `skill_outputs`：不可覆盖的 Skill 输出
626: ### 5. `approvals`：人工批准与定时 AI 授权链
652: ### 6. `external_actions`：Gmail、Garmin 与 Sites 外部动作
698: ### 六表的写入与保留规则
710: ## 技术合同 2：SQLite 备份、恢复与保留 v1（初始设计记录；后续已实施）
716: ### 备份位置与格式
744: ### 建立备份
755: ### 备份触发点
771: ### 恢复流程
796: ### 保留规则
811: ### 必须验证的故障场景
822: ## 技术合同 3：六个运行 Skills 输入、输出、失败与幂等 v1（已实施并通过独立验证）
828: ### 公共调用信封
861: ### 公共状态与失败规则
874: ### 稳定失败码白名单
904: ### 1. `garmin-sync`
932: ### 2. `training-coach`
957: ### 3. `weekly-fitness-summary`
972: ### 4. `garmin-training-sender`
993: ### 5. `training-report-publisher`
1018: ### 6. `gmail-sender`
1035: ### 每日与每周串行关系
1058: ## 目标结构草图
1107: ## 数据保护要求
1117: ## 已执行与最终结果
1128: ### 旧运行层退役清单（切换后执行）
1145: ## 依赖与隔离
1154: ## 当前只读审计
1180: ## 当前检查点
1195: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0012-current-runtime-tech-debt-audit.md
Tasks: 1., 2., 3., 4.
1: # 执行计划：当前运行架构完成度与技术债审计
12: ## 目标与验收标准
19: ## 范围与非目标
24: ## 适用规则与参考资料
29: ## 依赖与隔离
39: ## 功能与测试映射
43: ## 工具采用情况
49: ## Subagent 派发
57: ## 工作分解
66: ## 当前检查点
76: ## 决策与发现
78: ### 客观完成度
92: ### 启用前阻塞项
112: ### 技术债候选
133: ## 任务级独立验证
144: ## 集成级独立验证
148: ## PLANS 回写清单
155: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0013-mcp-and-runtime-adapter-audit.md
Tasks: 1., 2., 3., 4.
1: # 执行计划：Garmin/Gmail MCP 与运行适配状态核对
12: ## 目标与验收标准
19: ## 范围与非目标
24: ## 适用规则与参考资料
29: ## 依赖与隔离
36: ## 功能与测试映射
40: ## 工具采用情况
45: ## Subagent 派发
51: ## 工作分解
60: ## 当前检查点
70: ## 决策与发现
84: ## 任务级独立验证
92: ## 集成级独立验证
96: ## PLANS 回写清单
103: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0014-m9-local-delivery.md
Tasks: L01, L02, L03, L04, L05, L06
1: # 执行计划：M9 本地完整交付
12: ## 目标与验收标准
18: ## 范围与非目标
24: ## 适用规则与参考资料
29: ## 依赖与隔离
39: ## 功能与测试映射
43: ## 工具采用情况
49: ## Subagent 派发
55: ## 工作分解
66: ## 当前检查点
76: ## 决策与发现
82: ## 任务级独立验证
91: ## 集成级独立验证
101: ## PLANS 回写清单
108: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0015-agentforge-0.4.4-upgrade.md
Tasks: L01, L02, L03, L04, L05, L06
1: # 执行计划：升级 agentForge v0.4.4 并迁移 M11 诊断状态
12: ## 目标与验收标准
19: ## 范围与非目标
27: ## 适用规则与参考资料
35: ## 冻结验证合同
43: ### 验收标准
54: ### 行为不变量
63: ### 威胁模型
72: ### 明确排除项
80: ### Lint/Test 与静态门禁
92: ### 合同修订记录
98: ## 依赖与隔离
108: ## 功能与测试映射
112: ## 工具采用情况
118: ## Subagent 派发
124: ## 工作分解
135: ## 当前检查点
147: ## Validator 结论处理
153: ## 失败尝试与诊断
160: ## 决策与发现
167: ### v0.4.2 → v0.4.4 差异映射
181: ## Validator 固定输出
187: ## 任务级独立验证
200: ## 集成级独立验证
204: ## PLANS 回写清单
208: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0016-agentforge-governance-update.md
Tasks: L01, L02, L03, L04, POST-GIT-01
1: # 执行计划：适配 agentForge 最新开发脚手架
12: ## 冻结验证合同
50: ## 工作分解
61: ## 当前检查点
70: ## 上游差异映射
85: ## 验证与结论处理
92: ### 最终独立验证
104: ### 主协调 Agent 实测记录（不作为 Validator 结论输入）
110: ### 首轮独立报告与同合同修正
122: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0017-consolidate-pre-api-baseline.md
Tasks: D-01, D-02, D-03, C-01, C-02, C-03, C-06, C-06V1, C-06R1, C-06R1V, C-07, C-07V, C-08, C-08V, C-09, C-10, C-11, C-12, C-04, C-13, C-14, C-05
1: # CONSOLIDATE-20260914：单目录整合与 API 改造前旧版基线
9: ## 当前收尾合同 VC-002
30: ### 本次执行步骤（唯一现行状态）
38: ### 2026-09-14 本次边界与恢复偏差
45: ### D-01 实际结果与D-02派发
54: ### D-02/D-03 最终交付事实（2026-09-14）
64: ## 历史：VC-001 已确认目标与边界（已被收窄，非本轮指令）
74: ## 历史冻结合同 VC-001（superseded，以下原文不改写）
115: ## 历史工作分解（停止驱动本轮；以D-01–03为准）
139: ## 当前检查点与证据
154: ## Agent 派发记录
164: ## C-06 实际结果与待复核缺口
184: ## Main 审核决策与分步边界
194: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0019-adopt-next-before-api.md
Tasks: S1a, S1b, S2, S3
1: # ADHOC-0019：Goal保留、主目录检查点及采用next代码
9: ## 当前合同 VC-002：仅保存重构前快照
32: ## 历史合同 VC-001（已由VC-002替代，原文字节保留）
60: ## 步骤与写入职责
69: ## 当前检查点
79: ## 历史检查点与证据
95: ### 2026-09-15中断恢复与偏差
109: ### 恢复诊断结果与人工决定
127: ## 派发记录
133: ## 迭代记录

## docs/exec-plans/completed/ADHOC-0020-states-activities-decisions.md
Tasks: S1, S2, S3
1: # ADHOC-0020：记录 states / activities 数据目录决策
7: ## 当前冻结合同
30: ### 版本替代记录
34: ## 历史合同 VC-001（superseded，原文保留）
55: ## 步骤与检查点
68: ## 当前检查与受审材料
80: ## 独立验证与主协调收口
95: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0021-garmin-fit-reference.md
Tasks: L01, L02, L03
1: # 执行计划：Garmin FIT 官方解析资料整理
11: ## 冻结验证合同
39: ## 工作分解
47: ## 当前检查点
60: ## 验证设计与派发
72: ## 独立验证结果与主协调处理
92: ## 迭代日志

## docs/exec-plans/completed/ADHOC-0022-longdou-real-fit-reference.md
Tasks: L01, L02, L03, L04
1: # 执行计划：龙豆传感器资料与真实跑步 FIT 对照
10: ## 冻结验证合同
39: ## 步骤
48: ## 检查点与证据
67: ## 验证边界
79: ## 独立验证与完成回写
91: ## 迭代日志

## docs/exec-plans/completed/M1-agentforge-migration-0001-development-harness.md
Tasks: L01, L02, L03, L04, L05
1: # Execution plan: install the agentForge development Harness
10: ## Goal and acceptance
16: ## Scope and exclusions
21: ## Work
31: ## Current checkpoint
40: ## Independent validation
46: ## Iteration log

## docs/exec-plans/completed/M1-product-root-0002-source-migration.md
Tasks: L01, L02, L03, L04, L05
1: # Execution plan: move the sole TrainLab product source into product/
10: ## Goal and acceptance
17: ## Scope and exclusions
23: ## Work
33: ## Current checkpoint
42: ## Independent validation
48: ## Iteration log

## docs/exec-plans/completed/M1-runtime-root-0003-data-switch.md
Tasks: L01, L02, L03, L04, L05
1: # Execution plan: move local runtime data and switch product root
10: ## Goal and acceptance
16: ## Scope and exclusions
22: ## Work
32: ## Current checkpoint
41: ## Independent validation
47: ## Iteration log

## docs/exec-plans/completed/M10-live-e2e-0001-rolling-week.md
Tasks: M10-0001, M10-0002, M10-0003, M10-0004, M10-0005
1: # 执行计划：M10 滚动七日真实端到端验收
12: ## 目标与验收标准
19: ## 范围与非目标
35: ## 冻结预算
54: ## 适用规则与参考资料
63: ## 依赖与隔离
77: ## 功能与测试映射
87: ## 工具采用情况
94: ## Subagent 派发
135: ## 工作分解
145: ## 当前检查点
155: ## 决策与发现
161: ## 任务级独立验证
170: ## 集成级独立验证
175: ## PLANS 回写清单
182: ## 迭代日志

## docs/exec-plans/completed/M11-email-presentation-0001-readable-cid-r01.md
Tasks: M11-0015-01, M11-0015-02, M11-0015-03, M11-0015-04, M11-0015-05
1: # 执行计划：M11 v3 八封 Gmail 真实投递
12: ## 目标与验收标准
22: ## 范围与非目标
32: ## 适用规则与参考资料
38: ## 依赖与隔离
51: ## 功能与测试映射
59: ## 工具采用情况
67: ## Subagent 派发
74: ## 工作分解
84: ## 当前检查点
94: ## 决策与发现
99: ## 任务级独立验证
108: ## 集成级独立验证
118: ## PLANS 回写清单
125: ## 迭代日志

## docs/exec-plans/completed/M11-email-presentation-0001-readable-cid-r02.md
Tasks: M11-0016-01, M11-0016-02, M11-0017-01, M11-0017-02, M11-0018-01, M11-0018-02, M11-0017-03, M11-0017-04, M11-0017-05, M11-0017-06, M11-0017-07, M11-0017-08, M11-0017-09, M11-0017-10, M11-0018-03, M11-0018-04, M11-0018-05, M11-0018-06, M11-0019-01, M11-0019-02
1: # 执行计划：M11 v4 内容优先日报、技术周报与固定周计划
12: ## M12 替代记录
18: ## 目标与验收标准
29: ## 范围与非目标
36: ## 适用规则与参考资料
42: ## 冻结验证合同
54: ### 验收标准
74: ### 行为不变量
86: ### 威胁模型
100: ### 明确排除项
109: ### Lint/Test 与静态门禁
119: ### 合同修订记录
134: ### VC-002 健康状态矩阵
151: ### VC-003 结构化训练目标合同
174: ### VC-004 有限输入矩阵
212: ### VC-005 机器词法与基线
240: ### VC-006 目标模板、有限词法与故障门
283: ### VC-007 模型输入双视图合同
315: ### VC-008 结构化斜杠例外
333: ### VC-009 仓库外模型工作目录命令合同
346: ### VC-010 Prompt、Schema 与业务校验同构合同
374: ## 依赖与隔离
385: ## 功能与测试映射
396: ## 工具采用情况
403: ## Subagent 派发
444: ## 工作分解
469: ## 当前检查点
481: ## 决策与发现
489: ## Validator 结论处理
498: ## 失败尝试与诊断
510: ### Failure Analyst 固定输出
517: ## Validator 固定输出
524: ## 任务级独立验证
530: ## 集成级独立验证
535: ## PLANS 回写清单
542: ## 迭代日志

## docs/exec-plans/completed/M11-email-presentation-0001-readable-cid.md
Tasks: M11-0001, M11-0002, M11-0003, M11-0004, M11-0005, L06, M11-0006, M11-0007, M11-0008, M11-0009, M11-0010, M11-0011, M11-0012, M11-0013, M11-0014
1: # 执行计划：人类可读日报/周报与私有 CID 图表闭环
15: ## 目标与验收标准
33: ## 范围与非目标
42: ## 适用规则与参考资料
55: ## 依赖与隔离
71: ## 功能与测试映射
85: ## 工具采用情况
93: ## Subagent 派发
179: ## 工作分解
199: ## 当前检查点
211: ## 决策与发现
219: ## 任务级独立验证
228: ## 集成级独立验证
238: ## PLANS 回写清单
247: ## 迭代日志

## docs/exec-plans/completed/M2-agentforge-root-layout-0001-project-migration.md
Tasks: L01, L02, L03, L04, L05, L06, L07, L08
1: # 执行计划：将 TrainLab 完整迁移到 agentForge 0.4.2 根项目布局
13: ## 目标与验收标准
30: ## 范围与非目标
39: ## 适用规则与参考资料
47: ## 依赖与隔离
58: ## 功能与测试映射
69: ## 工具采用情况
75: ## Subagent 派发
82: ## 工作分解
95: ## 当前检查点
105: ## 决策与发现
122: ## 任务级独立验证
134: ## 集成级独立验证
139: ## PLANS 回写清单
146: ## 迭代日志

## docs/exec-plans/completed/M3-test-fixtures-0001-synthetic-fit-migration.md
Tasks: L01, L02, L03, L04, L05, L06, L07
1: # 执行计划：用合成 FIT 夹具替代私人 test_data
12: ## 目标与验收标准
22: ## 范围与非目标
28: ## 适用规则与参考资料
33: ## 依赖与隔离
40: ## 功能与测试映射
48: ## 工具采用情况
54: ## Subagent 派发
62: ## 工作分解
74: ## 当前检查点
84: ## 决策与发现
97: ## 任务级独立验证
106: ## 集成级独立验证
111: ## PLANS 回写清单
118: ## 迭代日志

## docs/exec-plans/completed/M4-source-root-0001-product-consolidation.md
Tasks: M4-0001, M4-0002, M4-0003, M4-0004
1: # 执行计划：M4 `source/` 工程、健康数据重建与教练 Harness v2
10: ## 目标
19: ## 硬边界
32: ## 串行任务与验收
34: ### M4-0001：工程布局与历史运行层清理
46: ### M4-0002：Foundation v4 离线 Garmin 重建
58: ### M4-0003：运行时教练 Harness v2
70: ### M4-0004：原子切换与独立验证
79: ## 当前状态
88: ## 变更范围
94: ## 独立验证
99: ## 迭代日志

## docs/exec-plans/completed/M5-adaptive-coaching-0001-profile-and-preview.md
Tasks: M5-0001, M5-0002, M5-0003, M5-0004, L05
1: # 执行计划：M5 自适应教练画像与本地报告校准
12: ## 目标与验收标准
23: ## 范围与非目标
40: ## 适用规则与参考资料
50: ## 依赖与隔离
64: ## 功能与测试映射
72: ## 工具采用情况
80: ## Subagent 派发
86: ## 工作分解
96: ## 当前检查点
106: ## 决策与发现
113: ## 任务级独立验证
122: ## 集成级独立验证
132: ## PLANS 回写清单
139: ## 迭代日志

## docs/exec-plans/completed/M6-activity-evidence-0001-lifecycle-and-preview.md
Tasks: M6-0001, M6-0002, M6-0003, M6-0004
1: # 执行计划：M6 活动证据一致性与真实报告预览（已被 ADHOC-0011 取代）
12: ## 目标与验收标准
18: ## 范围与非目标
24: ## 适用规则与参考资料
30: ## 依赖与隔离
39: ## 功能与测试映射
47: ## 工具采用情况
53: ## 工作分解
62: ## 当前检查点
72: ## 决策与发现
78: ## 任务级独立验证
86: ## 集成级独立验证
92: ## PLANS 回写清单
99: ## 迭代日志

## docs/exec-plans/completed/M7-ai-skills-0001-runtime-closure.md
Tasks: M7-0001, M7-0002, M7-0003, M7-0004, M7-0005
1: # 执行计划：M7 AI + Skills 执行闭环与双层测试体系
12: ## 目标与验收标准
27: ## 范围与非目标
36: ## 适用规则与参考资料
42: ## 依赖与隔离
54: ## 功能与测试映射
64: ## 工具采用情况
73: ## Subagent 派发
79: ## 工作分解
89: ## 当前检查点
99: ## 决策与发现
108: ## 任务级独立验证
117: ## 集成级独立验证
127: ## PLANS 回写清单
134: ## 迭代日志

## docs/exec-plans/completed/M8-real-data-0001-ai-coach-closure.md
Tasks: M8-0001, M8-0002, M8-0003, M8-0004, M8-0005
1: # 执行计划：M8 真实私人数据离线 AI 教练闭环
12: ## 目标与验收标准
22: ## 范围与非目标
28: ## 适用规则与参考资料
33: ## 依赖与隔离
41: ## 功能与测试映射
50: ## 工具采用情况
56: ## 工作分解
66: ## 当前检查点
75: ## 设计合同
84: ## 任务级独立验证
90: ## 集成级独立验证
96: ## PLANS 回写清单
103: ## 迭代日志

## docs/exec-plans/completed/M9-garmin-live-0001-bounded-daily-sync.md
Tasks: M9-0001, M9-0002, M9-0003, M9-0004, M9-0005
1: # 执行计划：M9 单日 Garmin MCP 有界真实只读闭环
12: ## 目标与验收标准
22: ## 范围与非目标
32: ## 适用规则与参考资料
39: ## 依赖与隔离
53: ## 冻结预算
69: ## r04 AI 阻塞恢复批次
87: ## r05 Structured Outputs Schema 修正批次
113: ## r06 threat-model closure batch
135: ## r07 Structured Outputs v2 与 attempt 4 批次
156: ## 功能与测试映射
166: ## 工具采用情况
173: ## Subagent 派发
217: ## 工作分解
227: ## 当前检查点
237: ## 决策与发现
243: ## 任务级独立验证
253: ## 集成级独立验证
263: ## PLANS 回写清单
270: ## 迭代日志
