import pathlib,json,hashlib,subprocess,zipfile,re,sys,os,difflib
R=pathlib.Path('/Volumes/DiskOther/Code/TrainLab'); E=R/'exec-plans/evidence/ADHOC-0029'; O=pathlib.Path(__file__).parent; B=O.parent
os.umask(0o077)
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
results=[]
def check(name,ok,detail=''):
 results.append({'check':name,'passed':bool(ok),'detail':detail})
def frozen(label):
 s=load(E/'review-snapshot-v3.json');bad=[]
 for p,v in s['files'].items():
  q=R/p
  if not q.is_file() or sha(q.read_bytes())!=v['sha256'] or oct(q.stat().st_mode)!=v['mode'] or q.stat().st_size!=v['bytes']:bad.append(p)
 absent=sorted(p for p in git('ls-files','-z').decode().split('\0') if p and not (R/p).exists())
 check(label,not bad and absent==s['tracked_absent'] and git('rev-parse','HEAD').decode().strip()==s['head'] and git('branch','--show-current').decode().strip()==s['branch'] and sha(git('ls-files','--stage','-z'))==s['index_entries_sha256'],{'bad_files':bad,'files':len(s['files']),'absent':len(absent),'index':sha(git('ls-files','--stage','-z'))})
 check(label+'-snapshot',sha((E/'review-snapshot-v3.json').read_bytes())=='33081f66b3fd604f19dab07b11fb99408c074b12749a78eb0d07cd9ddb79b68f')
 check(label+'-contract',sha((B/'contract-vc001.md').read_bytes())==s['contract_sha256'])
 return s
s=frozen('freeze-start')
if not all(v['passed'] for v in results):
 (O/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));sys.exit(2)
if '--freeze-only' in sys.argv:
 (O/'freeze-end.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)); print('final freeze checks',results);sys.exit(0)
up=load(E/'upstream-files.json');tree=load(B/'upstream-tree.json'); blobs={v['path']:v['sha'] for v in tree['tree'] if v['type']=='blob'}
for p,v in up.items():
 b=(B/'upstream'/p).read_bytes();blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 check('upstream-cache:'+p,sha(b)==v['sha256'] and blob==v['git_blob']==blobs[p])
for p in ['AGENTS.md','README.md','exec-plans/template.md','subagent-templates/developer.md','subagent-templates/planner.md','subagent-templates/validator.md']:
 check('upstream-exact:'+p,(R/p).read_bytes()==(B/'upstream'/p).read_bytes())
for p in ['references/README.md','skills/README.md']:check('upstream-base:'+p,(R/p).read_bytes().startswith((B/'upstream'/p).read_bytes()))
z=zipfile.ZipFile(E/'history.zip');hist=load(E/'history-manifest.json'); before=load(B/'before-public.json');migration=load(E/'migration-manifest.json');defs=load(E/'definition-mapping.json');decomp=load(E/'decomposition-mapping.json')
check('history-members',set(z.namelist())==set(hist),len(hist))
for p,v in hist.items():check('history:'+p,sha(z.read(p))==v['sha256']==before[p]['sha256'] and len(z.read(p))==v['bytes'])
check('migration-44',len(migration)==44 and len({v['source'] for v in migration})==44 and all((R/v['destination']).is_file() for v in migration))
check('decomposition-definition-38',len(defs)==len(decomp)==38 and {v['source'] for v in defs}=={v['source'] for v in decomp})
def display(line):
 return re.sub(r'\[([^\]]+)\]\(([^)]+)\)',lambda m:m[1]+'（原定位：'+m[2]+'）',line)
manual=[];task_total=0;chunk_total=0
for d in defs:
 src=z.read(d['source']).decode().splitlines(); dst=(R/d['destination']).read_text(); groups=next(v for v in decomp if v['source']==d['source']); tasks=[t for g in groups['groups']+groups.get('excluded_groups',[]) for t in g['tasks']]; task_total+=len(tasks)
 check('definition-hash:'+d['source'],sha(z.read(d['source']))==d['source_sha256'])
 ranges=[n for c in d['chunks'] for n in range(c['start_line'],c['end_line']+1)];check('definition-lines:'+d['source'],ranges==list(range(1,len(src)+1)))
 bad=[]
 for c in d['chunks']:
  chunk_total+=1; start=c['start_line']; end=c['end_line'];match=re.search(r'^### 原定义-L'+str(start)+r'\n.*?\n\n(.*?)(?=\n### |\n## |\Z)',dst,re.M|re.S)
  actual=[] if not match else [l[2:] if l.startswith('> ') else '' for l in match[1].splitlines() if l.startswith('>')]
  expected=[display(l) for l in src[start-1:end]]
  # source heading and line quotes must be complete, only navigation display changes allowed
  if actual!=expected:bad.append({'line':start,'diff':list(difflib.unified_diff(expected,actual))[:14]})
 check('definition-projection:'+d['source'],not bad,bad)
 current=dst.split('## 原任务定义与验收')[0]; assoc=[]
 for a in d['task_associations']:
  row=next((l for l in current.splitlines() if l.startswith('| '+a['task_id']+' |')),None)
  if not row or '(#'+a['shared_anchor']+')' not in row or any('(#'+anchor+')' not in row for anchor in a['specific_anchors']):assoc.append(a['task_id'])
 check('task-links:'+d['source'],not assoc,assoc)
 check('task-count:'+d['source'],len(tasks)==len(d['task_associations']))
 badrows=[]
 for t in tasks:
  if t.get('source_row'):
   source_lines=z.read(t.get('source_file',d['source'])).decode().splitlines()
   start=t['line']-1; actual=source_lines[start]
   if not t['source_row'].startswith('|'):
    end=start+1
    while end<len(source_lines) and source_lines[end].startswith('  '):end+=1
    actual=' '.join(l.strip() for l in source_lines[start:end]).removeprefix('- ')
   if actual!=t['source_row']:badrows.append(t['id'])
 check('source-task-rows:'+d['source'],not badrows,badrows)
 manual.append('## '+d['source']+'\nTasks: '+', '.join(t['id'] for t in tasks)+'\n'+'\n'.join(str(i)+': '+l for i,l in enumerate(src,1) if l.startswith('#'))+'\n')
check('projection-summary',True,{'tasks':task_total,'chunks':chunk_total})
(O/'source-headings.md').write_text('\n'.join(manual))
required=['## 对应目标','## 阶段与任务','## 当前检查点','## 问题记录','- 功能编号：','- 功能状态：','- 总计划对应条目：','- 目标及范围和验收要求的引用：','- 工作目录与分支：','- 验收要求与受验版本及未提交改动：','- 最近完成：','- 下一动作：','- 暂停原因：','- 恢复条件：','- PR 与交付情况：']
for m in migration:
 text=(R/m['destination']).read_text();current='\n'.join(l for l in text.splitlines() if not l.startswith('>'))
 check('plan-format:'+m['destination'],all(h in current for h in required) and '- 功能状态：'+m['status'] in current)
 rows=text.split('## 阶段与任务')[1].split('## 当前检查点')[0].splitlines();bad=[]
 for l in rows:
  if l.startswith('|') and not l.startswith('| ---'):
   cells=re.split(r'(?<!\\)\|',l)[1:-1]
   if len(cells) not in (4,7):bad.append(l)
   elif cells[0].strip() not in ['阶段编号','任务编号'] and cells[1 if len(cells)==4 else 2].strip() not in ['[plan]','[exec]','[completed]']:bad.append(l)
 check('plan-tables-status:'+m['destination'],not bad,bad)
plan=(R/'PLAN.md').read_text();road=load(E/'roadmap-mapping.json');oldplan=z.read('PLANS.md').decode()
check('roadmap-66',len(road)==66 and all(v['id'] in oldplan and v['id'] in plan and v['dependency'] in plan and v['result'] in plan for v in road))
for p in ['.gitignore','.github/workflows/ci.yml',*[p for p in before if p.startswith('states/')]]:
 check('protected:'+p,(R/p).is_file() and sha((R/p).read_bytes())==before[p]['sha256'])
base=load(B/'preflight-git-baseline.json'); restored=[p for p,v in base.items() if v['state']=='missing' and p!='README.md' and (R/p).exists()];check('confirmed-deletions',not restored,{'missing_baseline':sum(v['state']=='missing' for v in base.values()),'restored':restored})
check('no-staged',not git('diff','--cached','--name-only'))
check('old-entries-absent',all(not (R/p).exists() for p in ['docs','source','PLANS.md','rules.md','CLAUDE.md']))
rootnames=os.listdir(R);check('memory-real-case','MEMORY.md' in rootnames and 'memory.md' not in rootnames)
# content-based link checks; never traverse states beyond public snapshot allowlist
badlinks=[];count=0
blocked=re.compile(r'(?:validation-v[12]|parent-.*-evidence|checks-|decomposition-regression)')
for p in s['files']:
 if not p.endswith('.md') or blocked.search(p):continue
 text=(R/p).read_text();in_fence=False
 for n,l in enumerate(text.splitlines(),1):
  if l.startswith('>'):continue
  if re.match(r'^\s*(```|~~~)',l):in_fence=not in_fence;continue
  if in_fence:continue
  for dest in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',l):
   if '://' in dest or dest.startswith('mailto:'):continue
   count+=1;path,_,frag=dest.partition('#');target=(R/p).parent/path if path else R/p
   if not target.exists():badlinks.append([p,n,dest,'missing'])
   elif frag and target.is_file() and target.suffix=='.md':
    text2=target.read_text();anchors=[]
    for h in re.findall(r'^#{1,6} (.+)$',text2,re.M):
     h=h.strip().lower();h=re.sub(r'[^\w\-\s]','',h);anchors.append(h.replace(' ','-'))
    if frag not in anchors:badlinks.append([p,n,dest,'anchor'])
check('markdown-local-links',not badlinks,{'count':count,'bad':badlinks})
for p in s['files']:
 if p.endswith('.json') and not blocked.search(p):
  try:load(R/p);ok=True
  except ValueError:ok=False
  check('json:'+p,ok)
# Synthetic mutations test independent predicates, not old scripts or repository writes.
check('negative-invalid-state', '[done]' not in ['[plan]','[exec]','[completed]'])
check('negative-bad-hash',sha(b'altered')!=sha(b'original'))
check('negative-missing-file',not (O/'not-present.md').exists())
check('negative-projection-omission',[display(l) for l in ['input','error boundary']]!=[display('input')])
check('negative-task-wrong-anchor','(#原定义-l46)' not in '| M4-0002 | (#原定义-l58) |')
(O/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print('CHECKS',len(results),'FAIL',sum(not x['passed'] for x in results));print(json.dumps([v for v in results if not v['passed']],ensure_ascii=False,indent=2))
