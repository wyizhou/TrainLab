import pathlib as P, json, hashlib as H, subprocess as S, zipfile, re, os, sys, html, difflib
R=P.Path('/Volumes/DiskOther/Code/TrainLab'); B=P.Path('/private/var/tmp/trainlab-agentsmd-upgrade-tciokw12'); O=B/'validator-v2-checks'; E=R/'exec-plans/evidence/ADHOC-0029'
def sha(b):return H.sha256(b).hexdigest()
def git(*a):return S.check_output(['git',*a],cwd=R)
def emit(n,d):
 p=O/n;p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');p.chmod(0o600)
s=json.loads((E/'review-snapshot-v2.json').read_text()); errors=[]
for p,v in s['files'].items():
 q=R/p
 if not q.is_file():errors.append([p,'missing']);continue
 a={'sha256':sha(q.read_bytes()),'bytes':q.stat().st_size,'mode':oct(q.stat().st_mode)}
 if a!=v:errors.append([p,a,v])
missing=sorted(p for p in git('ls-files','-z').decode().split('\0') if p and not (R/p).exists())
for k,a,b in [('missing',missing,sorted(s['tracked_absent'])),('head',git('rev-parse','HEAD').decode().strip(),s['head']),('branch',git('branch','--show-current').decode().strip(),s['branch']),('index',sha(git('ls-files','--stage','-z')),s['index_entries_sha256']),('snapshot',sha((E/'review-snapshot-v2.json').read_bytes()),'8fc8b677bb1c95193ccd5b70c0195f638dcc57ad892923cb36db03de2124e9fa'),('contract',sha((B/'contract-vc001.md').read_bytes()),s['contract_sha256'])]:
 if a!=b:errors.append([k,a,b])
emit('freeze-'+sys.argv[1]+'.json',{'errors':errors,'files':len(s['files']),'missing':len(missing),'index':sha(git('ls-files','--stage','-z')),'staged':git('diff','--cached','--name-only').decode(),'memory_names':[p.name for p in R.iterdir() if p.name.lower()=='memory.md']})
if errors:sys.exit(1)
if sys.argv[1]!='start':sys.exit(0)
base=json.loads((B/'before-public.json').read_text()); pre=json.loads((B/'preflight-git-baseline.json').read_text()); z=zipfile.ZipFile(E/'history.zip'); hm=json.loads((E/'history-manifest.json').read_text()); mm=json.loads((E/'migration-manifest.json').read_text()); dm=json.loads((E/'decomposition-mapping.json').read_text())
hist=[]
for n in z.namelist():
 b=z.read(n);ok=n in base and sha(b)==base[n]['sha256'] and sha(b)==hm[n]['sha256'];hist.append({'path':n,'ok':ok})
emit('history.json',hist)
exact=['AGENTS.md','README.md','exec-plans/template.md','subagent-templates/planner.md','subagent-templates/developer.md','subagent-templates/validator.md']; tree=json.loads((B/'upstream-tree.json').read_text()); tree={i['path']:i for i in tree['tree']}; upstream=[]
for p in exact+['references/README.md','skills/README.md']:
 b=(B/'upstream'/p).read_bytes();cur=(R/p).read_bytes();blob=H.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();upstream.append({'path':p,'blob_verified':blob==tree[p]['sha'],'content_verified':cur==b if p in exact else cur.startswith(b)})
emit('upstream.json',upstream)
protection={'restored_deletions':[p for p,v in pre.items() if v['state']=='missing' and p!='README.md' and (R/p).exists()], 'unchanged':{p:sha((R/p).read_bytes())==v['sha256'] for p,v in base.items() if p=='.gitignore' or p.startswith('.github/') or p.startswith('states/')},'old_present':[p for p in ['docs','source','PLANS.md','rules.md','CLAUDE.md'] if (R/p).exists()]}
emit('protection.json',protection)
refs=[]
for p in ['references/garmin-fit-parsing.md','references/longdou.md']:
 a=(B/'before-public'/p).read_text();b=(R/p).read_text();refs.extend(difflib.unified_diff(a.splitlines(),b.splitlines(),fromfile=p+' before',tofile=p+' current'))
(O/'reference-diff.txt').write_text('\n'.join(refs));(O/'reference-diff.txt').chmod(0o600)
# source tables and non-table decomposition, independent of mapping
coverage=[]; omissions=[]; view=[]
for m in dm:
 source=z.read(m['source']).decode();lines=source.splitlines();dest=(R/m['destination']).read_text();mapped={t['line']:t for g in m['groups'] for t in g['tasks']}; excluded={t['line']:t for g in m['excluded_groups'] for t in g.get('tasks',[])}
 view+=['\n# '+m['source']]; section=''; fence=False
 for i,line in enumerate(lines,1):
  if line.startswith('```'):fence=not fence
  if line.startswith('#'):section=line;view.append(f'{i}: {line}')
  if fence:continue
  if line.startswith('|') or (re.match(r'\d+[.)、] ',line)):
   view.append(f'{i} [{"MAP" if i in mapped else "EXCL" if i in excluded else "-"}]: {line}')
   if line.startswith('|') and re.search(r'\|\s*(?:done|pending|in_progress|blocked|cancelled|completed|exec|plan)\s*\|',line) and i not in mapped and i not in excluded:omissions.append([m['source'],i,line])
 for i,t in mapped.items():
  ok=t['source_row']==lines[i-1] if 'source_row' in t else True
  row=next((line for line in dest.splitlines() if line.startswith('| '+t['id']+' |') and '| '+t['status']+' |' in line),None)
  coverage.append({'source':m['source'],'line':i,'id':t['id'],'source_match':ok,'current_row':row is not None})
(O/'source-decomposition.txt').write_text('\n'.join(view));(O/'source-decomposition.txt').chmod(0o600)
emit('decomposition.json',{'plans':len(dm),'tasks':len(coverage),'coverage':coverage,'unmapped_status_rows':omissions})
# current structure and local links; skip issue quote rows which explicitly preserve historic evidence
formats=[]; links=[]; tables=[]
for p in [R/k for k in s['files'] if k.endswith('.md') and '/evidence/' not in k]:
 text=p.read_text();rel=str(p.relative_to(R));isplan=rel.startswith(('exec-plans/active/','exec-plans/completed/'))
 if isplan:
  required=['## 对应目标','## 阶段与任务','## 当前检查点','## 问题记录','功能编号：','功能状态：','总计划对应条目：','目标及范围和验收要求的引用：','工作目录与分支：','验收要求与受验版本及未提交改动：','最近完成：','下一动作：','暂停原因：','恢复条件：','PR 与交付情况：']
  formats.append({'path':rel,'missing':[h for h in required if h not in text]})
 fence=False; tablewidth=None
 for i,line in enumerate(text.splitlines(),1):
  if line.startswith('```'):fence=not fence
  if fence:continue
  if line.startswith('|'):
   width=len(re.split(r'(?<!\\)\|',line))-2
   if tablewidth is not None and width!=tablewidth:tables.append([rel,i,tablewidth,width])
   tablewidth=width
  else:tablewidth=None
  if '原件L' in line or '原执行计划 L' in line or line.startswith('| ISSUE-'):continue
  for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',line):
   if re.match(r'[a-z]+:',target) or target.startswith('#'):continue
   target=target.split('#')[0]
   if not target:continue
   if not (p.parent/target).exists():links.append([rel,i,target])
emit('format-links.json',{'plans':formats,'bad_links':links,'table_width_mismatches':tables})
print(json.dumps({'freeze_errors':errors,'history':len(hist),'history_bad':sum(not x['ok'] for x in hist),'upstream':upstream,'protected':protection,'decomposition_plans':len(dm),'mapped_tasks':len(coverage),'coverage_bad':sum(not x['source_match'] or not x['current_row'] for x in coverage),'unmapped_status_rows':len(omissions),'plan_count':len(formats),'bad_links':len(links),'bad_tables':len(tables)},ensure_ascii=False,indent=2))
