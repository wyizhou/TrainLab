import json, pathlib as P, zipfile, re, sys
R=P.Path('/Volumes/DiskOther/Code/TrainLab');O=P.Path('/private/var/tmp/trainlab-agentsmd-upgrade-tciokw12/validator-v2-checks');E=R/'exec-plans/evidence/ADHOC-0029'
z=zipfile.ZipFile(E/'history.zip');dm=json.loads((E/'decomposition-mapping.json').read_text());headings=[]
for m in dm:
 for i,l in enumerate(z.read(m['source']).decode().splitlines(),1):
  if re.match(r'#{2,6}\s+(?:M\d+-\d+|[CDS]-\d+|阶段[一二三四五12345]|Step \d+)',l):headings.append({'source':m['source'],'line':i,'heading':l})
p='docs/exec-plans/completed/M4-source-root-0001-product-consolidation.md';q='exec-plans/completed/M4-source-root-0001-product-consolidation.md';old=z.read(p).decode().splitlines();new=(R/q).read_text().splitlines()
result={'review':'manual non-table decomposition semantic comparison; string markers are evidence locators, not a required wording policy','source':p,'destination':q,'scanned_plans':len(dm),'task_headings':headings,'original':{str(i):old[i-1] for i in range(32,78)},'current_rows':{str(i):l for i,l in enumerate(new,1) if l.startswith('| M4-')},'findings':[{'id':'ADHOC-0029-V001','requirement':'AC-02 / original non-table task inputs, error boundaries and checks must be carried into migrated task structure','task':'M4-0002','original_lines':'48-56','expected':'展示限定输入 active raw ∪ backup-only raw ∪ legacy FIT、按SHA去重/身份和revision重放；不迁移旧AI报告/计划/邮件/用户事实/交付运行历史；legacy FIT不能唯一绑定时仅归档并登记、不猜测。','actual':'当前行只复述原状态表L84的已重建数量及检查通过，边界为通用不超出原目标/授权，检查方法为通用核对原记录；上述任务级输入、排除项和歧义处理仅在ZIP原件。'},{'id':'ADHOC-0029-V001','requirement':'AC-02','task':'M4-0003','original_lines':'58-68','expected':'承接任务名及明确合同/错误边界，包括课程与画像合同版本、攀岩unsupported_skip、主睡眠歧义/未结束处理、完整周缺周日延期。','actual':'当前行只复述原状态表L85 course/profile/sleep/负荷已接入且PASS，具体任务范围/错误处理未进入新任务结构。'}],'conclusion':'失败：工作表行覆盖通过不等于原非表格任务定义完整迁移。原件保全通过，不重判旧M4产品。'}
p=O/'non-table-review.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');p.chmod(0o600)
print('ADHOC-0029-V001 AC-02: M4 non-table task definitions were replaced by status summaries; manual semantic review FAILED. Evidence non-table-review.json')
sys.exit(1)
