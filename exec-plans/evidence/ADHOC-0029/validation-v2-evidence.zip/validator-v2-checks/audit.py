import pathlib as P, json, hashlib as H, subprocess as S, zipfile, re, html, sys
R=P.Path('/Volumes/DiskOther/Code/TrainLab'); B=P.Path('/private/var/tmp/trainlab-agentsmd-upgrade-tciokw12'); O=B/'validator-v2-checks'; E=R/'exec-plans/evidence/ADHOC-0029'
def load(p):return json.loads(p.read_text())
def sha(b):return H.sha256(b).hexdigest()
def norm(t):return re.sub(r'\s+',' ',html.unescape(t).replace('\\|','|')).strip()
def save(n,d):
 p=O/n;p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');p.chmod(0o600)
z=zipfile.ZipFile(E/'history.zip');dm=load(E/'decomposition-mapping.json'); mm=load(E/'migration-manifest.json');s=load(E/'review-snapshot-v2.json');out={};errors=[]
# task definitions all groups including replaced scopes, complete source row and current fields
rows=[]
for m in dm:
 dest=(R/m['destination']).read_text()
 for g in m['groups']+m['excluded_groups']:
  for t in g['tasks']:
   src=z.read(t.get('source_file',m['source'])).decode().splitlines();idx=t['line']-1
   old=t.get('source_row',''); joined=' '.join(l.strip().removeprefix('- ') for l in src[idx:idx+3]);match=not old or norm(old) in norm(joined)
   row=next((l for l in dest.splitlines() if l.startswith('| '+t['id']+' |') and '| '+t['status']+' |' in l),'')
   fields=[t['label'],t['dependency'],t['check'],t['result']];ok=bool(row) and all(norm(f) in norm(row) for f in fields)
   rows.append({'source':m['source'],'line':t['line'],'id':t['id'],'source_ok':match,'current_fields_ok':ok})
   if not match or not ok:errors.append(rows[-1])
# independent work table enumeration including backtick states, all task sections
work=[]
for m in dm:
 lines=z.read(m['source']).decode().splitlines();mapped={t['line'] for g in m['groups']+m['excluded_groups'] for t in g['tasks'] if t.get('source_file',m['source'])==m['source']};section=''
 for i,l in enumerate(lines,1):
  if l.startswith('## '):section=l
  if l.startswith('|') and re.search(r'工作分解|执行步骤|步骤与|## 步骤|## Work|当前状态',section) and re.search(r'\|\s*`?(done|pending|in_progress|blocked|cancelled|completed|active|validated|validating)`?\s*\|',l):
   work.append({'source':m['source'],'line':i,'mapped':i in mapped})
   if i not in mapped:errors.append(work[-1])
# issue text compared exactly through source quoting; cannot derive cumulative failures from duplicate rows
issues=[]
for m in dm:
 src=z.read(m['source']).decode().splitlines();dest=(R/m['destination']).read_text()
 for i in m['issues']:
  ok=i['source_text']==src[i['line']-1] and norm(i['source_text']) in norm(dest)
  issues.append({'source':m['source'],'line':i['line'],'ok':ok})
  if not ok:errors.append(issues[-1])
failure=load(E/'failure-index.json');failures=[]
for p,v in failure.items():
 src=z.read(p).decode().splitlines()
 for i in v['entries']:
  ok=i['text']==src[i['line']-1] if 'text' in i else i['row'] in src
  failures.append(ok)
  if not ok:errors.append([p,'failure index',i.get('line',i.get('row'))])
# independently enumerate roadmap leaf rows, not manifest count
old=z.read('PLANS.md').decode();new=(R/'PLAN.md').read_text().split('## 原Roadmap阶段与叶子任务迁移',1)[1];road=[]
for line in old.splitlines():
 if not line.startswith('| ['):continue
 cells=[x.strip() for x in line.strip('|').split('|')]
 idmatch=re.search(r'`((?:M\d+|ADHOC-\d+)-\d+)`',cells[0])
 if not idmatch:continue
 id=idmatch[1];newrow=next((l for l in new.splitlines() if l.startswith('| '+id+' |')),'');newcells=[x.strip() for x in newrow.strip('|').split('|')]
 dep=cells[2] if len(cells)==5 else cells[3];result=cells[4] if len(cells)==5 else cells[5];name=re.sub(r'^\[[ x]\]\s*','',cells[0]).replace('`'+id+'`',id)
 ok=bool(newrow) and norm(dep)==norm(newcells[4]) and norm(result) in norm(newcells[2]) and norm(name) in norm(newcells[2])
 road.append({'id':id,'ok':ok,'old_state':cells[1],'new_state':newcells[1] if newrow else ''})
 if not ok:errors.append(['roadmap',id])
# states four allowlist baseline, no directory enumeration
pre=load(B/'preflight-git-baseline.json');states={}
for p,v in pre.items():
 if p.startswith('states/'):
  q=R/p;states[p]=sha(q.read_bytes())==v['sha256'] and oct(q.stat().st_mode)==v['mode']
# synthetic paths only for ignore -- no reading private files
paths=['states/Goal.md','states/activities/synthetic-private.fit','states/health/synthetic.json','states/verification/synthetic-secret.json','states/synthetic.db','states/synthetic-report.md','states/Goal-example.md','states/activities/.gitkeep','states/health/.gitkeep','states/verification/.gitkeep']
p=S.run(['git','check-ignore','--no-index','--stdin'],cwd=R,input='\n'.join(paths)+'\n',text=True,capture_output=True);ignored=p.stdout.splitlines();ignore_ok=ignored==paths[:6]
# current status columns and local markdown fragments
badstatus=[];badanchors=[];jsonblocks=[];whitespace=[]
for path in s['files']:
 if not path.endswith('.md') or '/evidence/' in path:continue
 text=(R/path).read_text();lines=text.splitlines();statusindex=None
 for i,l in enumerate(lines,1):
  if l.endswith((' ','\t')):whitespace.append([path,i])
  if l.startswith('|'):
   cells=[v.strip() for v in l.strip('|').split('|')]
   if '状态' in cells:statusindex=cells.index('状态');continue
   if statusindex is not None and statusindex<len(cells) and not cells[statusindex].startswith('---') and cells[statusindex].split('；')[0] not in ['[plan]','[exec]','[completed]']:
    badstatus.append([path,i,cells[statusindex]])
  else:statusindex=None
  if '原件L' in l or '原执行计划 L' in l:continue
  for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',l):
   if ':' in target or '#' not in target:continue
   f,anchor=target.split('#',1);q=(R/path).parent/f if f else R/path
   if not q.is_file():continue
   headings=re.findall(r'^#+ (.+)$',q.read_text(),re.M)
   slugs=[re.sub(r'[^\w\-\s\u4e00-\u9fff]','',h).lower().replace(' ','-') for h in headings]
   if anchor not in slugs:badanchors.append([path,i,target])
 for b in re.findall(r'```json\s*\n(.*?)\n```',text,re.S):
  try:json.loads(b);jsonblocks.append({'path':path,'ok':True})
  except ValueError:jsonblocks.append({'path':path,'ok':False})
# source manifest completeness against before public Markdown
base=load(B/'before-public.json');originals={p for p in base if p.endswith('.md') and (p.startswith('docs/') or p in ['AGENTS.md','PLANS.md','memory.md','skills/README.md','references/garmin-fit-parsing.md','references/longdou.md'])}
archive_complete=originals==set(z.namelist())
# error controls in memory; no product or repository modifications
statecheck=lambda st: st in ['[plan]','[exec]','[completed]']
fixture={'a.md':b'one','b.md':b'two'};expected={k:sha(v) for k,v in fixture.items()}
checkhash=lambda d: all(k in d and sha(d[k])==v for k,v in expected.items())
mutants={'normal_state':statecheck('[exec]'),'bad_state_rejected':not statecheck('[blocked]'),'normal_digest':checkhash(fixture),'missing_file_rejected':not checkhash({'a.md':b'one'}),'changed_digest_rejected':not checkhash({**fixture,'b.md':b'bad'}),'normal_link':'a.md' in fixture,'bad_link_rejected':'missing.md' not in fixture,'task_omission_rejected':not {'S1','S2','S3'}.issubset({'S1','S2'}),'id_rename_rejected':not {'D-01'}.issubset({'L01'}),'false_completion_rejected':not ('[completed]'=='[plan]')}
out={'errors':errors,'task_rows':rows,'worktable_enumeration':work,'issue_rows':issues,'failure_index_entries':len(failures),'failure_index_ok':all(failures),'roadmap':road,'states_unchanged':states,'ignore':{'exit':p.returncode,'ok':ignore_ok,'ignored_synthetic_paths':ignored},'status_errors':badstatus,'anchor_errors':badanchors,'json_blocks':jsonblocks,'trailing_whitespace':whitespace,'archive_complete':archive_complete,'mutants':mutants}
save('audit.json',out)
summary={k:v for k,v in out.items() if k not in ['task_rows','worktable_enumeration','issue_rows','roadmap','json_blocks']};summary.update(task_rows=len(rows),worktable_rows=len(work),issues=len(issues),roadmap_leaves=len(road),json_blocks=len(jsonblocks))
save('audit-summary.json',summary);print(json.dumps(summary,ensure_ascii=False,indent=2))
sys.exit(1 if errors or badstatus or badanchors or not ignore_ok or not archive_complete or not all(mutants.values()) else 0)
