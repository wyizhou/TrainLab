# TrainLab 项目记忆

主协调维护稳定事实与活动指针；任务状态以 exec plan 为准。不得保存私人资料、步骤或完整对话。

## 当前方向

- 2026-09-15用户已手动删除旧fit保全目录、将根data改名states；后续已有活动数据入口为`states/activities/`，不自动恢复`data/fit/`或额外保全文件。私人目标/认证位置为`states/Goal.md`及`states/verification/`；不读取或公开正文。
- 按用户随后澄清，states只公开三个数据子目录的空`.gitkeep`及虚构`Goal-example.md`，其余私人内容（包括真实Goal.md）继续忽略。目标示例提供距离填写方法，不代表用户真实目标或训练处方。
- 原activities命名为日期前缀加64位十六进制标识，天气后缀`.weather.json`；标识不能当当前FIT内容SHA。数据目录不是命令入口；旧source入口仅作过静态调查，已随旧树删除，不描述为当前可用。
- 2026-09-15用户明确不需要旧代码验证，转向直接API重构；next公开代码已作为未验证快照保存推送，不代表可运行交付。用户现确认主动删除source、根README.md/CHANGELOG.md/rules.md/CLAUDE.md，不自动恢复；直接API新实现尚未交付。规则载体与新实现的目录/CI入口仍需明确，文件删除不自动取消其他安全边界。
- 以下为既有M12目标与历史事实，不自动恢复其旧执行计划或真实调用。
- 用户已批准 M12：FIT-only 运动数据、新 SQLite、每周一次跑步技术总结与固定七日计划、
  简单邮件/PDF、Garmin 课程发布。每日健康/日报 AI 和高保真邮件不再是活动目标。
- source/ 是唯一产品工程；A-021 允许新的 Python 模块入口、相对实例路径和手动 daemon。
  接回的next快照已不含旧auto.txt；本次未做运行验收，不表示后台已运行。
- 每日香港时间22:00同步当日、昨日及已知缺口；周日15:00同步并冻结周报告。
  离线验收后才进入精确在线范围，首个真实周任务等待下个正常周日15:00。
- 每个独立模块测试及全新只读验证通过后正常提交并推送 origin/main；不包含私人数据或强推。
- 旧source/state曾存数据库及WAL/SHM；source现已由用户删除，不再断言原位置仍有数据库。本轮未核对私人保全/仓库外备份，不把目录删除视为数据库迁移完成，旧归档不能成为新运行依赖。
- 用户已确认 A-022，现完整合同VC-005：运动位置/路线/名称可供 AI 分析，凭据/任意文件边界保留；必要旧M12快照只读恢复不重置预算。不是允许私人资料进入 Git 或自动新增地图/天气服务。
- A-023要求批准的新方案同批替换受影响的规则、实现、Schema、Prompt、入口、配置、测试、CI与文档；必要安全场景迁移验证，已取消业务归档，不维持第二套执行器或永久旧测试总数。
- 归档工具已独立验证，9612 文件备份及恢复闭合。提交 afdb8c0 已推送核对；
  备份位置、清单与恢复命令见当前计划及 source/docs/legacy-archive.md。
- M11 未完成 v4 方向已取消，由 M12 替代；原 canary 失败和私人调用0的记录永久保留。

## 开发与安全

- 默认中文，通俗解释；保留必要的状态码、命令与协议名称。
- 根 Harness 适配 agentForge main 9964970d38df95bbd8fab53166c27c2e5648b82e，
  是 v0.4.4 后治理更新，不是新的正式版。
- AGENTS.md 授权 docs/exec-plans/README.md 作为详细协议。正式任务冻结合同；
  Validator 只读适用合同/规则/当前结果，不继承实施对话、memory 或历史 verdict。
- 验证绑定当前文件快照。只同步真实状态免重验；实现、规则、配置或合同语义变化必须新验证。
  同类两种修法仍失败、三轮不收敛或合同冲突时走独立 Failure Analyst，不自动补丁循环。
- 本仓库禁用 orchestrate-parallel-work，不修改全局技能/配置；实际并行需明确批准。
- FIT、GPS、raw、数据库、私人 goal/email、凭据/Token、Candidate 和结果不进入 Git。
  测试只使用合成或获批隔离输入；正常运行不读取测试。
- Gmail 只用官方 REST，正常原子刷新专用 Token；单次发送，unknown 只读对账。
  Garmin 只能管理已知自有 ID；历史成功验收不授权新的在线动作。
- 根 references 仅按用户主动请求维护，不自动沉淀开发结论。
- 2026-09-14：pi-subagents native fresh 子进程已实测完成（smoke run `99563d59-058a-475e-8633-431e2d3a23cf`）；原接口缺失阻塞已解除。该证据只证明调度可用，不替代产品验证。

## 验证入口

- source旧树及原测试/依赖/linter配置已删除；.github/workflows/ci.yml仍引用原入口，不是当前可运行的产品验证链。本轮不修旧产品或关闭CI。
- 新实现沿用既有Python3.12/pytest/Ruff/mypy技术栈，同批落实适用测试、配置、compile/Schema及CI，迁移必要安全场景，不把历史PASS当新产品验收；不要求项目.venv。
- 当前规划检查：根目录git diff --check，新增文件另查空白/Markdown/本地链接/JSON示例，核对完整tracked/untracked及删除基准，保护私人数据忽略。
- 旧 macOS 专用 Candidate 的 Linux CI 失败记录仍保留；不得把 macOS 通过称为 Linux 已验证。

## 当前活动指针

2026-09-15：[FIT与报告当前决策/计划（ADHOC-0023）](docs/exec-plans/active/ADHOC-0023-fit-data-classification-discussion.md)：states/data.db规划四张业务表，FIT基础层activities十二列（含segments_json）＋records四列（activity_id、record_index、timestamp_utc、metrics_json），联合主键为前两列、每场从0编号。报告按最新决定：activties_report为activity_id、运动start_time_utc、完整文本summary；weekly_report为自增id、run_time_utc、完整文本summary，覆盖本次实际时间T往前七天，不是自然周/固定整点，不再有周报activity_id或week_id。两表均三列，AI文本不覆盖FIT summary_json；SQLite自增系统表不算新增业务表。默认给所有受支持运动第1/2/3类，仅running提供get_running_records(activity_id)取全部采样，超限整体失败不截断；子类不设白名单、铁三排除不变，不增加报告AI工具。五份计划ADHOC-0024至0028均planned；身份/时间/字段设计已确认，剩余实施边界未冻结，未建库、开发、调用AI或启动调度。

2026-09-15：[ADHOC-0019](docs/exec-plans/completed/ADHOC-0019-adopt-next-before-api.md)按用户明确取消旧代码验证的VC-002结束。主检查点fb6fe6d及next未验证源码快照6965654已正常推送并核远端；只做公开提交隐私检查，不宣称功能/CI通过。旧保护基准缺失和此前联网安装越界如实保留，不改判历史失败。后续转向直接API，具体实现尚未开始；不自动恢复旧任务或删除原件。

历史保全/目录清理分别见[ADHOC-0017](docs/exec-plans/completed/ADHOC-0017-consolidate-pre-api-baseline.md)和[ADHOC-0018](docs/exec-plans/active/ADHOC-0018-data-fit-year-cleanup.md)。旧清理验收仍为INCONCLUSIVE，已删副本无法事后重哈希；本轮用户另选activities不改判该历史，也不恢复旧清理循环。旧data/fit、按年份命名及保全数量仅是历史记录，已不是当前目录入口或应恢复的目标。历史来源/保护证据路径不保证仍存在；令牌在线有效性和SQLite一致性未验，真实R7及旧代码修复不自动续跑。

原 [M12 FIT-only 周系统重建](docs/exec-plans/active/M12-fit-weekly-0001-rebuild.md)暂停续跑，以下为其历史检查点，不是本轮执行指令。

当前0003n按VC-005进行依赖与验收收敛；首批公共资源、周输入与安全接替已获全新独立PASS，提交25e8b92已推送，远端macOS/Linux完整CI均3049项通过。剩余旧CLI退出正在验收，不等于M12交付。修改前保护/恢复副本及正式state不变。旧M9停止确认失败原因仍未确定，不声称已修复。0004–0006未进入真实调用。

## 历史交付定位

- 2026-09-15：[ADHOC-0020](docs/exec-plans/completed/ADHOC-0020-states-activities-decisions.md)已记录states/activities决策；目录骨架、虚构Goal示例及隐私忽略经VC-002独立PASS并归档。未提交/推送，不表示旧产品/API/数据库验收。
- 开发治理：ADHOC-0015/0016，见 docs/exec-plans/completed/。
- M10 曾完成有界 Garmin 测试课程生命周期与 Gmail 投递；不授权长期自动化。
- M11 v3 曾完成8封真实邮件；v4 返工取消，不改写为成功。
- M7/M8/M9 的测试、真实数据离线验收与失败记录均留在原 completed plans。
  M8 r31 曾触碰正式 SHM 元数据，不得宣称全部历史从未触碰 sidecar。
