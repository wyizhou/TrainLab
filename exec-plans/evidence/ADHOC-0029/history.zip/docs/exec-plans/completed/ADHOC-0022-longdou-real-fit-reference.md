# 执行计划：龙豆传感器资料与真实跑步 FIT 对照

- 任务 ID：`ADHOC-0022`
- 状态：`completed`
- 负责人：主协调 Agent
- 执行方式：串行研究、资料编写与全新只读独立验证
- 开始 / 更新日期：2026-09-15
- 用户依据：用户明确要求用真实跑步 FIT 解释通用/运动/外接传感器字段，指出佩戴龙豆跑步动态传感器、连接方式不确定，指定阅读 `references/longdou.xlsx`，熟悉后总结为 `references/longdou.md`；原 XLSX 留用户之后自行删除。

## 冻结验证合同

<!-- VC-001-BEGIN -->
- 合同版本：`VC-001`
- 合同状态：`frozen`
- 冻结依据：2026-09-15上述用户明确请求；在写参考正文或解析私人 FIT 前冻结。
- 范围：只读提供的 XLSX，结合现有 `states/activities/` 中必要的代表性跑步 FIT，解释真实字段、设备连接方式和来源可追溯性；写 `references/longdou.md` 和本任务协调记录。实际活动证据只留仓库外 owner-only 私有位置，聊天中仅展示解释所需的最少数据。
- 非目标：不改产品解析器/配置/Schema/测试/CI/规则；不读目标、认证、天气/健康资料或旧数据库；不发邮件、不连接 Garmin 业务服务、不上传 FIT、不安装全局依赖或仓库 .venv；不删除/移动/修改 FIT 或 XLSX，不暂存/提交/推送/切换分支。
- 工具边界：依赖安装须另获明确批准；当前环境无可用 FIT 解码依赖时暂停相关实读，不以未验证手写解码结果冒充 SDK 实测，不继承历史临时环境的安装/使用授权。
- 适用规则：AGENTS 的 References、私人数据、Git、合同和独立验证边界；rules A-001/A-002/A-004/A-009/A-019/A-020/A-022；执行协议。
- 尚待确认的实施授权：临时隔离环境中的官方 SDK 下载/安装，或用户指定已有可用环境。传感器型号、佩戴方向、主从/左右映射无法由资料或 FIT 唯一确定时保留未知，不擅自设定。

| 标准 | 要求 | 来源 |
| --- | --- | --- |
| AC-01 | 完整理解 XLSX 的字段名、单位、精度、指标分组和重要限定；用自主概括形成可独立阅读的 longdou.md，记录来源、摘要、复核日期、未知项及过期条件，避免依赖原 XLSX 永久存在。 | 用户保存 Markdown、之后自行删除 XLSX 的请求；References 边界 |
| AC-02 | 用真实跑步 FIT 的实际消息/有效值说明通用指标、跑步动态和设备信息；区分真实观测、换算/映射及未证实推断，不再用虚构数据冒充真实例子。 | 用户真实例子请求 |
| AC-03 | 结合 device_info 与实际字段/开发者元数据判断连接与数据来源；不能仅凭文档标题、相似指标名称或存在某设备就断言 ANT+/BLE、逐字段归属或全部指标齐备。证据不足明确说明。 | 用户连接方式疑问；事实准确性边界 |
| AC-04 | 原 FIT、XLSX 及既有未提交成果保持不变；公开 references/计划不包含真实活动采样、GPS、序列号、目标、凭据或无关作者元数据；不新增未授权外部动作。 | AGENTS/rules 私人数据和原件保护；用户自行删除说明 |

| 门禁 | 检查 | 预期 |
| --- | --- | --- |
| GATE-01 | XLSX 原内容与 Markdown 逐项对照；FIT 完整性/解码错误、样本定位与来源核验，换算只做一次。 | 可追溯且无错标；解析失败/缺失不伪造。 |
| GATE-02 | Markdown/链接、git diff --check（含新文件）、完整差异/摘要、原件和既有成果保护及公开隐私检查。 | 仅获批参考/协调写入；未泄露私人值、未修改原件。 |

| 版本 | 状态 | 说明 | 批准依据 |
| --- | --- | --- | --- |
| VC-001 | frozen | 初始研究与资料交付合同；依赖安装仍待单独授权 | 2026-09-15用户请求 |
<!-- VC-001-END -->

## 步骤

| 步骤 | 状态 | 证据 |
| --- | --- | --- |
| 阅读 XLSX 与检查可用环境 | done | 43项字段；现有3个解释器均无 FIT 解码库 |
| 确认可用工具、选取真实跑步样本并只读解码 | done | 官方 SDK 21.214.0 安装与 import；有界候选中实际筛选2份，选中1份跑步；CRC/read通过 |
| 编写 longdou.md，组织最少必要真实示例 | done | 公开 references/longdou.md；仓库外私人 running-example.md 与 actual-example.json |
| 全新独立验证、回写与归档 | done | 全新独立33项检查通过，AC-01..04/GATE-01..02全PASS；主协调核对绑定并归档 |

## 检查点与证据

- Git 已就绪：仓库根 `/Volumes/DiskOther/Code/TrainLab`，`main`，HEAD `ec36ce7bbdf9d70a509238dd771b155eb6f84261`；暂存为空。
- 启动时14项未提交成果：前序13项加用户新放入的 `references/longdou.xlsx`，均保留；不续跑历史 M12 或清理计划。
- 已完整读取 AGENTS、rules、memory、PLANS、执行协议；references 下无额外 AGENTS。
- XLSX：15230字节，SHA-256 `65a8aae377bcbcbe83fc8bed1efc8cce2c13fae925562e609fd06fd0dfe8ea9a`；一个工作表“龙豆动态数据描述”，字段序号0–42共43项，无公式；用标准库 zipfile/XML 读取，没有运行 Excel 或执行外部链接。
- 已确认资料包含：dr_cadence 为双脚 spm；dr_timestamp 为相对毫秒；主从平衡不天然等于左右；DR-010/011 与 DR-013 的着地俯仰角正负解释不同且依赖佩戴方向；dr_fusion_scale 是 App 自动校准产物。文档中的理想阈值/损伤归因属于资料作者说法，不作为已验证医疗结论。
- 原表“序号”不等于 FIT field_definition_number；当前已核对8组 record/lap/session Developer Fields 名称、编号、单位和类型。其余字典字段和未知消息不能猜补。
- 来源的无关作者/机器路径元数据不写进摘要。longdou.md 已完成且通过独立验证，可脱离原 XLSX 阅读；原 XLSX 本轮保留，用户可按原计划自行删除。
- 证据根：`/private/var/tmp/trainlab-longdou-syaq1g1q`（0700；根文件0600），含既有基准、XLSX字段提取、环境/候选/原件核验、隔离 selected-running.fit、actual-example.json 和 running-example.md。私人活动数值与定位只在此处，不存凭据。
- 前轮环境检查：`/usr/bin/python3`（3.9.6）、`/Users/lucas/.local/bin/python3.12`、`/opt/homebrew/bin/python3.12`（后二者均3.12.13）中 `find_spec('fitdecode')` 和 `find_spec('garmin_fit_sdk')` 均为空。未安装任何依赖、未联网、未使用历史越界临时环境；不声称全机所有环境均不存在解码库。
- 原阻塞为依赖安装授权待确认，未进入实施失败/合同冲突/模型升级循环。
- 2026-09-15用户回复“批准”，明确同意上一轮提出的官方 SDK 联网下载及仓库外独立临时环境安装，仅用于本次本地只读分析；不上传活动、不改变系统或项目依赖。此为合同内工具授权条件的满足，逐字 VC-001 不改写。
- blocker_type：`none`；诊断状态：`not_triggered`。
- 实际环境恢复：官方 PyPI 的 garmin-fit-sdk 21.214.0 wheel SHA-256 `9fa66c8bc6983808e784ba5058c550831c2621862097f41998a3ba129b7b7c6d`，校验后在证据根 python-env 中离线安装本地 wheel；Python3.12/no-extras 无额外运行依赖，未安装 dev extras。项目和全局依赖未改。
- 初次安装预检错误地要求 requires_dist 完全为空而 AssertionError；后续 pip 因 wheel 未下载而失败，环境只创建未安装 SDK。核实所有依赖均为旧 Python 或 dev-extra 条件后修正检查，保留 sdk-preflight-initial-failure.json；没有通过安装测试框架或弱化字段标准绕过。
- 样本读取前保存 candidate-selection.json：上限20，实际筛选2份即找到符合条件跑步并停止扩展。对选中1份的隔离副本详读；两份实际读取原件前后 SHA/模式/mtime/ctime等元数据一致。只保存必要解释数据，不批量导出逐秒点。
- 自检最初发现三个临时研究脚本为0644（父目录0700仍限制访问），仅将这些新建脚本改为0600后通过，未改变任何原件权限。当前14项既有成果保持不变，共16项未提交变更；43字段核对、文档/差异/原件/隐私门通过，自检不代替独立裁决。

## 验证边界

- 本任务不是产品开发，不新增产品测试、不恢复旧代码验证；文档验收不能冒称 pytest/CI 通过。
- 独立 Validator 获逐字合同、适用规则、当前参考/XLSX、精确受审快照及必要的隔离私有活动证据；未读取 memory/PLANS/历史 verdict 恢复上下文，未修改交付物。
- 本次选择 native delegate 作为 fresh 只读 Validator，模型能力与主实施者相同，high 推理：既涉及真实私人数据，又涉及跨文档/单位/来源核对，采用充分的高档核查；不是因失败而升级。明确关闭 fork/技能继承，无并行写者、无第二集成层。
- 中性输入仅当前逐字合同、适用规则、16项客观快照、XLSX、公开参考、精确隔离 FIT/私人解释结果及已批准安装边界。禁止读取原 states/目标/认证/数据库/旧历史；私有原件保护只用预先记录的客观证据核对，不声称 OS 级全历史审计。
- 报告通过 runs.run 的 output 绑定到 owner-only 证据根；实际模型/运行身份在回执中，文件不建立厂商依赖。任何实际 FIT 数值不进入公开计划或参考文档。
- 2026-09-15 native fresh 工作流 `b7c564bd-64e6-4adf-b4fa-37a030808fa8` 已完成，稳定键 `adhoc0022-longdou-validator`，子运行 `9829fdae-dce1-40f0-b6ed-e44c272c54a0`，实际绑定输出为证据根 `validation.md`；主协调完整读取报告与机器证据后接受限定范围的 PASS。
- 受审快照 SHA-256：`8a1608e2c43bbeea9368653edd0871cf0cfbb02c457210c5984ffc21ff9a6723`；冻结合同：`816ae99348253699245f69868b5fbedfecffe51c7d03baa80daa0a6d95bd2287`；公开参考：`8278d5d8a89b3b34b6c5d96084068b39c1b9a775806b503045ada04962efa8ce`；私有解释报告：`17a86e08c3703abce2586249725cee1289c5a753083dfef3ab641e1d1b1e1790`。
- Validator 子运行 `9829fdae-dce1-40f0-b6ed-e44c272c54a0` 请求核对计划非合同正文的自动隐私检查权限及原件后置证据。主协调允许仅在内存自动检查当前协调差异，不作为历史上下文；不扩大到其他计划或原 states 读取。
- 补充独立记录的当前原件/副本 SHA 和 lstat 原始值到私有 `originals-post-observation.json`，摘要 `5086d0f4260c97336f889b78a40119f08531242cf39c196572f4b0daae8941d7`；不含 PASS 声明。最终报告及机器证据确认实际采用并独立比较一致；补证只支持观测时点间比较，不代表全历史主机审计；原受审参考/私有解释/合同未改。

## 独立验证与完成回写

- 八字段报告：证据根 `validation.md`，SHA-256 `b0eedb9a10813584afcc93dfb417d322e8621168a1fd207740b41541809eb674`。AC-01..04/GATE-01..02全部PASS，无阻塞或范围变更候选；原件保护结论限定为实际前后观测一致，不是连续历史审计。
- 独立检查：`PYTHONDONTWRITEBYTECODE=1 <证据根>/python-env/bin/python <证据根>/validator-checks/check.py` 最终退出0，33项通过；机器结果 SHA-256 `828ab2c6461bc2a82629c4a531c96ca72aee42c720cde3644359ad9bca977064`，方法脚本摘要 `bfa6e8eb03a167f2ea2ef8c4748f0adac41f9d70693171fafc00fda1f8b5b4a6`。
- 复核了原始XLSX全43项、独立新流CRC/解码、当前真实选择值、开发者定义/覆盖、标准raw换算、安装包与13个SDK源文件字节、16项完整快照和14项既有成果。`git diff --check`退出0，新文件no-index检查退出1且无诊断；Markdown、本地链接及公开隐私检查通过。
- Validator 方法调试曾遇到复用SDK流到EOF后的KeyError和误读新增no-index退出1，均在仓库外检查方法中修正，保持交付/合同不变后最终完整重跑通过；不隐藏失败，也不把它们记为受审产品缺陷。
- 主协调注意独立报告正文有“10项lstat”的计数笔误：客观JSON实际为9项，独立机器证据逐项比较通过。此处按原始记录限定为9项，不扩大取证维度，不改写独立原报告；不影响合同中前后观测一致的证据。
- 工作流回执：`/var/folders/dh/4th4rwbd7xlg8qslxz62hbjc0000gn/T/pi-subagents-uid-501/async-subagent-runs/b7c564bd-64e6-4adf-b4fa-37a030808fa8/workflow-receipt.json`，摘要 `684fce648e3f764179a44a4cd02e7647dd9a88f7c26f4a9c04201c5515831471`，1个子运行已完成。实际输出留在owner-only证据根，不将报告中的真实值复制到公开文件。
- 未运行产品pytest/Ruff/mypy/全CI：本轮仅参考和协调记录变更，既有产品/配置/测试不变；不声称这些产品门禁通过。Validator未联网复核外部链接实时可达性，使用固定来源/安装证据。
- 剩余未知：具体DR型号/佩戴侧/主从关系、逐标准指标来源、算法和未命名字段语义；不把文档资料变为医学判断。建议只维持现有保守解释，不新增开发或审计机制范围。
- 按串行正式任务条件归档至 `docs/exec-plans/completed/ADHOC-0022-longdou-real-fit-reference.md`；仅真实结果、状态和路径回写，引用原独立PASS，不改参考/私有解释/合同。ADHOC没有Roadmap叶子或memory活动指针待清理，保留原14项成果。未暂存、提交、推送或删除XLSX。最终复核回执位于证据根 `closeout-receipt.json`。

## 迭代日志

| 日期/上下文 | 完成 | 发现 | 下一动作 |
| --- | --- | --- | --- |
| 2026-09-15 / 本轮 | 获批隔离SDK，完成43字段参考和私有真实跑步对照；独立33项检查PASS，主协调复核并归档 | 标准/龙豆值并存且不同；型号和逐指标来源仍未知；初始检查/方法调试及报告计数笔误均如实保留 | 无获批后续开发或Git动作；用户可自行删除原XLSX |
