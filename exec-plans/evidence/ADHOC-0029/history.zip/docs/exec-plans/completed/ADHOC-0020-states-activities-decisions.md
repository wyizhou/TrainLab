# ADHOC-0020：记录 states / activities 数据目录决策

- 状态：`completed`；开始/更新：2026-09-15；负责人：Main；串行记录/配置维护及全新只读验证完成，无提交或推送。
- 用户明确：已手动删除 fit，将 data 改名 states；后续以 activities 为数据目录，要求熟悉其中的命令并记录决策。随后打断澄清：忽略 states 内私人文件，但保留目录骨架，可用 .gitkeep，并提供带距离例子的 Goal-example.md。
- Git 门禁：macOS，Git 2.50.1；根 `/Volumes/DiskOther/Code/TrainLab`，有效 worktree，main，HEAD `ec36ce7bbdf9d70a509238dd771b155eb6f84261`。开始时 tracked 修改及暂存为空；states 更名后有8831个未忽略的 untracked 私有路径，尚无 tracked states。只记录聚合事实，不公开逐文件私人清单。

## 当前冻结合同

<!-- VC-002-BEGIN -->

- 版本：`VC-002`；状态：`frozen`；日期：2026-09-15；依据：用户本轮明确决策及随后目录骨架/Goal-example.md澄清，根 AGENTS 与 A-004/A-019/A-020/A-023。
- 范围：记录用户已完成的目录调整及后续活动数据入口，熟悉现存文件命名/命令入口但不执行业务；states 私人内容忽略，目录骨架及虚构目标示例可跟踪。
- 允许写入：`.gitignore`、`rules.md`、`memory.md`、`README.md`、`CHANGELOG.md`、`PLANS.md`、本任务计划，以及新建的 `states/Goal-example.md`、`states/verification/.gitkeep`；既有空 `states/activities/.gitkeep`、`states/health/.gitkeep` 仅放行跟踪，不改原字节。仓库外0700临时目录可保存去敏检查脚本/证据。
- 隐私解释：公开的是用户提出的 Goal-example.md，使用虚构例子；真实 states/Goal.md 继续忽略且不读取、不覆盖，不把真实目标复制进模板。
- 非目标：不实现 API 或旧命令路径适配，不验证/修复旧产品，不新增或恢复 FIT，不移动/删除/修改私人文件，不读取 Goal/认证/健康正文，不连接 SQLite 或操作 sidecar，不调用 Provider/安装依赖/启动服务，不暂存、提交、推送或改写历史合同与 verdict。

| 标准 | 要求及来源 |
| --- | --- |
| AC-01 | 当前记录明确：用户已删除旧 fit；根 data 已改名 states；后续活动数据以 states/activities 为入口，不自动恢复 data/fit 或额外56份旧保全文件。来源：用户本轮明确决定。 |
| AC-02 | states 的 FIT、天气/健康 JSON、认证、真实 Goal.md 和其他私人内容继续忽略，不进入 tracked/staged；仅放行三个现有数据子目录的空 .gitkeep 与公开 Goal-example.md，不削弱已有其他隐私排除。来源：用户目录骨架澄清及 A-004。 |
| AC-03 | 当前规则、README、memory 和必要状态索引一致；历史计划/合同/失败保留，不把用户手工调整写成本次 AI 执行或历史验收通过；source/state 中仍存旧库/sidecar时如实标明，不声称全部状态迁移、数据库一致性或 API 运行路径适配完成。来源：用户记录请求、根真实状态要求、A-023。 |
| AC-04 | 只读核对 activities 文件类别/命名及可定位的现有命令资料；只记录有证据的结构，不把文件名标识冒称当前内容 SHA、把目录存在当命令可用，或将天气数据视为 FIT；未明确的“命令”含义保留澄清，不自动新增命名/执行要求。来源：用户熟悉目录请求及根证据要求。 |
| AC-05 | Goal-example.md 明示为虚构、非用户真实目标，提供距离相关填写例子并说明真实目标使用本地 Goal.md；不得复制私人正文/秘密/原始 FIT 或逐文件私人清单进入公开记录。来源：用户模板请求及 A-004。 |
| AC-06 | 只在允许范围写入；私人文件、旧代码、测试、CI 和历史冻结合同不变，外部调用与 Git 写操作为零。新公开文件导致的父目录元数据变动不冒称私人文件修改，须精确区分。来源：用户记录范围及根权限边界。 |
| GATE-01 | Main 检查本次完整公开差异、实际及合成路径的 ignore 白名单/负例、模板/空占位、链接与 diff-check；核私有树前后 lstat 元数据（不含读取时间），只允许新增公开文件及其父目录正常元数据变化。配置/治理任务不运行旧产品测试，不宣称产品或 CI 通过。来源：根适用检查与保护要求。 |
| GATE-02 | 全新只读 Validator 仅获得逐字本合同、适用规则、当前差异与快照；独立检查上述标准并返回协议八字段。memory/PLANS/计划协调段仅作本轮差异审计，不恢复历史；最终语义结果绑定摘要。来源：A-019/A-020。 |

<!-- VC-002-END -->

### 版本替代记录

VC-002依据用户打断澄清替代VC-001的整树忽略，改为私人内容忽略、目录骨架与虚构示例放行；扩展仅限上述两个新增公开文件。旧方案尚未实施，没有删除或重命名数据。本轮不将“Goal不忽略”解释为公开真实私人目标，采用用户提出的Goal-example.md作为公开示例。

## 历史合同 VC-001（superseded，原文保留）

<!-- VC-001-BEGIN -->

- 版本：`VC-001`；状态：`frozen`；日期：2026-09-15；依据：本轮用户明确决策及记录请求，根 AGENTS 与 A-004/A-019/A-020/A-023。
- 范围：记录用户已完成的目录调整及后续活动数据入口，熟悉现存文件命名/命令入口但不执行业务；同步新路径的 Git 隐私排除和必要当前文档。
- 允许写入：`.gitignore`、`rules.md`、`memory.md`、`README.md`、`CHANGELOG.md`、`PLANS.md`、本任务计划；仓库外0700临时目录可保存去敏检查脚本/证据。私人目录及产品代码只读。
- 非目标：不实现 API 或旧命令路径适配，不验证/修复旧产品，不新增或恢复 FIT，不移动/删除/修改任何私人文件，不读取 Goal/认证/健康正文，不连接 SQLite 或操作 sidecar，不调用 Provider/安装依赖/启动服务，不暂存、提交、推送或改写历史合同与 verdict。

| 标准 | 要求及来源 |
| --- | --- |
| AC-01 | 当前记录明确：用户已删除旧 fit；根 data 已改名 states；后续活动数据以 states/activities 为入口，不自动恢复 data/fit 或额外56份旧保全文件。来源：用户本轮明确决定。 |
| AC-02 | 新 states 全树继续遵守私人资料不入 Git；同步根忽略规则，不削弱已有其他隐私排除，states 无 tracked/staged 文件。来源：目录改名及 A-004。 |
| AC-03 | 当前规则、README、memory 和必要状态索引一致；历史计划/合同/失败保留，不把用户手工调整写成本次 AI 执行或历史验收通过；source/state 中仍存旧库/sidecar时如实标明，不声称全部状态迁移、数据库一致性或 API 运行路径适配完成。来源：用户记录请求、根真实状态要求、A-023。 |
| AC-04 | 只读核对 activities 文件类别/命名及可定位的现有命令资料；只记录有证据的结构，不把文件名标识冒称当前内容 SHA、把目录存在当命令可用，或将天气数据视为 FIT；未明确的“命令”含义保留澄清，不自动新增命名/执行要求。来源：用户熟悉目录请求及根证据要求。 |
| AC-05 | 只在允许的公开记录/配置范围写入，无私人正文/秘密/原始 FIT 或逐文件私人清单进入公开文档；私人数据/旧代码/测试/CI/历史冻结合同不变，外部调用与 Git 写操作为零。来源：用户记录范围及 A-004、根权限边界。 |
| GATE-01 | Main 检查本次完整公开差异、Git ignore（实际私有路径仅作元数据核对，合成新路径测试忽略规则）、链接和 diff-check；私有树前后 lstat 元数据（不含读取时间）稳定。配置/治理任务不运行旧产品测试，不宣称产品或 CI 通过。来源：根适用检查与保护要求。 |
| GATE-02 | 全新只读 Validator 仅获得逐字本合同、适用规则、当前差异与快照；独立检查上述标准并返回协议八字段。memory/PLANS/计划协调段仅作本轮差异审计，不恢复历史；最终语义结果绑定摘要。来源：A-019/A-020。 |

<!-- VC-001-END -->

## 步骤与检查点

| 步骤 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| S1 记录与隐私配置 | done | VC-002记录、公开白名单、目标示例及自检已交付 |
| S2 独立核对 | done | fresh只读Validator对VC-002返回PASS；范围仅本次记录/配置 |
| S3 收口 | done | Main复核受审快照及原件元数据，归档并回写链接；未提交/推送 |

- 实际布局：states 有 activities、health、verification 与 Goal；data/fit 不存在。source/state 仍有旧数据库及 WAL/SHM/lock，未连接或修改。
- activities 中没有命令脚本；已识别日期前缀与64位十六进制标识，标识与当前 FIT 内容摘要不相等，不解释为文件内容 SHA 或活动 ID。天气后缀为 `.weather.json`；原件不重命名。
- 本任务不恢复 ADHOC-0018 清理验收、M12 或旧 R7；本轮用户选择作为新的当前决策记录，旧 INCONCLUSIVE 不改判。
- blocker_type：`none`；诊断状态：`not_triggered`。

## 当前检查与受审材料

- 私有证据根：`/private/var/tmp/trainlab-states-decision-_3qu101c/`。原元数据清单仅含lstat，无私人正文；不提交该目录。
- 检查器：`PYTHONDONTWRITEBYTECODE=1 python3 /private/var/tmp/trainlab-states-decision-_3qu101c/check_decisions.py`，最终退出0。9340个states私人文件均忽略；20个合成隐私负例通过；公开白名单仅4个文件。三个.gitkeep均空，真实Goal/认证/旧库未读取或更改。
- 初次临时检查器错误：将APFS父目录nlink假定不变，断言退出1；实查只有states与verification两个父目录变化，各新增一项后nlink准确+1，其余原18694节点元数据全不变。保留initial脚本，修正为精确父目录增量检查；未改数据或降低私人文件保护。
- Git HEAD/branch及暂存空保持；完整公开受审集合11项（6个tracked记录/配置、计划、4个states公开文件）；source代码/测试、CI、根AGENTS及历史计划无改动。diff-check、Markdown新增文件空白与本轮文档链接检查通过。
- activities文件命名只读核对：FIT均符合日期+64位标识格式，但当前内容SHA与名称标识不同；天气是`.weather.json`。不重新解析日期/业务有效性、不读天气正文。命令只静态阅读`source/docs/fit-weekly-entrypoint.md`及`source/skills/_shared/fit_weekly/cli.py`，未执行任何旧命令。
- 受审快照：证据根`review-snapshot.json`，含基准HEAD、分支、11项完整变更/模式/SHA（计划仅VC-002段）。合同另存`contract-vc002.txt`，原文SHA `98fad230494d96b361cf9694f1f5dec9bc284d8e5dc573be878306d05ee48ff0`。
- 本次没有产品代码/运行语义变更，旧pytest/Ruff/mypy/业务CI不运行、不记通过；只核隐私配置、记录/模板和原件不变。
- 派发：ADHOC-0020-Validator，fresh native只读，模型能力high/推理high；同Main能力、显式推理档，因私人目录白名单及治理记录风险采用充分档位。只给逐字VC-002、适用规则和当前结果，memory/PLANS/计划协调段仅审计差异。工具没有OS只读沙箱保证，禁止写受审树；允许仓库外私有临时检查。产物由工具output绑定，不传Main自检结论或历史verdict。
- 实际async workflow：`cb7c33a1-6dfb-4fcc-af4b-c53f5f0a122b`；唯一child key `states-vc002-review`，output绑定`adhoc-0020-states-vc002-review.md`。派发脚本SHA `7346636aa00ef19d74dd1dc5bac737149fd9a1b55408d59895330c7babbd55bf`；原生通知后已读取完整实际产物。

## 独立验证与主协调收口

- workflow `cb7c33a1-6dfb-4fcc-af4b-c53f5f0a122b`、child `d923a2dc-5501-46ca-b72d-1c2964815a21` 均已核实complete；不是仅以工具ok代替裁决。
- 完整原始八字段报告：`/Users/lucas/.pi/agent/sessions/--Volumes-DiskOther-Code-TrainLab--/subagent-artifacts/outputs/cb7c33a1-6dfb-4fcc-af4b-c53f5f0a122b/adhoc-0020-states-vc002-review.md`；SHA `102c8950f103bd52a00cc86e08fdc724618d2af2dbf8af80db774a1b5a2d8250`。
- `contract_version`：VC-002，冻结段SHA仍为`98fad230494d96b361cf9694f1f5dec9bc284d8e5dc573be878306d05ee48ff0`。
- `overall_verdict`：PASS，仅文档、忽略配置、公开模板和骨架。
- `criterion_results`：AC-01–06、GATE-01–02均PASS；9340个私人文件路径忽略，4个公开正例、25个新路径私人负例及17个旧路径负例通过；11项当前文件/模式/合同摘要匹配，原18696项元数据无私人项变化。
- `blocking_findings`：无。
- `advisories`：只有真实状态/归档链接回写可免重验；不授权强制添加私人文件或启动/迁移业务。
- `scope_change_candidates`：无。
- `unknowns`：具体所指“命令”可继续澄清；运动日期语义、FIT有效性、数据库/凭据及业务状态未验；无OS强制只读沙箱，lstat不等于完整私人内容校验或历史主机操作审计。
- `commands_and_evidence`：独立标准库检查器、git check-ignore/完整差异/链接/diff-check均退出0；详见原报告。独立去敏证据`/var/folders/dh/4th4rwbd7xlg8qslxz62hbjc0000gn/T/trainlab-vc002-validator-u_vrznjp/evidence.json` SHA `728a7e8502ddd074f2a0241a70b1eea62bdedc9981b2e5d01ff49786da4400f8`；检查器SHA `6e987b3ccfc21891ac4ae7ca85970de980625a737a5eacd77cb1b0a3353d3f25`。未运行旧产品门、不宣称CI或API验收。
- Main收口前重新运行本次只读自检退出0，核实受审快照SHA `40d7e81c6c690c683d9ba3b56230413a711175556699d6eab2ae520bebcf3e60`、原元数据基准及独立产物摘要未变，原文件元数据仍闭合。随后仅归档本计划、更新README/PLANS链接、将memory活动指针改为完成事实；不更改已验证配置、规则、模板或合同语义。
- 本任务完成不代表ADHOC-0018历史清理通过，也不恢复M12/旧R7。私人原件未修改，暂存/提交/推送/Provider调用均未执行。

## 迭代日志

2026-09-15：用户澄清后冻结VC-002，保留VC-001历史；同步states/activities决策、精确忽略白名单和虚构距离示例。临时检查器APFS父目录nlink假设经核对修正，自检及全新只读独立验收PASS，Main复核后归档回写。私人文件、旧代码、历史裁决不动，未提交/推送。
