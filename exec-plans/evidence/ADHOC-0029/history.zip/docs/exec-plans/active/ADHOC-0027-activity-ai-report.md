# 开发计划四：活动 AI 总结存储 activties_report

- 任务 ID：`ADHOC-0027`
- 状态：`planned`；活动报告三字段及完整文本目标已确认，未实施。
- 负责人：主协调 Agent
- 日期：2026-09-15
- 用户最新依据：在activties_report中加入运动开始时间，summary为完整AI文本总结，并要求更新决策/计划、处理冲突、以当前为准。原两字段限制不再生效。
- 决策：[ADHOC-0023](ADHOC-0023-fit-data-classification-discussion.md)。依赖：[ADHOC-0024数据库底座](ADHOC-0024-fit-sqlite-parser.md)。相关但不预设前后依赖：[周报告计划](ADHOC-0028-weekly-ai-report.md)。
- 本轮仅更新计划；不建表、不生成真实AI报告、不读取正式数据、不提交或推送。无并行或外部动作授权。

## 目标与边界

在states/data.db增加activties_report，保存每场活动对应的完整AI总结。表名按用户原文拼写记录，不自动改成另一名称。

只使用以下三列；运动开始时间命名与activities保持一致。不新增独立report_id、报告生成时间、模型、状态、版本、评分等列，不通过强制summary包装对象暗中加回被否决字段。

| 字段 | 含义 | 类型 |
| --- | --- | --- |
| activity_id | 总结所属活动，关联activities.activity_id | TEXT |
| start_time_utc | 该运动实际开始时间，来自activities.start_time_utc；不是生成报告的时间 | TEXT |
| summary | AI总结的完整文本，而非摘录、路径或另行结构化的JSON报告对象 | TEXT |

- activities.summary_json仍保存FIT事实摘要；activties_report.summary保存AI报告，不互相覆盖，也不把AI判断伪装成FIT原生数据。
- 建议activity_id作为主键并引用activities：每活动一条当前报告。不新增独立ID；重复写入是覆盖、拒绝还是幂等，需要明确后固定，不自动承诺历史多版本保存。
- start_time_utc保存所属运动的开始时间，写入时与来源活动一致；合法缺失如实保留，不用当前时间/报告生成时间或文件名猜值。UTC存储与本地展示区分，不把本地钟点直接标成UTC。
- summary已明确为文本，完整保存并可原样读取；中文、换行、Markdown表格等仍是正文，不截断、不再次摘要，不强制改成结构化JSON或附塞模型/运行元数据。
- 报告正文是数据，不是SQL、shell、文件路径或外部动作指令。写入由受控宿主负责，不因新增表而增加AI工具、任意SQL/DB路径权限。
- 本任务聚焦表及完整报告的保存/读取边界。实际AI生成、Prompt/Provider选择、宿主接线、调度、邮件/PDF等不在本轮执行授权内；用合成文本验存储不等于真实AI闭环已交付。

## 验证合同草案

- 实施合同：`VC-001` / `draft`，未冻结。三字段、运动开始时间语义与全文本目标已确认，不再请求确认旧两字段方案；活动报告主键/重复写入、时间格式/缺失技术细则及实际写入边界落实后再冻结。
- 当前规则依据：根AGENTS、执行协议与本次用户授权。用户确认删除rules.md/source，不恢复或从历史拼接替代；新实现前须落实当前规则载体、代码落点与适用CI入口。
- 非目标：修改FIT基础两表列设计、添加分段表/报告元数据表、扩张唯一records查询工具、恢复旧产品或触碰私人报告/凭据。

| 标准 | 可验证目标 | 来源 |
| --- | --- | --- |
| AC-01 | states/data.db有activties_report业务表，只有activity_id、start_time_utc、summary三列。 | 用户最新字段决定 |
| AC-02 | 报告与指定活动对应，不串场；start_time_utc是来源运动开始时间，不是报告生成/写入时间，不自动创建假活动或伪造缺失时间。 | 用户每活动总结及新增开始时间目标 |
| AC-03 | 完整summary写入读取往返一致，不裁剪、再次摘要、只存路径或覆盖FIT summary_json。 | 用户全部内容目标与数据边界 |
| AC-04 | 保存操作不破坏activities、records、weekly_report或其他无关数据；失败不得留下半份报告冒充成功。 | AGENTS保护无关工作/数据边界 |

| 门禁 | 计划检查 | 来源 |
| --- | --- | --- |
| GATE-01 | 先建立合成正常/异常/边界预期，再实现；适用pytest/Ruff/mypy/compile/Schema与CI检查。 | AGENTS及执行协议 |
| GATE-02 | 三列Schema、运动开始时间来源/缺失/时区、活动隔离、完整文本、参数化写入、回滚和其他表保护。 | AC-01..04 |
| GATE-03 | fresh只读Validator核对冻结合同与当前快照；不用主自检或历史PASS替代。 | AGENTS及执行协议 |

## 工作分解与测试映射

| 步骤 | 状态 | 预期结果 |
| --- | --- | --- |
| 落实主键/重复保存、时间格式/缺失、文本空值/容量及宿主写入边界 | pending | 保持三列及全文本目标，冻结实施合同 |
| 先固定合成Schema及报告往返用例 | pending | 正常/错误/边界输入输出明确 |
| 实现建表和受控保存/读取，配套测试/文档/CI | pending | 与FIT底座共存，不新增AI工具 |
| 完整适用门禁与fresh独立验证 | pending | 存储交付，不冒称真实报告生成已完成 |

拟用source/tests/code/下的unit/test_activity_report_payload.py、contract/test_activity_report_schema.py、integration/test_activity_report_sqlite.py及fixtures/reports/。测试使用合成活动ID/报告：两活动不同开始时间/总结，运动开始与生成时间不同、合法开始时间缺失与UTC表示、中文多行/表格全文、SQL片段作为普通文本、失败回滚、重复写入策略和已有FIT数据不变。超容量不得静默裁文；具体阈值与错误行为在实施合同固定。

source旧树已被用户删除，上述为拟建测试路径，不是现存用例。新实现沿用既有Python3.12/pytest/Ruff/mypy栈，需与前置计划共同落实配置和CI；不运行旧产品，不读取正式Goal/FIT/报告，不调用业务Provider。

## 检查点与迭代

- 数据库不存在，未创建表/代码/真实报告。活动报告保留activity_id；周报告已改自增id和run_time_utc，不再有待澄清的周报activity_id关系。
- Git main / ec36ce7bbdf9d70a509238dd771b155eb6f84261；用户确认的删除保留，文档保护/检查证据见ADHOC-0023。
- 尚无实施失败或独立验收结论；本计划的创建不是功能完成。

| 日期 / 上下文 | 结果 | 下一步 |
| --- | --- | --- |
| 2026-09-15 / 本轮 | 按用户增加start_time_utc，确定summary为完整文本；清除两列限制及结构化JSON候选，区分运动开始时间与报告运行时间。 | 三字段设计已确认，落实剩余实施细则；不建库或调用AI。 |
